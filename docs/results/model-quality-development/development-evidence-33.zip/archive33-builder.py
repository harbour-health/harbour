"""Root-only Archive33 check/build from a hash-bound complete supplemental selection.

No model, scoring, source/test, transport, held-out or publication operation.
The preparer does not invoke this builder. Original phase/proof bytes stay intact.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'build/archive-development-33'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
read = lambda path: json.loads(Path(path).read_bytes())

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--selection', type=Path, required=True)
parser.add_argument('--selection-sha256', required=True)
mode = parser.add_mutually_exclusive_group(required=True)
mode.add_argument('--check-only', action='store_true')
mode.add_argument('--build', action='store_true')
parser.add_argument('--root-reviewed-build-go', action='store_true')
args = parser.parse_args()
assert not args.build or args.root_reviewed_build_go
assert sha(args.selection) == args.selection_sha256
selection = read(args.selection)
assert selection['sourceCommit'] == '0cbc0b0b9fa37347ca7af4d52d755c259f058a0c'
assert selection['sourceIdentitySHA256'] == '9e32bdce9ca76757e7c91ac7e7086f7af42679e808cd8318ab09937b906901cc'
assert selection['testedAppCommit'] == '3ee4ec60b7fe54419d56fdeeb8339183869486d5'
assert selection['docsPublicationCommit'] == 'd84fe754e94a267572974a40f977ae61bf354894'
assert selection['fileCount'] == len(selection['files'])
assert selection['totalUncompressedBytes'] == sum(r['bytes'] for r in selection['files'])

def verify(reference):
    path = (ROOT / reference['source']).resolve()
    assert path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink()
    assert path.stat().st_size == reference['bytes'] and sha(path) == reference['sha256']
    return path

names = set()
private_address = '.'.join(str(n) for n in (100, 83, 225, 2)).encode()
for reference in selection['files']:
    path = verify(reference)
    assert reference['source'] not in names
    names.add(reference['source'])
    assert len(path.read_bytes()) < 8 * 1024 * 1024 and private_address not in path.read_bytes()
    assert path.suffix.lower() not in {'.zip', '.gz', '.gguf', '.so', '.exe', '.mp4', '.pyc'}
    assert 'native-ci-d84fe75' not in reference['source'] and 'paired-heldout' not in reference['source']
    assert not any(p == '.build' or p.endswith(('.xcresult', '.app', '.xtoolsdk')) for p in path.parts)
    assert not path.read_bytes().startswith((b'MZ', b'\x7fELF', b'GGUF'))
assert len(selection['previousArchives']) == 32
for reference in selection['previousArchives']:
    verify(reference)

audit_path = verify(selection['actualCompleteAudit'])
metadata_path = verify(selection['actualMetadata'])
aggregate_path = Path(selection['actualAggregation']['path'])
assert sha(aggregate_path) == selection['actualAggregation']['sha256']
audit, metadata, aggregate = map(read, (audit_path, metadata_path, aggregate_path))
assert audit['result'] == 'PASS_BYTE_BINDINGS_GENERATION_AND_REVIEW_COMPOSITION'
assert audit['rows'] == audit['reviewed'] == 120 and audit['pending'] == 0
assert metadata['complete'] and metadata['executableSHA256'] == '4f978a93e69635cac5ee603771bd851d258bd4d221e2d0a60533a5fe2dd96052'
assert metadata['settings']['repeats'] == 1 and metadata['settings']['recordExecution'] is False
assert aggregate['requiredReviews'] == aggregate['reviewed'] == 120 and aggregate['pending'] == 0
assert aggregate['metadataSHA256'] == sha(metadata_path)
assert audit['bindings']['aggregate']['sha256'] == sha(aggregate_path)
assert audit['bindings']['metadata']['sha256'] == sha(metadata_path)
unsafe_actions = unsafe_summaries = 0
for model in ('qwen35', 'small', 'balanced'):
    counter = audit['reviewCounters'][model]
    assert counter['requiredReviews'] == counter['reviewed'] == 40
    assert {k: v for k, v in aggregate['models'][model].items() if k != 'binding'} == counter
    unsafe_actions += counter['unsafeAcceptedActions']
    unsafe_summaries += counter['unsafeAcceptedSummaries']
    assert metadata['exitCodes'][model] in (0, 1)
    stream = metadata_path.with_name(model + '.jsonl')
    assert sha(stream) == metadata['reportSHA256'][model]
assert ('PASS' if not unsafe_actions and not unsafe_summaries else 'BLOCKED') == audit['supplementalAcceptedSourceSafetyConditionOnly']
consumer_path = verify(selection['actualConsumerSchemaProof'])
consumer = read(consumer_path)
assert consumer['actualIndependentAudit']['sha256'] == sha(audit_path)
assert consumer['aggregate']['sha256'] == sha(aggregate_path)
assert consumer['finalOptionalGateFreezeHeldoutAuthorizationDefaultPromotionOrReady'] is False
summary = {
    'schemaVersion': 1, 'checkedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceCommit': selection['sourceCommit'], 'testedAppCommit': selection['testedAppCommit'],
    'docsPublicationCommit': selection['docsPublicationCommit'], 'selectionSHA256': args.selection_sha256,
    'fileCount': len(names), 'totalUncompressedBytes': selection['totalUncompressedBytes'],
    'rows': 120, 'reviewed': 120, 'pending': 0, 'reviewCounters': audit['reviewCounters'],
    'nativeLimitedFixtureSummary': metadata['summary'], 'actualModelQualityExitCodes': metadata['exitCodes'],
    'supplementalAcceptedSourceSafetyConditionOnly': audit['supplementalAcceptedSourceSafetyConditionOnly'],
    'unsafeAcceptedActions': unsafe_actions, 'unsafeAcceptedSummaries': unsafe_summaries,
    'previousArchives01To32VerifiedUnchanged': True, 'externalExcluded': selection['externalExcluded'],
    'scope': selection['selectedScope'], 'noCurrentDocsHeadCIOrHeldoutOutputIncluded': True,
    'noModelIQCreditForApplicationRecoveryOrConstrainedSourceLiterals': True,
    'newScorerTestsModelsNetworkSourceEditsOrHeldoutInvoked': False,
    'builderSHA256': sha(Path(__file__)), 'zipBuilt': bool(args.build),
}
if args.check_only:
    destination = OUT / 'preflight.json'
    assert not destination.exists()
    destination.open('x', encoding='utf-8', newline='\n').write(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'preflight': str(destination), 'sha256': sha(destination), 'files': len(names)}))
else:
    destination = OUT / 'development-evidence-33.zip'
    manifest = {'schemaVersion': 1, 'evidenceFiles': selection['files'], 'selectedEvidenceCount': len(names),
                'selectionSHA256': args.selection_sha256, 'summary': summary}
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    assert not destination.exists() and not (OUT / 'summary-33.json').exists()
    with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for reference in selection['files']:
            archive.write(verify(reference), reference['source'])
        archive.write(args.selection, 'archive33-selection.json')
        archive.write(Path(__file__), 'archive33-builder.py')
        archive.writestr('manifest.json', manifest_raw)
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None and len(archive.infolist()) == len(names) + 3
    summary.update(archiveSHA256=sha(destination), archiveBytes=destination.stat().st_size,
                   archiveMembers=len(names) + 3, manifestSHA256=hashlib.sha256(manifest_raw).hexdigest())
    (OUT / 'summary-33.json').open('x', encoding='utf-8', newline='\n').write(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'archive': str(destination), 'sha256': sha(destination), 'bytes': destination.stat().st_size, 'members': len(names) + 3}))
