"""Root-only bounded Archive36 ZIP; copies original bytes, never evaluates models."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import zipfile
import archive36_common as A

OUT = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--selection', type=Path, required=True); p.add_argument('--selection-sha256', required=True)
mode = p.add_mutually_exclusive_group(required=True)
mode.add_argument('--check-only', action='store_true'); mode.add_argument('--build', action='store_true')
p.add_argument('--root-reviewed-build-go', action='store_true')
args = p.parse_args(); assert not args.build or args.root_reviewed_build_go
selection = A.pinned(args.selection, args.selection_sha256)
assert selection['kind'] == 'complete-paired-and-all-suite-archive36-selection' and selection['finalSelection'] is True
assert selection['sourceHead'] == A.RELEASE and selection['modelSourceCommit'] == A.MODEL
assert selection['builderSHA256'] == A.sha(Path(__file__))
held, full, audit = [A.read_ref(selection['actualInputs'][role]) for role in ['heldout-bindings', 'all-suite-bindings', 'all-suite-pair-audit']]
assert A.complete_inputs(held, full, audit) == selection['optionalAllSuiteCondition']
assert audit['actualBindings']['sha256'] == selection['actualInputs']['all-suite-bindings']['sha256']
assert A.verify(audit['actualBindings']) == A.verify(selection['actualInputs']['all-suite-bindings'])
assert len(selection['files']) == selection['fileCount'] and 0 < selection['fileCount'] <= 1000
assert sum(v['bytes'] for v in selection['files']) == selection['totalUncompressedBytes'] <= 128 * 1024 * 1024
names = set()
for reference in selection['files']:
    path = A.verify(reference); name = reference['source']
    assert name not in names and not name.startswith('/') and '..' not in Path(name).parts
    assert A.payload_exclusion(path) is None
    names.add(name)
assert len(selection['previousArchives']) == 35
for reference in selection['previousArchives']:
    A.verify(reference)
for reference in selection['externalExcluded']:
    A.verify(reference)
    assert reference['source'] not in names and reference['includedInPayload'] is False and reference['originalBytesModified'] is False
core = list(selection['actualInputs'].values()) + list(A.walk_references(held)) + list(A.walk_references(full))
for role in ['baseline', 'candidate']:
    assembly = A.read_ref(full['phases'][role]['assemblyReceipt'])
    core.append(assembly['actualBindings'])
    core += list(A.walk_references(A.read_ref(assembly['actualBindings'])))
    core += list(A.walk_references(assembly['originalSplitReports']))
excluded_names = {v['source'] for v in selection['externalExcluded']}
for reference in core:
    path = A.verify(reference); name = A.reference(path)['source']
    assert name in (excluded_names if A.payload_exclusion(path) else names)
summary = {'schemaVersion': 1, 'checkedUTC': datetime.now(timezone.utc).isoformat(),
    'sourceHead': A.RELEASE, 'modelSourceCommit': A.MODEL, 'selectionSHA256': args.selection_sha256,
    'builderSHA256': A.sha(Path(__file__)), 'commonSHA256': A.sha(OUT / 'archive36_common.py'),
    'fileCount': len(names), 'totalUncompressedBytes': selection['totalUncompressedBytes'],
    'optionalAllSuiteCondition': selection['optionalAllSuiteCondition'], 'originalDefaultPromotionGate': selection['originalDefaultPromotionGate'],
    'actualInputs': selection['actualInputs'], 'previousArchives01To35VerifiedUnchanged': True,
    'retention': selection['retention'], 'externalExcluded': selection['externalExcluded'], 'scope': selection['scope'],
    'newModelsTestsScorerTransportSourceOrGitOperations': False, 'ReadyClaim': False, 'zipBuilt': bool(args.build)}
if args.check_only:
    output = OUT / 'preflight-36.json'
    with output.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'preflight': A.reference(output), 'files': len(names)}))
else:
    output, summary_path = OUT / 'development-evidence-36.zip', OUT / 'summary-36.json'
    assert not output.exists() and not summary_path.exists()
    manifest = (json.dumps({'schemaVersion': 1, 'selectionSHA256': args.selection_sha256,
        'evidenceFiles': selection['files'], 'selectedEvidenceCount': len(names), 'summary': summary}, ensure_ascii=False, indent=2) + '\n').encode()
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for reference in selection['files']:
            archive.write(A.verify(reference), reference['source'])
        archive.write(A.path_of(args.selection), 'archive36-selection.json')
        archive.write(Path(__file__), 'archive36-builder.py')
        archive.writestr('manifest.json', manifest)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        indexed = {v.filename: v for v in archive.infolist()}
        assert len(indexed) == len(archive.infolist()) == len(names) + 3
        for reference in selection['files']:
            raw = archive.read(reference['source'])
            assert len(raw) == reference['bytes'] and hashlib.sha256(raw).hexdigest() == reference['sha256']
    summary.update(archiveSHA256=A.sha(output), archiveBytes=output.stat().st_size,
                   archiveMembers=len(names) + 3, manifestSHA256=hashlib.sha256(manifest).hexdigest())
    with summary_path.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'archive': A.reference(output), 'summary': A.reference(summary_path), 'members': len(names) + 3}))
