#!/usr/bin/env python3
"""Preregister all fixed seeds for a diagnostic author-sampling approximation."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SEEDS = [1729, 2027, 4099]
CASE_IDS = ['prose.sky.en', 'prose.sky.fr-CA', 'control.soap_grease.en',
            'control.zipper.fr-CA', 'control.frost.en', 'control.sugar_dissolving.fr-CA']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--actor-copy-policy', type=Path, required=True)
    parser.add_argument('--focused-run', type=Path, required=True)
    parser.add_argument('--controls-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    manifest = json.loads(args.source_manifest.read_text(encoding='utf-8'))
    policy = json.loads(args.actor_copy_policy.read_text(encoding='utf-8'))
    assert policy['reverseEditsRecoverOriginalBytes'] is True
    assert policy['sourceArchiveSHA256'] == manifest['archiveSHA256']
    source_files = {entry['path']: entry['sha256'] for entry in manifest['files']}
    rows, identity, bindings = {}, None, []
    for phase in [args.focused_run, args.controls_run]:
        metadata_path = phase / 'metadata.json'
        metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
        assert metadata['complete'] is True
        assert all(source_files.get(name) == sha for name, sha in metadata['sourceSHA256'].items())
        current = {key: metadata[key] for key in ['sourceSHA256', 'runtimeFilesSHA256', 'models', 'executableSHA256', 'swiftVersion', 'platform', 'processor', 'logicalProcessors']}
        if identity is None:
            identity = current
        assert identity == current
        path = phase / 'qwen35.jsonl'
        assert digest(path) == metadata['resultSHA256']['qwen35']
        bindings.append({'phase': phase.name, 'model': 'qwen35', 'streamSHA256': digest(path), 'metadataSHA256': digest(metadata_path), 'suiteSHA256': metadata['suiteSHA256']})
        for line in path.read_text(encoding='utf-8').splitlines():
            row = json.loads(line)
            if row['caseID'] not in CASE_IDS:
                continue
            assert row['caseID'] not in rows
            assert row['model'] == 'qwen35' and row['kind'] == 'prose' and row['effort'] == 'standard' and row['repeatIndex'] == 0
            assert row['budget'] == 512 and not row.get('responseGrammar')
            prompt = row['prompt']
            assert prompt.endswith('<|im_start|>assistant\n<think>\n\n</think>\n\n')
            binding = next(item for item in metadata['promptSHA256']['qwen35'] if item['caseID'] == row['caseID'])
            assert hashlib.sha256(prompt.encode('utf-8')).hexdigest() == binding['prompt']
            rows[row['caseID']] = row
    assert set(rows) == set(CASE_IDS)
    original_actor = ROOT / 'HarbourRuntime/Sources/HarbourRuntime/LocalModel.swift'
    actor = ROOT / 'evaluation/sampling-system/Sources/SamplingDiagnostic/SamplingDiagnosticModel.swift'
    assert digest(original_actor) == policy['originalActorSHA256']
    assert digest(actor) == policy['diagnosticActorSHA256']
    recovered = actor.read_bytes().decode('utf-8')
    for edit in reversed(policy['edits']):
        assert recovered.count(edit['after']) == 1
        recovered = recovered.replace(edit['after'], edit['before'])
    assert recovered.encode('utf-8') == original_actor.read_bytes()
    diagnostic_paths = ['evaluation/sampling-system/Package.swift',
                        'evaluation/sampling-system/Sources/SamplingDiagnostic/main.swift',
                        'evaluation/sampling-system/Sources/SamplingDiagnostic/SamplingDiagnosticModel.swift',
                        'scripts/prepare-sampling-system.py', 'scripts/evaluate-sampling-system.py']
    registration = {
        'schemaVersion': 1, 'id': 'qwen35-author-sampling-approximation-v1',
        'preregisteredUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'releaseEvidence': False,
        'sourceHEAD': manifest['gitHEAD'], 'sourceScope': 'Exact reviewed working snapshot; not represented as a committed source',
        'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'sourceArchiveSHA256': manifest['archiveSHA256'],
        'sourceManifestSHA256': digest(args.source_manifest), 'sourceFilesSHA256': source_files,
        'originalSourceSHA256': identity['sourceSHA256'], 'runtimeFilesSHA256': identity['runtimeFilesSHA256'],
        'models': [item for item in identity['models'] if item['model'] == 'qwen35'],
        'sourceStreams': bindings, 'sourceRunIdentity': identity,
        'actorCopyPolicySHA256': digest(args.actor_copy_policy), 'actorCopyPolicy': policy,
        'diagnosticSourceSHA256': {name: digest(ROOT / name) for name in diagnostic_paths},
        'design': 'Exact current-source prepared prompts are unchanged. Only sampler construction differs in an isolated reversible actor copy; all three fixed seeds and all outputs are retained.',
        'officialRecommendation': 'https://huggingface.co/Qwen/Qwen3.5-2B',
        'pinnedSamplerSource': 'https://github.com/ggml-org/llama.cpp/blob/b10549/src/llama-sampler.cpp',
        'implementationLimit': 'The author card does not specify penalty history scope or sampler order. This llama.cpp generated-only history window and explicit chain are a bounded approximation, not a claim of exact framework equivalence.',
        'settings': {'context': 4096, 'batch': 512, 'physicalMicrobatch': 512, 'threads': 4, 'backend': 'Linux CPU',
                     'maxTokens': 512, 'grammar': None, 'stopAtJSON': False, 'thinking': 'canonical closed empty think prefix',
                     'temperature': 1.0, 'topP': 1.0, 'topK': 20, 'minP': 0.0, 'presencePenalty': 2.0, 'repetitionPenalty': 1.0, 'frequencyPenalty': 0.0,
                     'penaltyHistory': 'generated tokens only; positive512-token window covers every output token',
                     'chain': ['penalties', 'topK', 'temperature', 'seeded distribution'],
                     'noOps': ['topP1', 'minP0', 'repetition1', 'frequency0'],
                     'acceptance': 'llama_sampler_sample automatically accepts once; no prompt or manual output acceptance',
                     'seeds': SEEDS, 'order': ['qwen35'], 'repetitions': 3,
                     'processModelBoundaries': 'One fresh actor/model/context per seed; fresh sampler/history per request',
                     'promptFormat': 'qwen25 passthrough of already prepared canonical Qwen3.5 prompt'},
        'qualificationPolicy': 'Retain all18 results without selecting a favourable seed. All18 must pass completion, existing factual and language reviews to support further production investigation. This does not replace release gates, baseline comparisons or a production sampler change.',
        'reviewType': 'Output-bound qualitative AI review; no human subject-matter validation implied',
        'completionPolicy': 'Nonempty complete final response required; actual generation stop cause remains unknown. Generated analysis or incomplete output receives no final-answer credit.',
        'cases': [{'id': case_id, 'language': rows[case_id]['language'], 'prompt': rows[case_id]['prompt'],
                   'preparedPromptSHA256': hashlib.sha256(rows[case_id]['prompt'].encode('utf-8')).hexdigest()} for case_id in CASE_IDS],
    }
    with args.output.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(registration, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'sha256': digest(args.output), 'cases': 6, 'seeds': SEEDS, 'plannedRows': 18}))


if __name__ == '__main__':
    main()
