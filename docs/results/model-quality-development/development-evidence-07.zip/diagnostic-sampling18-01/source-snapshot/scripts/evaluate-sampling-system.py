#!/usr/bin/env python3
"""Run all preregistered diagnostic sampler seeds without editing production runtime."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1_048_576), b''):
            value.update(block)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preregistration', type=Path, required=True)
    parser.add_argument('--models-directory', type=Path, required=True)
    parser.add_argument('--runtime-prefix', type=Path, required=True)
    parser.add_argument('--output-directory', type=Path, required=True)
    args = parser.parse_args()
    assert sys.platform == 'linux', 'Use the isolated native CPU evaluation image'
    registration = json.loads(args.preregistration.read_text(encoding='utf-8'))
    assert registration['releaseEvidence'] is False and len(registration['cases']) == 6
    assert registration['settings']['seeds'] == [1729, 2027, 4099]
    for name, expected in {**registration['sourceFilesSHA256'], **registration['diagnosticSourceSHA256']}.items():
        assert digest(ROOT / name) == expected, f'Source mismatch: {name}'
    prefix = args.runtime_prefix.resolve()
    assert {p.relative_to(prefix).as_posix(): digest(p) for p in sorted(prefix.rglob('*')) if p.is_file()} == registration['runtimeFilesSHA256']
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    subprocess.run([sys.executable, str(ROOT / 'scripts/cache-eval-models.py'), '--directory', str(args.models_directory), '--models', 'qwen35'], check=True)
    models = json.loads((args.models_directory / 'model-provenance.json').read_text(encoding='utf-8'))
    assert models == registration['models']
    environment = dict(os.environ, HARBOUR_LINUX_RUNTIME='1', HARBOUR_DEVICE_RUNTIME='0', SWIFT_DETERMINISTIC_HASHING='1',
                       PKG_CONFIG_PATH=str(prefix / 'lib/pkgconfig'), LD_LIBRARY_PATH=str(prefix / 'lib'))
    environment.pop('SDKROOT', None)
    package = ROOT / 'evaluation/sampling-system'
    subprocess.run(['swift', 'build', '--package-path', str(package), '--configuration', 'release', '--product', 'sampling-diagnostic', '--jobs', '4'], env=environment, check=True)
    binaries = subprocess.check_output(['swift', 'build', '--package-path', str(package), '--configuration', 'release', '--show-bin-path'], env=environment, text=True).strip()
    executable = Path(binaries) / 'sampling-diagnostic'
    metadata = {'schemaVersion': 1, 'complete': False, 'releaseEvidence': False,
                'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'preregistrationSHA256': digest(args.preregistration), 'sourceIdentitySHA256': registration['sourceIdentitySHA256'],
                'sourceFilesSHA256': registration['sourceFilesSHA256'], 'diagnosticSourceSHA256': registration['diagnosticSourceSHA256'],
                'runtimeFilesSHA256': registration['runtimeFilesSHA256'], 'models': models, 'settings': registration['settings'],
                'implementationLimit': registration['implementationLimit'], 'qualificationPolicy': registration['qualificationPolicy'],
                'platform': platform.platform(), 'processor': platform.processor(), 'logicalProcessors': os.cpu_count(),
                'swiftVersion': subprocess.check_output(['swift', '--version'], text=True).strip(),
                'executableSHA256': digest(executable), 'streams': {},
                'coldLoadMeaning': 'Actor/model/context initialization at each seed boundary; disk pages already read by hash verification.'}
    metadata_path = output / 'metadata.json'
    try:
        metadata_path.write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
        rows_path = output / 'qwen35.jsonl'
        spec = models[0]
        command = [str(executable), '--model', str(args.models_directory / spec['filename']), '--suite', str(args.preregistration), '--output', str(rows_path)]
        metadata['command'] = command
        with (output / 'qwen35.stdout.json').open('w') as stdout, (output / 'qwen35.stderr.log').open('w') as stderr:
            process = subprocess.run(command, env=environment, stdout=stdout, stderr=stderr)
        assert process.returncode == 0, f'Diagnostic process failed: exit{process.returncode}'
        rows = [json.loads(line) for line in rows_path.read_text(encoding='utf-8').splitlines() if line]
        expected = [(seed, case['id']) for seed in registration['settings']['seeds'] for case in registration['cases']]
        assert [(row['seed'], row['caseID']) for row in rows] == expected
        cases = {case['id']: case for case in registration['cases']}
        for row in rows:
            assert row['model'] == 'qwen35' and row['budget'] == 512 and row['stopAtJSON'] is False
            assert row['context'] == 4096 and row['batch'] == 512 and row['threads'] == 4 and row.get('grammar') is None
            assert hashlib.sha256(row['prompt'].encode('utf-8')).hexdigest() == cases[row['caseID']]['preparedPromptSHA256']
        metadata['streams']['qwen35'] = {'rows': 18, 'rowsSHA256': digest(rows_path),
                                        'stdoutSHA256': digest(output / 'qwen35.stdout.json'), 'stderrSHA256': digest(output / 'qwen35.stderr.log'),
                                        'generationErrors': sum(row.get('error') is not None for row in rows),
                                        'coldLoadBoundaries': [{'seed': row['seed'], 'caseID': row['caseID'], 'seconds': row['seconds']} for row in rows if row['coldLoad']],
                                        'manualCompletionFactualLanguageReviewsRequired': 18}
        metadata['complete'] = True
        print('Completed all18 sealed sampler diagnostic rows', flush=True)
    finally:
        metadata['finishedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        metadata_path.write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    print(output, flush=True)


if __name__ == '__main__':
    main()
