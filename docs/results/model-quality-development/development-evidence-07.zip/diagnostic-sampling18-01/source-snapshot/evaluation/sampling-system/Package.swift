// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "SamplingDiagnostic",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "sampling-diagnostic", targets: ["SamplingDiagnostic"])],
    dependencies: [.package(path: "../../HarbourRuntime")],
    targets: [.executableTarget(name: "SamplingDiagnostic", dependencies: [.product(name: "HarbourRuntime", package: "HarbourRuntime")])]
)
