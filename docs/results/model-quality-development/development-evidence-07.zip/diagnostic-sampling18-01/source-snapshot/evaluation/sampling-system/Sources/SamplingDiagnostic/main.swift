import Foundation
import HarbourRuntime

private struct DiagnosticCase: Decodable {
    let id: String
    let language: String
    let prompt: String
}
private struct DiagnosticSettings: Decodable { let seeds: [UInt32] }
private struct DiagnosticSuite: Decodable {
    let id: String
    let cases: [DiagnosticCase]
    let settings: DiagnosticSettings
}
private struct DiagnosticResult: Encodable {
    let caseID: String
    let kind = "qwen35_author_sampling_diagnostic"
    let model = "qwen35"
    let language: String
    let seed: UInt32
    let coldLoad: Bool
    let budget = 512
    let context = 4096
    let batch = 512
    let threads = max(1, min(4, ProcessInfo.processInfo.processorCount - 2))
    let grammar: String? = nil
    let stopAtJSON = false
    let sampler = "presence2 generated-only window512 -> topK20 -> temperature1 -> seeded distribution; topP1/minP0 are no-ops"
    let prompt: String
    var promptTokens: Int?
    var output = ""
    var seconds: Double = 0
    var error: String?
    let rawGenerationStopCause = "unknown: copied production actor returns text only"
    let completenessRequiresManualReview = true
}

@main private enum SamplingDiagnostic {
    static func main() async throws {
        var arguments = Array(CommandLine.arguments.dropFirst()), values: [String: String] = [:]
        while !arguments.isEmpty {
            let key = arguments.removeFirst()
            guard ["--model", "--suite", "--output"].contains(key), !arguments.isEmpty, values[key] == nil else {
                throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid or repeated argument: \(key)"])
            }
            values[key] = arguments.removeFirst()
        }
        guard let modelPath = values["--model"], let suitePath = values["--suite"], let outputPath = values["--output"] else {
            throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require model, suite and output"])
        }
        let suite = try JSONDecoder().decode(DiagnosticSuite.self, from: Data(contentsOf: URL(fileURLWithPath: suitePath)))
        guard suite.cases.count == 6, Set(suite.cases.map(\.id)).count == 6,
              suite.settings.seeds == [1729, 2027, 4099],
              suite.cases.allSatisfy({ ["en", "fr-CA"].contains($0.language) }) else {
            throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require six unique bilingual cases and the three preregistered seeds"])
        }
        let output = URL(fileURLWithPath: outputPath)
        try Data().write(to: output, options: .withoutOverwriting)
        let stream = try FileHandle(forWritingTo: output)
        defer { try? stream.close() }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        let model = URL(fileURLWithPath: modelPath)
        for seed in suite.settings.seeds {
            let actor = SamplingDiagnosticModel(useGPU: false, diagnosticSeed: seed)
            for (index, fixture) in suite.cases.enumerated() {
                guard fixture.prompt.hasSuffix("<|im_start|>assistant\n<think>\n\n</think>\n\n") else {
                    throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require canonical closed non-thinking prefix"])
                }
                let prepared = try ModelPromptFormat.qwen25.prepare(fixture.prompt)
                var result = DiagnosticResult(caseID: fixture.id, language: fixture.language, seed: seed, coldLoad: index == 0, prompt: prepared)
                let started = Date()
                do {
                    result.promptTokens = try await actor.tokenCount(file: model, prompt: fixture.prompt, promptFormat: .qwen25)
                    result.output = try await actor.generate(file: model, prompt: fixture.prompt, maxTokens: 512, grammar: nil, stopAtJSON: false, promptFormat: .qwen25)
                } catch { result.error = error.localizedDescription }
                result.seconds = Date().timeIntervalSince(started)
                try stream.write(contentsOf: encoder.encode(result) + Data([10]))
                FileHandle.standardError.write(Data("qwen35 diagnostic \(fixture.id) seed=\(seed) error=\(result.error ?? "none") seconds=\(String(format: "%.2f", result.seconds))\n".utf8))
            }
            await actor.unload()
        }
        FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject: ["suite": suite.id, "rows": 18, "complete": true, "releaseEvidence": false], options: [.sortedKeys]))
        FileHandle.standardOutput.write(Data([10]))
    }
}
