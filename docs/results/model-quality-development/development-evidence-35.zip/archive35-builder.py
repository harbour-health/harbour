"""Root-only Archive35: actual current-bba app PASS and protocol freeze.

The retained freeze does not authorize held-out execution. A distinct later GO
and live remote preflight remain necessary. No Ready or physical-device claim.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'build/archive-development-35'
HEAD = 'bba74d659eada0a6dcba834926973dc9d800e8bf'
MODEL_SOURCE = '0cbc0b0b9fa37347ca7af4d52d755c259f058a0c'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
read = lambda path: json.loads(Path(path).read_bytes())

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--selection', type=Path, required=True)
parser.add_argument('--selection-sha256', required=True)
mode = parser.add_mutually_exclusive_group(required=True)
mode.add_argument('--check-only', action='store_true')
mode.add_argument('--build', action='store_true')
parser.add_argument('--root-reviewed-build-go', action='store_true')
args = parser.parse_args()
assert not args.build or args.root_reviewed_build_go
assert sha(args.selection) == args.selection_sha256
selection = read(args.selection)
assert selection['sourceHead'] == HEAD and selection['modelSourceCommit'] == MODEL_SOURCE
assert selection['finalSelection'] is True and selection['currentAppGate'] == 'PASS_CURRENT_BBA_FULL_APP'
assert selection['fileCount'] == len(selection['files'])
assert selection['totalUncompressedBytes'] == sum(ref['bytes'] for ref in selection['files'])

def verify(ref):
    path = (ROOT / ref['source']).resolve()
    assert path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink()
    assert path.stat().st_size == ref['bytes'] and sha(path) == ref['sha256']
    return path

names = set()
private_address = '.'.join(str(n) for n in (100, 83, 225, 2)).encode()
for ref in selection['files']:
    path = verify(ref)
    raw = path.read_bytes()
    assert ref['source'] not in names and len(raw) < 8 * 1024 * 1024
    names.add(ref['source'])
    assert private_address not in raw
    assert path.suffix.lower() not in {'.zip', '.gz', '.tar', '.gguf', '.so', '.exe', '.mp4', '.mov', '.pyc', '.sqlite3'}
    assert not any(part in {'.build', 'Data'} or part.endswith(('.xcresult', '.app', '.xtoolsdk')) for part in path.parts)
    assert not raw.startswith((b'MZ', b'\x7fELF', b'GGUF'))
assert len(selection['previousArchives']) == 34
for ref in selection['previousArchives']:
    verify(ref)

audit = read(verify(selection['actualCurrentAppAudit']))
assert audit['result'] == 'PASS_CURRENTBBA_ORIGINAL_CI_COUNTS_BYTES_TREE_COMPLETE_INPUT_AND_FINAL_PRESERVATION_ASSERTIONS'
assert audit['auditorSHA256'] == '8eaf5e6025e94c127315c0a4363bdbefd1b2903f23c2048d0a363342c5991b89'
assert audit['sourceHead'] == HEAD and audit['canonicalSourceInventoryFilesVerified'] == 135
assert audit['noOldPassImported'] is True
assert audit['nativeOriginalTestLogMatchesExactCurrentZIPMember'] is True
assert audit['currentInputAndAcknowledgementAssertionLines'] == {'exactInput':1427,'acknowledgement':1524,'recordsNavigation':1529,'finalMedicine':1530}
assert len(audit['EnglishFrenchExactInputBeforeSend']) == 4
for item in audit['EnglishFrenchExactInputBeforeSend'].values():
    assert item['oneTypingOperation'] and item['oneSendTap'] and item['exactValuePredicateObservedAfterTypingBeforeSend'] and item['completedExactValueWaitEstablishedByGuardSendAndTestPass']
assert len(audit['EnglishFrenchPreservation']) == 2
for item in audit['EnglishFrenchPreservation'].values():
    assert item['passed'] and item['finalMedicineAssertionReached'] and item['singleRecordsTap'] and item['sourceAllAcknowledgementNoDeleteFailureTextAndPreservationAssertionsRetained']
terminal = read(verify(selection['actualTerminal']))
assert terminal['sourceHead'] == HEAD and terminal['fullNativePassed'] is True
assert terminal['canonicalSourceManifestSHA256'] == selection['actualSourceManifest']['sha256']
for kind, run_id, ui, hosted in [('standard',38488871374,11,23),('native',38488871420,7,24)]:
    checked = audit['runs'][kind]
    run = next(row for row in terminal['runs'] if row['kind'] == kind)
    assert run['runID'] == checked['runID'] == run_id and run['conclusion'] == checked['conclusion'] == 'success'
    assert run['Core'] == {'executed':216,'passed':216,'failed':0} and run['Runtime'] == {'executed':21,'passed':21,'failed':0}
    assert run['counts'] == checked['counts'] == selection['observedCounts'][kind]
    assert run['counts']['UI'] == {'total':ui,'passed':ui,'failed':0,'skipped':0}
    assert run['counts']['hosted'] == {'total':hosted+1,'passed':hosted,'failed':0,'skipped':1}
    for artifact in checked['artifacts']:
        ref = artifact['binding']
        original = ROOT / ref['path']
        assert original.stat().st_size == ref['bytes'] and sha(original) == ref['sha256']
        assert artifact['APIReportedDigestMatchesDownloadedZIP'] and artifact['CRCAndAllMemberHashesPassed']

manifest = read(verify(selection['actualSourceManifest']))
assert manifest['sourceHead'] == HEAD and manifest['checkoutTreeEqualsHeadTree'] is True
assert len(manifest['files']) == len(selection['canonicalSourceFiles']) == 135
assert manifest['gitTree'] == audit['actualCheckoutTree']
for item in manifest['files']:
    ref = selection['canonicalSourceFiles'][item['path']]
    assert ref['bytes'] == item['bytes'] and ref['sha256'] == item['sha256']
    verify(ref)

freeze = read(verify(selection['actualFinalFreeze']))
freeze_audit = read(verify(selection['actualFinalFreezeIndependentAudit']))
assert freeze_audit['result'] == 'PASS_ACTUAL_FINAL_SOURCE15_FREEZE_CURRENT42_BINDINGS_ALIASES_AND_EXECUTION_SEPARATION'
assert freeze_audit['freeze']['sha256'] == selection['actualFinalFreeze']['sha256']
assert freeze['kind'] == 'root-final-source15-freeze' and freeze['sourceCommit'] == MODEL_SOURCE
assert freeze['releaseCommit'] == freeze['currentPublicationCommit'] == HEAD
assert freeze['finalSourceFreeze'] is True and freeze['rootAuthorizesPairedHeldout'] is True
assert freeze['heldoutExecutionAuthorized'] is False and freeze['separateHeldoutGORequired'] is True
assert freeze['baselineHeldoutPreviouslyExecuted'] is False
assert freeze['defaultModelPolicy'] == 'Automatic' and freeze['qwen35OptionalOnly'] is True
assert len(freeze['requiredEvidence']) == 42
assert freeze['requiredEvidence']['candidateAppReviewReceipt']['sha256'] == selection['actualTerminal']['sha256']
assert freeze['requiredEvidence']['candidateAppIndependentAudit']['sha256'] == selection['actualCurrentAppAudit']['sha256']
assert freeze['requiredEvidence']['candidateAppCanonicalSourceManifest']['sha256'] == selection['actualSourceManifest']['sha256']
for ref in freeze['requiredEvidence'].values():
    path = ROOT / ref['path']
    assert path.is_file() and path.stat().st_size == ref['bytes'] and sha(path) == ref['sha256']
for field in ('devReviewArtifactBindings','supplementalReviewArtifactBindings','productionProductArtifactBindings','historicalEvidenceNotCurrentAppCredit'):
    for ref in freeze[field].values():
        path = ROOT / ref['path']
        assert path.is_file() and path.stat().st_size == ref['bytes'] and sha(path) == ref['sha256']

summary = {'schemaVersion':1,'checkedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'sourceHead':HEAD,'modelSourceCommit':MODEL_SOURCE,'selectionSHA256':args.selection_sha256,
           'fileCount':len(names),'totalUncompressedBytes':selection['totalUncompressedBytes'],
           'observedCounts':selection['observedCounts'],'currentAppGate':'PASS_CURRENT_BBA_FULL_APP',
           'fourFullInputTracesAndTwoFinalMedicineAssertionsVerified':True,
           'actualFinalFreezeSHA256':selection['actualFinalFreeze']['sha256'],
           'heldoutExecutionAuthorized':False,'separateHeldoutGORequired':True,
           'previousArchives01To34VerifiedUnchanged':True,'scope':selection['selectedScope'],
           'externalExcluded':selection['externalExcluded'],'retentionLimits':selection['retentionLimits'],
           'modelRowsAndWholeCaptureIdentitiesNotRelabelledBba':True,'ReadyOrPhysicalDeviceClaimed':False,
           'newFreezeGOTestsModelsScorerCPUTransportNetworkHeldoutOrGitMutationInvokedByBuilder':False,
           'builderSHA256':sha(Path(__file__)),'zipBuilt':bool(args.build)}
if args.check_only:
    path = OUT / 'preflight.json'
    with path.open('x',encoding='utf-8',newline='\n') as handle:
        handle.write(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'preflight':str(path),'sha256':sha(path),'files':len(names)}))
else:
    path = OUT / 'development-evidence-35.zip'
    assert not path.exists() and not (OUT / 'summary-35.json').exists()
    manifest_raw = (json.dumps({'schemaVersion':1,'evidenceFiles':selection['files'],
                               'selectedEvidenceCount':len(names),'selectionSHA256':args.selection_sha256,
                               'summary':summary},ensure_ascii=False,indent=2)+'\n').encode()
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for ref in selection['files']:
            archive.write(verify(ref),ref['source'])
        archive.write(args.selection,'archive35-selection.json')
        archive.write(Path(__file__),'archive35-builder.py')
        archive.writestr('manifest.json',manifest_raw)
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.infolist()) == len(names)+3
    summary.update(archiveSHA256=sha(path),archiveBytes=path.stat().st_size,archiveMembers=len(names)+3,
                   manifestSHA256=hashlib.sha256(manifest_raw).hexdigest())
    with (OUT / 'summary-35.json').open('x',encoding='utf-8',newline='\n') as handle:
        handle.write(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'archive':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'members':len(names)+3}))
