// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "NeutralSystemDiagnostic",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "neutral-system-diagnostic", targets: ["NeutralSystemDiagnostic"])],
    dependencies: [.package(path: "../../HarbourRuntime")],
    targets: [.executableTarget(name: "NeutralSystemDiagnostic", dependencies: [.product(name: "HarbourRuntime", package: "HarbourRuntime")])]
)
