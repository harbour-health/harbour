import Foundation
import HarbourRuntime

private struct DiagnosticCase: Decodable {
    let id: String
    let language: String
    let prompt: String
}
private struct DiagnosticSuite: Decodable {
    let id: String
    let cases: [DiagnosticCase]
}
private struct DiagnosticResult: Encodable {
    let caseID: String
    let kind = "neutral_system_diagnostic"
    let model: String
    let language: String
    let coldLoad: Bool
    let budget = 512
    let context = 4096
    let batch = 512
    let threads = max(1, min(4, ProcessInfo.processInfo.processorCount - 2))
    let grammar: String? = nil
    let stopAtJSON = false
    let sampler = "production greedy"
    let prompt: String
    var promptTokens: Int?
    var output = ""
    var seconds: Double = 0
    var error: String?
}

@main private enum NeutralSystemDiagnostic {
    static func main() async throws {
        var arguments = Array(CommandLine.arguments.dropFirst()), values: [String: String] = [:]
        while !arguments.isEmpty {
            let key = arguments.removeFirst()
            guard ["--model", "--model-id", "--suite", "--output"].contains(key), !arguments.isEmpty, values[key] == nil else {
                throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid or repeated diagnostic argument: \(key)"])
            }
            values[key] = arguments.removeFirst()
        }
        guard let modelPath = values["--model"], let modelID = values["--model-id"],
              ["small", "balanced", "qwen35"].contains(modelID), let suitePath = values["--suite"], let outputPath = values["--output"] else {
            throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require model, model-id, suite and output"])
        }
        let suite = try JSONDecoder().decode(DiagnosticSuite.self, from: Data(contentsOf: URL(fileURLWithPath: suitePath)))
        guard suite.cases.count == 6, Set(suite.cases.map(\.id)).count == 6,
              suite.cases.allSatisfy({ ["en", "fr-CA"].contains($0.language) }) else {
            throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require six unique preregistered bilingual cases"])
        }
        let output = URL(fileURLWithPath: outputPath)
        try Data().write(to: output, options: .withoutOverwriting)
        let stream = try FileHandle(forWritingTo: output)
        defer { try? stream.close() }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        let actor = LocalModel(useGPU: false)
        let model = URL(fileURLWithPath: modelPath)
        let format: ModelPromptFormat = modelID == "qwen35" ? .qwen35 : .qwen25
        for (index, fixture) in suite.cases.enumerated() {
            let prepared = try format.prepare(fixture.prompt)
            var result = DiagnosticResult(caseID: fixture.id, model: modelID, language: fixture.language, coldLoad: index == 0, prompt: prepared)
            let started = Date()
            do {
                result.promptTokens = try await actor.tokenCount(file: model, prompt: fixture.prompt, promptFormat: format)
                result.output = try await actor.generate(file: model, prompt: fixture.prompt, maxTokens: 512, grammar: nil, stopAtJSON: false, promptFormat: format)
            } catch {
                result.error = error.localizedDescription
            }
            result.seconds = Date().timeIntervalSince(started)
            try stream.write(contentsOf: encoder.encode(result) + Data([10]))
            FileHandle.standardError.write(Data("\(modelID) diagnostic \(fixture.id) error=\(result.error ?? "none") seconds=\(String(format: "%.2f", result.seconds))\n".utf8))
        }
        await actor.unload()
        FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject: ["suite": suite.id, "rows": 6, "complete": true, "releaseEvidence": false], options: [.sortedKeys]))
        FileHandle.standardOutput.write(Data([10]))
    }
}
