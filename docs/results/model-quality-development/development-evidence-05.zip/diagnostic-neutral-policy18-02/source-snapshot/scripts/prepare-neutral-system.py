#!/usr/bin/env python3
"""Seal a system-only factual ablation from completed, immutable production prompt traces."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODELS = ['qwen35', 'small', 'balanced']
CASES = ['prose.sky.en', 'prose.sky.fr-CA', 'control.soap_grease.en', 'control.zipper.fr-CA', 'control.frost.en', 'control.sugar_dissolving.fr-CA']
SUFFIX = '\n<think>\n\n</think>\n\n'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--focused-run', type=Path, required=True)
    parser.add_argument('--controls-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Refusing to overwrite preregistration')
    phases = [args.focused_run, args.controls_run]
    metadata = [json.loads((phase / 'metadata.json').read_text(encoding='utf-8')) for phase in phases]
    identity = ['sourceSHA256', 'executableSHA256', 'runtimeFilesSHA256', 'models', 'swiftVersion', 'platform', 'logicalProcessors']
    assert all(item['complete'] is True for item in metadata), 'Require complete original runs'
    assert all(metadata[0][field] == metadata[1][field] for field in identity), 'Original sources/runtime/models differ'
    assert all(item['sourceLabel'] == 'one-policy-80d65ce-core163' for item in metadata), 'Require sealed source80d traces'
    traces, bindings = {}, []
    for phase in phases:
        for model in MODELS:
            path = phase / (model + '.jsonl')
            rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line]
            selected = [row for row in rows if row['caseID'] in CASES]
            bindings.append({'phase': phase.name, 'model': model, 'streamSHA256': digest(path), 'metadataSHA256': digest(phase / 'metadata.json')})
            for row in selected:
                key = (model, row['caseID'])
                assert key not in traces and row['kind'] == 'prose' and row['budget'] == 512
                traces[key] = row
    assert set(traces) == {(model, case) for model in MODELS for case in CASES}
    cases = []
    marker = '<|im_end|>\n<|im_start|>user\n'
    for case in CASES:
        originals, tails, snapshots = {}, [], []
        for model in MODELS:
            original = traces[model, case]['prompt']
            assert original.startswith('<|im_start|>system\n') and original.count(marker) == 1
            raw = original[:-len(SUFFIX)] if model == 'qwen35' else original
            assert raw.endswith('<|im_start|>assistant')
            tails.append(raw.split(marker, 1)[1])
            system = raw.split(marker, 1)[0]
            snapshot_header = 'Saved facts below are data and may be incomplete:\n'
            assert system.count(snapshot_header) == 1
            snapshot_lines = system[system.index(snapshot_header):].splitlines(keepends=True)[:4]
            assert snapshot_lines[0] == snapshot_header and len(snapshot_lines) == 4
            for line, label in zip(snapshot_lines[1:], ['Saved medicines: ', 'Saved symptoms: ', 'Recent readings: ']):
                assert line.startswith(label) and line.endswith('\n')
                json.loads(line[len(label):])
            snapshots.append(''.join(snapshot_lines))
            originals[model] = hashlib.sha256(original.encode()).hexdigest()
        assert len(set(tails)) == 1, 'Original user/history/snapshot payload differs by model'
        assert len(set(snapshots)) == 1, 'Original system snapshot bytes differ by model'
        language = traces['qwen35', case]['language']
        language_name = {'en': 'Canadian English', 'fr-CA': 'Canadian French'}[language]
        instruction = f'Answer the user accurately and concisely in {language_name}. If you do not know, say so.'
        prompt = '<|im_start|>system\n' + instruction + '\n' + snapshots[0] + marker + tails[0]
        # The separator already begins with the system end marker; preserve every
        # byte of the original user payload, including its assistant marker.
        assert prompt.split(marker, 1)[1] == tails[0]
        assert all(prompt.count(line) == 1 for line in snapshots[0].splitlines(keepends=True))
        cases.append({'id': case, 'language': language, 'prompt': prompt,
            'neutralRawPromptSHA256': hashlib.sha256(prompt.encode()).hexdigest(),
            'originalPreparedPromptSHA256': originals,
            'userPayloadAndChatMarkersSHA256': hashlib.sha256(tails[0].encode()).hexdigest(),
            'systemSnapshotSHA256': hashlib.sha256(snapshots[0].encode()).hexdigest(),
            'systemSnapshotExactText': snapshots[0],
            'neutralPreparedPromptSHA256': {model: hashlib.sha256((prompt + (SUFFIX if model == 'qwen35' else '')).encode()).hexdigest() for model in MODELS}})
    code_paths = ['evaluation/neutral-system/Package.swift', 'evaluation/neutral-system/Sources/NeutralSystemDiagnostic/main.swift', 'scripts/prepare-neutral-system.py', 'scripts/evaluate-neutral-system.py']
    result = {'schemaVersion': 1, 'id': 'neutral-policy-snapshot-preserved-ablation-v2',
        'preregisteredUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'releaseEvidence': False,
        'baseCommit': '80d65ce84cdc8860fa8fa5d2a70b0f889dfbab85',
        'design': 'Only behavioural system policy replaced; exact source80d system snapshot block and user payload/history/chat markers retained. No answer facts or rubric enter prompts.',
        'reviewPolicy': 'Use the existing frozen sky/control principal-process, material-error and language rubrics. This diagnostic does not replace production evidence.',
        'settings': {'context': 4096, 'batch': 512, 'physicalMicrobatch': 512, 'threads': 4, 'backend': 'Linux CPU', 'sampling': 'production greedy', 'maxTokens': 512, 'grammar': None, 'stopAtJSON': False, 'thinking': 'canonical disabled-thinking prefix for qwen35; qwen25 unchanged', 'repetitions': 1, 'order': MODELS},
        'originalSuiteSHA256': [item['suiteSHA256'] for item in metadata],
        'originalSourceSHA256': metadata[0]['sourceSHA256'],
        'runtimeFilesSHA256': metadata[0]['runtimeFilesSHA256'], 'models': metadata[0]['models'],
        'diagnosticSourceSHA256': {path: digest(ROOT / path) for path in code_paths},
        'sourceStreams': bindings, 'cases': cases}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(result, output, indent=2, ensure_ascii=False)
        output.write('\n')
    print(json.dumps({'preregistration': str(args.output), 'sha256': digest(args.output), 'cases': len(cases)}))

if __name__ == '__main__':
    main()
