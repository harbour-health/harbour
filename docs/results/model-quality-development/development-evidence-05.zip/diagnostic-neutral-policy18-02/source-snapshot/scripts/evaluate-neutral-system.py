#!/usr/bin/env python3
"""Run a sealed system-only diagnostic through the unchanged production CPU actor."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1_048_576), b''):
            value.update(block)
    return value.hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preregistration', type=Path, required=True)
    parser.add_argument('--models-directory', type=Path, required=True)
    parser.add_argument('--runtime-prefix', type=Path, required=True)
    parser.add_argument('--output-directory', type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != 'linux':
        parser.error('Run inside the isolated native CPU evaluation image')
    registration = json.loads(args.preregistration.read_text(encoding='utf-8'))
    assert registration['releaseEvidence'] is False and len(registration['cases']) == 6
    for path, expected in {**registration['originalSourceSHA256'], **registration['diagnosticSourceSHA256']}.items():
        assert digest(ROOT / path) == expected, f'Source mismatch: {path}'
    prefix = args.runtime_prefix.resolve()
    assert {str(path.relative_to(prefix)): digest(path) for path in sorted(prefix.rglob('*')) if path.is_file()} == registration['runtimeFilesSHA256'], 'Pinned runtime mismatch'
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    subprocess.run([sys.executable, str(ROOT / 'scripts/cache-eval-models.py'), '--directory', str(args.models_directory), '--models', *registration['settings']['order']], check=True)
    models = json.loads((args.models_directory / 'model-provenance.json').read_text(encoding='utf-8'))
    assert sorted(models, key=lambda item: item['model']) == sorted(registration['models'], key=lambda item: item['model'])
    env = dict(os.environ, HARBOUR_LINUX_RUNTIME='1', HARBOUR_DEVICE_RUNTIME='0', SWIFT_DETERMINISTIC_HASHING='1', PKG_CONFIG_PATH=str(prefix / 'lib/pkgconfig'), LD_LIBRARY_PATH=str(prefix / 'lib'))
    env.pop('SDKROOT', None)
    package = ROOT / 'evaluation/neutral-system'
    subprocess.run(['swift', 'build', '--package-path', str(package), '--configuration', 'release', '--product', 'neutral-system-diagnostic', '--jobs', '4'], env=env, check=True)
    binaries = subprocess.check_output(['swift', 'build', '--package-path', str(package), '--configuration', 'release', '--show-bin-path'], env=env, text=True).strip()
    executable = Path(binaries) / 'neutral-system-diagnostic'
    metadata = {'schemaVersion': 1, 'complete': False, 'releaseEvidence': False,
        'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'preregistrationSHA256': digest(args.preregistration), 'baseCommit': registration['baseCommit'],
        'diagnosticSourceSHA256': registration['diagnosticSourceSHA256'], 'originalSourceSHA256': registration['originalSourceSHA256'],
        'runtimeFilesSHA256': registration['runtimeFilesSHA256'], 'models': models, 'settings': registration['settings'],
        'platform': platform.platform(), 'logicalProcessors': os.cpu_count(), 'swiftVersion': subprocess.check_output(['swift', '--version'], text=True).strip(),
        'executableSHA256': digest(executable), 'streams': {},
        'coldLoadMeaning': 'Actor/model/context initialization in each fresh process; disk pages already read by SHA verification.'}
    metadata_path = output / 'metadata.json'
    try:
        for model in registration['settings']['order']:
            metadata_path.write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
            spec = next(item for item in models if item['model'] == model)
            rows_path = output / (model + '.jsonl')
            command = [str(executable), '--model', str(args.models_directory / spec['filename']), '--model-id', model, '--suite', str(args.preregistration), '--output', str(rows_path)]
            with (output / (model + '.stdout.json')).open('w') as stdout, (output / (model + '.stderr.log')).open('w') as stderr:
                process = subprocess.run(command, env=env, stdout=stdout, stderr=stderr)
            assert process.returncode == 0, f'Diagnostic process failed: {model} exit {process.returncode}'
            rows = [json.loads(line) for line in rows_path.read_text(encoding='utf-8').splitlines() if line]
            assert [row['caseID'] for row in rows] == [case['id'] for case in registration['cases']]
            assert all(row['model'] == model and row['budget'] == 512 and row['stopAtJSON'] is False for row in rows)
            assert all(row['context'] == 4096 and row['batch'] == 512 and row['threads'] == 4 and row.get('grammar') is None for row in rows)
            for row, case in zip(rows, registration['cases']):
                assert hashlib.sha256(row['prompt'].encode()).hexdigest() == case['neutralPreparedPromptSHA256'][model]
            metadata['streams'][model] = {'rows': 6, 'rowsSHA256': digest(rows_path), 'stdoutSHA256': digest(output / (model + '.stdout.json')), 'stderrSHA256': digest(output / (model + '.stderr.log')), 'generationErrors': sum(row.get('error') is not None for row in rows)}
            print(f'Completed sealed neutral diagnostic: {model}: 6 rows', flush=True)
        metadata['complete'] = True
    finally:
        metadata['finishedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        metadata_path.write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    print(output, flush=True)

if __name__ == '__main__':
    main()
