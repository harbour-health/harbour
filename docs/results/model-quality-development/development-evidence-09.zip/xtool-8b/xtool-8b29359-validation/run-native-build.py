import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

cache = Path(__file__).resolve().parent
workspace = cache / 'workspace'
manifest = json.loads((cache / 'source-manifest.json').read_text(encoding='utf-8'))
for item in manifest['files']:
    assert hashlib.sha256((workspace / item['path']).read_bytes()).hexdigest() == item['sha256']
for package, count in [('HarbourCore', 178), ('HarbourRuntime', 21)]:
    result = json.loads((workspace / (package + '-test-result.json')).read_text(encoding='utf-8'))
    assert result['exitCode'] == 0 and result['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
    assert f'Executed {count} tests, with 0 failures' in (workspace / (package + '-swift-test.log')).read_text(encoding='utf-8')
command = [sys.executable, str(workspace / 'scripts/xtool-build.py'), '--configuration', 'release', '--xtool', str(cache / 'xtool-container.sh')]
start = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (cache / 'native-build.log').open('x', encoding='utf-8') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    previous = None
    for line in process.stdout:
        log.write(line)
        log.flush()
        if line != previous:
            print(line, end='', flush=True)
        previous = line
    code = process.wait()
report = {'schemaVersion': 1, 'complete': True, 'scope': 'Current-source8b arm64 iOS Release compilation, not model quality or final-release proof',
          'sourceCommit': manifest['sourceCommit'], 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
          'sourceArchiveSHA256': manifest['archiveSHA256'], 'command': command, 'exitCode': code,
          'startedUTC': started, 'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'elapsedSeconds': time.monotonic() - start,
          'logSHA256': hashlib.sha256((cache / 'native-build.log').read_bytes()).hexdigest(),
          'runnerSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'environmentReceiptSHA256': hashlib.sha256((cache / 'environment-reuse.json').read_bytes()).hexdigest(),
          'noAccountLoginProvisioningDeviceInstallationOrUpload': True,
          'signatureScope': 'xtool may apply local ad-hoc signatures; no developer-account signing is performed'}
(cache / 'native-build-result.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(code)
