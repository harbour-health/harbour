import hashlib
import json
from pathlib import Path

workspace = Path(__file__).resolve().parent.parent
directory = workspace / 'build/xtool-8b29359-validation'
purposes = {
    'source.tar.gz': 'Exact123-file committed-source materialization; actual CRLF bytes preserved',
    'source-manifest.json': 'Source archive/inventory identity and scope',
    'HarbourCore-swift-test.log': 'Fresh178-test Release log',
    'HarbourCore-test-result.json': 'Bound Core test command, source, exit and log metadata',
    'HarbourRuntime-swift-test.log': 'Fresh21-test Release log against pinned Linux CPU runtime',
    'HarbourRuntime-test-result.json': 'Bound Runtime test command, source, exit and log metadata',
    'native-build.log': 'Fresh arm64 iOS Release cross-build log including existing compiler warnings',
    'native-build-result.json': 'Bound current-source8b build command and result',
    'environment-reuse.json': 'Verified SDK metadata, official xtool image and19-file pinned device runtime reuse',
    'prior-sdk-install-result.json': 'Original isolated SDK installation receipt; historical environment evidence only',
    'prior-native-build-02-result.json': 'Historical environment/build receipt preserved as context, not current-source result',
    'bundle-proof.json': 'Packaged Mach-O architecture, linking, metadata, resources, privacy and local ad-hoc signature inspection',
    'validation-status.json': 'Local hash/archive/result verification and explicit limitations',
    'run-core-runtime-tests.py': 'Exact fresh-test runner',
    'prepare-environment.py': 'Exact verified environment/runtime reuse preparation',
    'run-native-build.py': 'Exact fresh cross-build runner',
    'xtool-container.sh': 'Exact pinned official tool image/network-none build wrapper',
    'inspect-bundle.py': 'Standalone complete Mach-O/bundle inspector and ZIP generator',
    'verify-evidence.py': 'Exact local source/ZIP/log/result integrity verifier',
}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
status = json.loads((directory / 'validation-status.json').read_text(encoding='utf-8'))
entries = []
for name, purpose in purposes.items():
    path = directory / name
    entries.append({'source': path.relative_to(workspace).as_posix(),
                    'archivePath': 'xtool-8b29359-validation/' + name,
                    'bytes': path.stat().st_size, 'sha256': sha(path), 'purpose': purpose})
for name, purpose in [('capture-xtool-8b29359-source.py', 'Exact source-capture generator, requires original Git commit'),
                       ('prepare-xtool-8b29359-allowlist.py', 'Exact publishable-allowlist generator')]:
    path = workspace / 'build' / name
    entries.append({'source': path.relative_to(workspace).as_posix(),
                    'archivePath': 'xtool-8b29359-validation/' + name,
                    'bytes': path.stat().st_size, 'sha256': sha(path), 'purpose': purpose})
app = directory / 'Harbour-8b29359.app.zip'
assert sha(app) == status['bundle']['zip']['sha256']
report = {'schemaVersion': 1, 'scope': 'Compact publishable current-source8b build/test evidence allowlist only; no publication or commit performed',
          'sourceCommit': status['sourceCommit'], 'sourceIdentitySHA256': status['sourceIdentitySHA256'],
          'validationStatusSHA256': sha(directory / 'validation-status.json'),
          'files': entries, 'fileCount': len(entries), 'totalUncompressedBytes': sum(item['bytes'] for item in entries),
          'excluded': [{'source': app.relative_to(workspace).as_posix(), 'bytes': app.stat().st_size,
                        'sha256': sha(app), 'reason': 'Compiled app ZIP intentionally omitted from compact public proof; hash retained in bundle/status evidence'},
                       {'source': 'build/xtool-8b29359-validation/create-bundle-inspector.py',
                        'sha256': sha(directory / 'create-bundle-inspector.py'),
                        'reason': 'Historical template-based inspector generator unnecessary; complete standalone generated inspector included'}],
          'notEstablished': ['No model-quality or device-execution result', 'No validation of later calendar/course source fix',
                             '123 captured source files are not an exact compiler input list',
                             'Original SDK installation receipt and metadata hashes do not assert every SDK file was hashed']}
(directory / 'publishable-allowlist.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'files': report['fileCount'], 'totalBytes': report['totalUncompressedBytes'],
                  'allowlistSHA256': sha(directory / 'publishable-allowlist.json'), 'appZipExcludedSHA256': sha(app)}))
