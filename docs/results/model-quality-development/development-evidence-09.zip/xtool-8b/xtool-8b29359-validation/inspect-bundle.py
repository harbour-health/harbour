import hashlib,json,os,plistlib,stat,struct,zipfile
from pathlib import Path
cache=Path(__file__).resolve().parent
root=cache/'workspace'
app=root/'xtool/Harbour.app'

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def version(n):return f'{n>>16}.{(n>>8)&255}.{n&255}'
def cstring(data,offset):return data[offset:data.index(b'\0',offset)].decode('utf-8')
def macho(path):
    data=path.read_bytes()
    magic,cpu,subtype,filetype,count,size,flags,reserved=struct.unpack_from('<8I',data)
    assert magic==0xfeedfacf and cpu==0x0100000c
    result={'sha256':digest(path),'bytes':len(data),'architecture':'arm64','cpu_subtype':subtype,'file_type':filetype,'dependencies':[],'rpaths':[],'has_main_entry':False}
    offset=32
    for _ in range(count):
        cmd,cmdsize=struct.unpack_from('<2I',data,offset)
        if cmd==0x32:
            platform,minimum,sdk,ntools=struct.unpack_from('<4I',data,offset+8)
            result['build_version']={'platform':platform,'minimum_os':version(minimum),'sdk':version(sdk)}
        elif cmd==0x25:
            minimum,sdk=struct.unpack_from('<2I',data,offset+8)
            result['build_version']={'platform':2,'minimum_os':version(minimum),'sdk':version(sdk)}
        elif cmd in [0xc,0x80000018,0x8000001f,0x80000023,0xd]:
            nameoffset=struct.unpack_from('<I',data,offset+8)[0]
            name=cstring(data,offset+nameoffset)
            if cmd==0xd: result['install_name']=name
            else: result['dependencies'].append({'name':name,'weak':cmd==0x80000018})
        elif cmd==0x8000001c:
            result['rpaths'].append(cstring(data,offset+struct.unpack_from('<I',data,offset+8)[0]))
        elif cmd==0x80000028:result['has_main_entry']=True
        elif cmd==0x1d:
            start,length=struct.unpack_from('<2I',data,offset+8)
            signature=data[start:start+length]
            sig={'code_directories':[],'cms_payload_present':False,'entitlements':None}
            sigmagic,siglength,entries=struct.unpack_from('>3I',signature)
            assert sigmagic==0xfade0cc0
            for i in range(entries):
                slot,location=struct.unpack_from('>2I',signature,12+i*8)
                blobmagic,bloblength=struct.unpack_from('>2I',signature,location)
                blob=signature[location:location+bloblength]
                if blobmagic==0xfade0c02:
                    cdversion,cdflags=struct.unpack_from('>2I',blob,8)
                    identoffset=struct.unpack_from('>I',blob,20)[0]
                    teamoffset=struct.unpack_from('>I',blob,48)[0] if cdversion>=0x20200 and len(blob)>=52 else 0
                    sig['code_directories'].append({'identifier':cstring(blob,identoffset),'flags':cdflags,'adhoc':bool(cdflags&2),'team_id':cstring(blob,teamoffset) if teamoffset else None})
                elif blobmagic==0xfade7171:sig['entitlements']=plistlib.loads(blob[8:])
                elif slot==0x10000:sig['cms_payload_present']=bloblength>8
            result['signature']=sig
        offset+=cmdsize
    return result


manifest = json.loads((cache / 'source-manifest.json').read_text(encoding='utf-8'))
for item in manifest['files']:
    assert digest(root / item['path']) == item['sha256'], item['path']
build_result = json.loads((cache / 'native-build-result.json').read_text(encoding='utf-8'))
assert build_result['complete'] and build_result['exitCode'] == 0
assert build_result['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
info = plistlib.loads((app / 'Info.plist').read_bytes())
expected_info = plistlib.loads((root / 'build/xtool/Info.plist').read_bytes())
assert all(info.get(key) == value for key, value in expected_info.items())
expected_entitlements = plistlib.loads((root / 'Harbour/Harbour.entitlements').read_bytes())
required = ['Harbour', 'AppIcon.png', 'PrivacyInfo.xcprivacy',
            'en.lproj/Localizable.strings', 'en.lproj/InfoPlist.strings',
            'fr-CA.lproj/Localizable.strings', 'fr-CA.lproj/InfoPlist.strings',
            'Frameworks/llama.framework/llama', 'Frameworks/llama.framework/PrivacyInfo.xcprivacy']
assert all((app / name).is_file() for name in required)
files = {}
for file in sorted(app.rglob('*')):
    if file.is_file() and not file.is_symlink():
        files[file.relative_to(app).as_posix()] = {'bytes': file.stat().st_size, 'sha256': digest(file)}
report = {'schemaVersion': 1, 'complete': True,
          'scope': 'Current-source8b arm64 iOS Release bundle inspection; no device execution or model-quality claim',
          'sourceCommit': manifest['sourceCommit'], 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
          'sourceArchiveSHA256': manifest['archiveSHA256'], 'sourceInventoryScope': manifest['scope'],
          'sourceInventoryFilesVerified': len(manifest['files']),
          'nativeBuildResultSHA256': digest(cache / 'native-build-result.json'),
          'environmentReceiptSHA256': digest(cache / 'environment-reuse.json'),
          'inspectorSHA256': digest(Path(__file__)),
          'app': macho(app / 'Harbour'), 'runtime': macho(app / 'Frameworks/llama.framework/llama'),
          'infoPlist': info, 'sourceEntitlements': expected_entitlements, 'files': files,
          'embeddedMobileProvision': (app / 'embedded.mobileprovision').exists(),
          'appPrivacy': plistlib.loads((app / 'PrivacyInfo.xcprivacy').read_bytes()),
          'runtimePrivacy': plistlib.loads((app / 'Frameworks/llama.framework/PrivacyInfo.xcprivacy').read_bytes())}
assert report['app']['file_type'] == 2 and report['app']['has_main_entry']
assert report['app']['build_version']['platform'] == 2
assert report['runtime']['build_version']['platform'] == 2
assert report['app']['build_version']['minimum_os'] == '18.0.0'
assert report['app']['signature']['entitlements'] == expected_entitlements
assert expected_entitlements['com.apple.developer.healthkit'] is True
assert all(c['adhoc'] and c['team_id'] is None for c in report['app']['signature']['code_directories'])
assert not report['app']['signature']['cms_payload_present'] and not report['embeddedMobileProvision']
assert '@executable_path/Frameworks' in report['app']['rpaths']
assert any(d['name'] == '@rpath/llama.framework/llama' for d in report['app']['dependencies'])
source_runtime_privacy = root / 'HarbourRuntime/Vendor/llama-device.xcframework/ios-arm64/llama.framework/PrivacyInfo.xcprivacy'
assert digest(app / 'Frameworks/llama.framework/PrivacyInfo.xcprivacy') == digest(source_runtime_privacy)
archive = cache / 'Harbour-8b29359.app.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(app.rglob('*')):
        relative = 'Harbour.app/' + path.relative_to(app).as_posix()
        if path.is_symlink():
            item = zipfile.ZipInfo(relative)
            item.create_system = 3
            item.external_attr = (stat.S_IFLNK | 0o777) << 16
            output.writestr(item, os.readlink(path))
        elif path.is_file():
            output.write(path, relative)
report['zip'] = {'filename': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive)}
(cache / 'bundle-proof.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'scope': report['scope'], 'sourceCommit': report['sourceCommit'],
                  'sourceInventoryFilesVerified': report['sourceInventoryFilesVerified'],
                  'app': report['app'], 'runtime': report['runtime'], 'resources': list(files), 'zip': report['zip']},
                 indent=2, ensure_ascii=False))
