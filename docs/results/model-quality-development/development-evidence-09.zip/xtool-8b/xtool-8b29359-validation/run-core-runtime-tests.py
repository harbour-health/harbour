import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

workspace = Path(__file__).resolve().parent
manifest_path = workspace / 'source-manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
for entry in manifest['files']:
    data = (workspace / entry['path']).read_bytes()
    assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
environment = dict(os.environ, HARBOUR_LINUX_RUNTIME='1', HARBOUR_DEVICE_RUNTIME='0', SWIFT_DETERMINISTIC_HASHING='1', PKG_CONFIG_PATH='/evalcache/linux-runtime-v2/lib/pkgconfig', LD_LIBRARY_PATH='/evalcache/linux-runtime-v2/lib')
environment.pop('SDKROOT', None)
for package in ('HarbourCore', 'HarbourRuntime'):
    log = workspace / (package + '-swift-test.log')
    report_path = workspace / (package + '-test-result.json')
    if log.exists() or report_path.exists():
        raise SystemExit('Refusing to overwrite test evidence')
    start = time.monotonic()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    command = ['swift', 'test', '--configuration', 'release', '--jobs', '4']
    with log.open('wb') as output:
        process = subprocess.run(command, cwd=workspace / package, env=environment, stdout=output, stderr=subprocess.STDOUT)
    report = {
        'schemaVersion': 1, 'complete': True, 'package': package,
        'startedUTC': started, 'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsedSeconds': time.monotonic() - start, 'exitCode': process.returncode,
        'command': command, 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
        'sourceArchiveSHA256': manifest['archiveSHA256'],
        'sourceManifestSHA256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        'logSHA256': hashlib.sha256(log.read_bytes()).hexdigest(),
        'runnerSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'swiftVersion': subprocess.check_output(['swift', '--version'], text=True).strip(),
        'testBinariesSHA256': {str(p.relative_to(workspace)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (workspace / package / '.build').rglob('*.xctest') if p.is_file()},
    }
    report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
    print(log.read_text(encoding='utf-8', errors='replace')[-1600:], flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
