import hashlib
import json
from pathlib import Path
import tarfile
import zipfile

root = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):
    return json.loads((root / name).read_text(encoding='utf-8'))
manifest = load('source-manifest.json')
assert sha(root / 'source.tar.gz') == manifest['archiveSHA256']
with tarfile.open(root / 'source.tar.gz') as archive:
    source = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
assert len(source) == len(manifest['files']) == 123
for item in manifest['files']:
    data = source[item['path']]
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
identity = [{key: item[key] for key in ['path', 'bytes', 'sha256']} for item in sorted(manifest['files'], key=lambda item: item['path'])]
assert hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == manifest['sourceIdentitySHA256']
tests = []
for package, count in [('HarbourCore', 178), ('HarbourRuntime', 21)]:
    result = load(package + '-test-result.json')
    log = root / (package + '-swift-test.log')
    assert result['exitCode'] == 0 and result['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
    assert sha(log) == result['logSHA256']
    assert f'Executed {count} tests, with 0 failures' in log.read_text(encoding='utf-8')
    tests.append({'package': package, 'passedTests': count, 'resultSHA256': sha(root / (package + '-test-result.json')), 'logSHA256': sha(log)})
build = load('native-build-result.json')
environment = load('environment-reuse.json')
proof = load('bundle-proof.json')
assert build['complete'] and build['exitCode'] == 0 and sha(root / 'native-build.log') == build['logSHA256']
assert build['runnerSHA256'] == sha(root / 'run-native-build.py')
assert build['environmentReceiptSHA256'] == proof['environmentReceiptSHA256'] == sha(root / 'environment-reuse.json')
assert proof['nativeBuildResultSHA256'] == sha(root / 'native-build-result.json')
assert proof['inspectorSHA256'] == sha(root / 'inspect-bundle.py')
assert all(item['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256'] for item in [build, environment, proof])
assert environment['priorSDKInstallResultSHA256'] == sha(root / 'prior-sdk-install-result.json')
app_zip = root / proof['zip']['filename']
assert sha(app_zip) == proof['zip']['sha256'] and app_zip.stat().st_size == proof['zip']['bytes']
with zipfile.ZipFile(app_zip) as archive:
    assert archive.testzip() is None
    for name, item in proof['files'].items():
        data = archive.read('Harbour.app/' + name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
result = {'schemaVersion': 1, 'complete': True, 'scope': 'Current-source8b fresh tests, arm64 iOS Release cross-build and bundle inspection; not model quality, physical-device execution, or final-source approval',
          'sourceCommit': manifest['sourceCommit'], 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
          'sourceArchiveSHA256': manifest['archiveSHA256'], 'sourceInventoryFilesVerified': len(source),
          'sourceInventoryScope': manifest['scope'], 'tests': tests,
          'nativeBuild': {'exitCode': build['exitCode'], 'elapsedSeconds': build['elapsedSeconds'], 'logSHA256': build['logSHA256']},
          'bundle': {'filesVerified': len(proof['files']), 'appSHA256': proof['app']['sha256'], 'runtimeSHA256': proof['runtime']['sha256'], 'zip': proof['zip']},
          'sdkScope': 'Installed iPhoneOS27 SDK metadata verified by reuse receipt; Mach-O load-command SDK field records18.0 for app and16.4 for pinned framework',
          'signatureScope': build['signatureScope'], 'verifierSHA256': sha(Path(__file__)),
          'limitations': ['Cross-compilation does not execute the app on a physical device or simulator',
                          'The123-file source inventory is broader than individual compiler input lists',
                          'No model inference or model-quality result is established by this build',
                          'Subsequent source fixes need their own correctness/build evidence'],
          'filesSHA256': {path.name: sha(path) for path in sorted(root.iterdir()) if path.is_file()}}
(root / 'validation-status.json').open('x', encoding='utf-8').write(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['complete', 'sourceCommit', 'sourceIdentitySHA256', 'tests', 'nativeBuild', 'bundle']}, indent=2))
