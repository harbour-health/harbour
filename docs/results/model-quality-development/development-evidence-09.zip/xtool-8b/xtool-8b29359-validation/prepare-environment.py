import hashlib
import json
from pathlib import Path
import shutil

cache = Path(__file__).resolve().parent
workspace = cache / 'workspace'
prior = Path('/tmp/harbour-xtool-validation.D7Kusi')


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            sha.update(block)
    return sha.hexdigest()


manifest = json.loads((cache / 'source-manifest.json').read_text(encoding='utf-8'))
assert manifest['sourceCommit'] == '8b29359e87a6e2f24f3e2fc7dcacc6d3d46798c2'
for entry in manifest['files']:
    assert digest(workspace / entry['path']) == entry['sha256'], entry['path']
app_image = prior / 'xtool-x86_64.AppImage'
assert digest(app_image) == 'e2277e59bb2fda9b487cbc77ad080ea2b0370bb740ac0f02cc42fa28a272d3a5'
runtime = prior / 'workspace/HarbourRuntime/Vendor/llama-device.xcframework'
marker = json.loads((runtime / '.harbour-device-runtime.json').read_text(encoding='utf-8'))
assert marker['runtimeBuild'] == 'b10549'
assert marker['archiveSHA256'] == '636709d4a7b49ac7f2ed6dc8a4de3f278c257cac7248fe40d6a513f671e4bff4'
for name, expected in marker['files'].items():
    assert digest(runtime / name) == expected, name
assert digest(runtime / 'ios-arm64/llama.framework/llama') == 'f8c32f64a9c74dda29978b9b7049f3484fd528e12229a80c2664f86c705aff9f'
target = workspace / 'HarbourRuntime/Vendor/llama-device.xcframework'
target.parent.mkdir(parents=True, exist_ok=True)
assert not target.exists()
shutil.copytree(runtime, target)
sdk = prior / 'config/swiftpm/swift-sdks/darwin.artifactbundle'
sdk_hashes = {name: digest(sdk / name) for name in ['info.json', 'swift-sdk.json', 'toolset.json']}
for name in ['sdk-install-result.json', 'xtool-validation.json', 'native-build-02-result.json']:
    source = prior / name
    if source.exists():
        (cache / ('prior-' + name)).open('xb').write(source.read_bytes())
receipt = {'formatVersion': 1, 'scope': 'Reuse existing isolated official xtool/SDK installation and verified pinned device framework; no new installation or download',
           'sourceCommit': manifest['sourceCommit'], 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
           'sourceArchiveSHA256': manifest['archiveSHA256'], 'sourceInventoryScope': manifest['scope'],
           'xtoolVersion': '1.21.0', 'xtoolAppImageSHA256': digest(app_image),
           'containerImage': 'ghcr.io/xtool-org/xtool:1.21.0@sha256:032d20a18c8015e49fa99fddfc4ba236795731fd8543d69971ff76d388e8430f',
           'existingSDKMetadataSHA256': sdk_hashes, 'priorSDKInstallResultSHA256': digest(prior / 'sdk-install-result.json'),
           'runtimeInputMarker': marker, 'runtimeInputMarkerSHA256': digest(runtime / '.harbour-device-runtime.json'),
           'noAccountLoginOrProvisioning': True, 'noDeviceInstallationOrUpload': True}
(cache / 'environment-reuse.json').open('x', encoding='utf-8').write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'sourceInventoryFilesVerified': len(manifest['files']), 'runtimeFilesVerified': len(marker['files']), 'SDKMetadataVerified': sdk_hashes}))
