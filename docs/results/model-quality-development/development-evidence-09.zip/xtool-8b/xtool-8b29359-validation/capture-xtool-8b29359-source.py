import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent.parent
commit = '8b29359e87a6e2f24f3e2fc7dcacc6d3d46798c2'
directory = root / 'build/xtool-8b29359-validation'
directory.mkdir(exist_ok=False)
paths = ['Package.swift', 'xtool.yml', 'Harbour', 'Harbour.xcodeproj', 'HarbourCore', 'HarbourRuntime',
         'HarbourTests', 'HarbourUITests', 'scripts', 'evaluation']
process = subprocess.run(['git', 'archive', '--format=tar', commit, *paths], cwd=root, stdout=subprocess.PIPE, check=True)
archive_path = directory / 'source.tar.gz'
with archive_path.open('xb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        compressed.write(process.stdout)
files = []
with tarfile.open(fileobj=io.BytesIO(process.stdout)) as archive:
    for member in archive.getmembers():
        if member.isfile():
            data = archive.extractfile(member).read()
            files.append({'path': member.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                          'CRLFCount': data.count(b'\r\n'), 'LFCount': data.count(b'\n')})
identity_files = [{key: item[key] for key in ['path', 'bytes', 'sha256']} for item in sorted(files, key=lambda item: item['path'])]
manifest = {'schemaVersion': 1, 'gitHEAD': commit, 'sourceCommit': commit,
            'scope': 'Current-source8b committed materialization for fresh Core/Runtime tests and arm64 iOS Release cross-build; source inventory is broader than each compiler input list.',
            'lineEndings': 'Actual git archive materialized bytes; no assumption of LF equivalence to raw Git blobs',
            'sourceIdentitySHA256': hashlib.sha256(json.dumps(identity_files, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'archiveSHA256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'files': files,
            'priorWorkingSource03Unchanged': True, 'priorHistoricalXtool108EvidenceUnchanged': True,
            'notEstablished': 'No physical-device execution, simulator execution or model quality evidence is established by this source capture.'}
(directory / 'source-manifest.json').open('x', encoding='utf-8').write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'commit': commit, 'files': len(files), 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'archiveSHA256': manifest['archiveSHA256']}))
