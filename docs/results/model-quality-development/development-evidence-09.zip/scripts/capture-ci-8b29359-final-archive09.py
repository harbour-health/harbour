import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent.parent
destination = root / 'build/ci-8b29359-final-archive09'
destination.mkdir(exist_ok=False)
run_id = 38336438685
commit = '8b29359e87a6e2f24f3e2fc7dcacc6d3d46798c2'
def fetch(endpoint, filename):
    output = subprocess.check_output(['gh', 'api', endpoint])
    (destination / filename).open('xb').write(output)
    return output
run = json.loads(fetch(f'repos/harbour-health/harbour/actions/runs/{run_id}', 'run-final.json'))
jobs = json.loads(fetch(f'repos/harbour-health/harbour/actions/runs/{run_id}/jobs?filter=latest&per_page=100', 'jobs-final.json'))
assert run['id'] == run_id and run['head_sha'] == commit and run['status'] == 'completed' and run['conclusion'] == 'success'
assert len(jobs['jobs']) == jobs['total_count']
log_info = []
for job in jobs['jobs']:
    assert job['run_id'] == run_id and job['head_sha'] == commit and job['status'] == 'completed'
    if job['conclusion'] == 'success':
        filename = f"job-{job['id']}.log"
        data = fetch(f"repos/harbour-health/harbour/actions/jobs/{job['id']}/logs", filename)
        log_info.append({'jobID': job['id'], 'name': job['name'], 'file': filename, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
receipt = {'schemaVersion': 1, 'capturedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'scope': 'Read-only final standard CI API/job/log receipt at8b; distinct from actual Native inference workflow and later current-source changes',
           'runID': run_id, 'runURL': run['html_url'], 'sourceCommit': commit, 'status': run['status'], 'conclusion': run['conclusion'],
           'jobs': [{'id': job['id'], 'name': job['name'], 'status': job['status'], 'conclusion': job['conclusion'], 'url': job['html_url']} for job in jobs['jobs']],
           'capturedLogs': log_info, 'generatorSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'filesSHA256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(destination.iterdir()) if path.is_file()},
           'noAPICredentialsOrResponseHeadersRetained': True, 'noBuildTestOrInferenceTriggered': True}
(destination / 'receipt.json').open('x', encoding='utf-8').write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'runID': run_id, 'conclusion': run['conclusion'], 'jobs': receipt['jobs'], 'logs': log_info}, indent=2))
