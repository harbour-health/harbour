import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent.parent
directory = root / 'build/ci-8b29359-final-archive09'
receipt = json.loads((directory / 'receipt.json').read_text(encoding='utf-8'))
run = json.loads((directory / 'run-final.json').read_text(encoding='utf-8'))
jobs = json.loads((directory / 'jobs-final.json').read_text(encoding='utf-8'))
logs = receipt['capturedLogs']
assert len(logs) == 1 and logs[0]['name'] == 'deterministic-tests'
log_path = directory / logs[0]['file']
data = log_path.read_bytes()
assert hashlib.sha256(data).hexdigest() == logs[0]['sha256']
text = data.decode('utf-8')
assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['head_sha'] == '8b29359e87a6e2f24f3e2fc7dcacc6d3d46798c2'
assert {(job['name'], job['conclusion']) for job in jobs['jobs']} == {('deterministic-tests', 'success'), ('model-accuracy', 'skipped')}
assert "Test Suite 'HarbourCorePackageTests.xctest' passed" in text and 'Executed 178 tests, with 0 failures' in text
assert "Test Suite 'HarbourRuntimePackageTests.xctest' passed" in text and 'Executed 21 tests, with 0 failures' in text
assert "Test Suite 'HarbourUITests.xctest' passed" in text and 'Executed 11 tests, with 0 failures' in text
assert "Test Suite 'HarbourTests.xctest' passed" in text and 'Executed 24 tests, with 1 test skipped and 0 failures' in text
cases = []
for match in re.finditer(r"Test Case '(-\[Harbour(?:UI)?Tests\.[^']+)' (passed|failed|skipped)", text):
    cases.append({'identifier': match.group(1), 'result': match.group(2)})
assert len({row['identifier'] for row in cases}) == len(cases) == 35
counts = {}
for name, prefix in [('hosted', '-[HarbourTests.'), ('UI', '-[HarbourUITests.')]:
    subset = [row for row in cases if row['identifier'].startswith(prefix)]
    counts[name] = {'total': len(subset), **{status: sum(row['result'] == status for row in subset) for status in ['passed', 'failed', 'skipped']}}
assert counts['hosted'] == {'total': 24, 'passed': 23, 'failed': 0, 'skipped': 1}
assert counts['UI'] == {'total': 11, 'passed': 11, 'failed': 0, 'skipped': 0}
report = {'schemaVersion': 1, 'scope': 'Final standard8b deterministic CI result; model-accuracy job skipped, not evaluated/passed',
          'runID': run['id'], 'runURL': run['html_url'], 'sourceCommit': run['head_sha'], 'conclusion': run['conclusion'],
          'deterministicTestsJob': 'success', 'modelAccuracyJob': 'skipped', 'coreTests': 178, 'runtimeTests': 21,
          'hosted': counts['hosted'], 'UI': counts['UI'], 'originalAppCases': cases,
          'receiptSHA256': hashlib.sha256((directory / 'receipt.json').read_bytes()).hexdigest(),
          'logFile': log_path.name, 'logSHA256': hashlib.sha256(data).hexdigest(),
          'verifierSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'notEstablished': 'No model-accuracy matrix, actual Qwen/Small Native inference cohort, or later Automatic/medical-safety-source validation'}
(directory / 'verified-counts.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ['runID', 'conclusion', 'deterministicTestsJob', 'modelAccuracyJob', 'coreTests', 'runtimeTests', 'hosted', 'UI']}, indent=2))
