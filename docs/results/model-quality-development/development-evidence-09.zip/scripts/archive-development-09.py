"""Build immutable archive09 from sealed allowlists after root review.

This script never builds, tests, infers, downloads, signs, installs, or publishes.
Use --check-only for a read-only preflight. Original08 and earlier records remain
unchanged. Source inventories preserve bytes and are not compiler-input lists.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import tarfile
from urllib.parse import urlparse
import zipfile

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / 'docs/results/model-quality-development'
COMMIT = '8b29359e87a6e2f24f3e2fc7dcacc6d3d46798c2'
ALLOWLISTS = [
    ('native-diagnostics', 'build/simulator-production-candidate/archive09-native-diagnostics-allowlist.json', '1771415b0331050816e86ab591dca8d5ea6e573d1f81ce91b0862090974944aa', 441),
    ('xtool-8b', 'build/xtool-8b29359-validation/publishable-allowlist.json', 'a0f367c5ff952bde1adc3f90bf09c807d24f6cc764b64631351d6ac3e800cbbb', 21),
    ('calendar-snapshot04', 'build/model-quality/visit-policy-correctness-04/publishable-allowlist.json', '7559c211efbb7f2cb64d0a6e66892fea1c4857b0ff8a9abba82f8c9104536110', 31),
]
SUPPLEMENTS = {
    'build/model-quality/calendar-scope-fix-01.patch': '328e5b5cfbfc58c917b5232f5c8e4fa76bc62fc88446a959e1ca27b6f288eb85',
    'build/model-quality/calendar-scope-fix-01-scope.json': '12f8ac453dcde4b801556daa852771b8753213522c7552e3b514468cb29db24a',
    'build/model-quality/calendar-scope-fix-02.patch': 'b117d9bedde8f3b9850913f269676837e21f2b352f2c7e432269892ad296cc60',
    'build/model-quality/calendar-scope-fix-02-scope.json': '561b6b798d50caa02e1137098694074d88aafd7b49596d70443b6d2caae30ca6',
    'docs/results/model-quality-development/development-archive-audit-08.json': '3620a19736a0ab7c3f2e9dd57b56990656f4abc219ab19919214e06c54991404',
    'docs/results/model-quality-development/summary-08.json': 'ba3c3363a44036c356f1cdbb017871fef47ec377af6b384f3be33b07fb221516',
    'build/ci-8b29359-final-archive09/run-final.json': '7ab6c9c87ed761ca55c608a8cacb2acfa06ca741baaf846ef3332b6867ee23e2',
    'build/ci-8b29359-final-archive09/jobs-final.json': '5a0b5a29e13599535552610f5ffe6708a52087e1b4cbeff86737a95e28b75afd',
    'build/ci-8b29359-final-archive09/receipt.json': '443dab61b859226de443c02bd0728d5cca08bb2e2ac351f2722035f09b69427b',
    'build/ci-8b29359-final-archive09/job-115097467713.log': 'fcfd690a7aee8bf6b342ecb909885964322b7e729719dd3e6b8e7fc791a303c0',
    'build/ci-8b29359-final-archive09/verified-counts.json': '92bb46332e9f3333bc32af8c2cfccb112f33854addea225a52264704be502b83',
}
FORBIDDEN_SUFFIXES = {'.gguf', '.xip', '.zip', '.so', '.dylib', '.a', '.dll', '.exe', '.mp4', '.mov', '.xcresult'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def safe_name(value):
    name = str(value).replace('\\', '/')
    posix, windows = PurePosixPath(name), PureWindowsPath(name)
    assert name and not posix.is_absolute() and not windows.is_absolute() and not windows.drive
    assert '..' not in posix.parts and '.' not in posix.parts and '\x00' not in name
    return posix.as_posix()

def source_file(value):
    name = safe_name(value)
    path = ROOT.joinpath(*PurePosixPath(name).parts)
    assert path.is_file() and not path.is_symlink(), 'Missing/symlink evidence: ' + name
    assert path.resolve().is_relative_to(ROOT.resolve()), 'Evidence escapes workspace: ' + name
    return path

def checked_data(path, expected_sha=None, expected_bytes=None):
    data = path.read_bytes()
    if expected_sha is not None:
        assert expected_sha == sha(data), 'Changed SHA256: ' + str(path)
    if expected_bytes is not None:
        assert isinstance(expected_bytes, int) and expected_bytes >= 0 and expected_bytes == len(data), 'Changed size: ' + str(path)
    return data

def json_file(name):
    return json.loads(source_file(name).read_text(encoding='utf-8'))

def assert_payload_safe(name, data):
    path = PurePosixPath(safe_name(name))
    assert path.suffix.lower() not in FORBIDDEN_SUFFIXES, 'Excluded binary/asset: ' + name
    assert not any(part.lower().endswith(('.app', '.xcresult')) or part == '.build' for part in path.parts)
    assert not data.startswith((b'\x7fELF', b'MZ', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'GGUF')), 'Compiled/model payload: ' + name
    if name.endswith('.jsonl'):
        assert all(json.loads(line).get('split') != 'heldout' for line in data.splitlines() if line), 'Heldout output: ' + name
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            for member in archive.getmembers():
                safe_name(member.name)
                assert member.isdir() or member.isfile(), 'Unexpected nested link/special member'
                if member.isfile():
                    assert_payload_safe(member.name, archive.extractfile(member).read())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    archive_path, summary_path = DEST / 'development-evidence-09.zip', DEST / 'summary-09.json'
    assert not archive_path.exists() and not summary_path.exists(), 'Immutable archive09/summary already exists'
    old_audit = json_file('docs/results/model-quality-development/development-archive-audit-08.json')
    previous = dict(old_audit['previousArchivesUnchanged'], **{'08': old_audit['archiveSHA256']})
    assert previous['08'] == '8997676469921003a6e4a112e3c120317382cc562cc5150f3646d4869b524a10'
    for number, expected in previous.items():
        assert sha(source_file(f'docs/results/model-quality-development/development-evidence-{number}.zip').read_bytes()) == expected

    files, sources, bindings, allowlists = {}, {}, [], {}
    def include(member, path, expected_sha=None, expected_bytes=None):
        member = safe_name(member)
        assert member != 'manifest.json' and member.casefold() not in {name.casefold() for name in files}, 'Duplicate member: ' + member
        data = checked_data(path, expected_sha, expected_bytes)
        assert len(data) <= 8 * 1024 * 1024, 'Oversized member requires explicit retention decision'
        assert_payload_safe(member, data)
        files[member], sources[member] = data, path

    for group, filename, expected_sha, expected_count in ALLOWLISTS:
        path = source_file(filename)
        data = checked_data(path, expected_sha)
        value = json.loads(data)
        assert len(value['files']) == expected_count
        declared_size = value['totalUncompressedBytes']
        assert sum(item['bytes'] for item in value['files']) == declared_size
        scope = value.get('preservationScope', value.get('scope'))
        assert isinstance(scope, str) and scope
        include(f'allowlists/{group}.json', path, expected_sha)
        for item in value['files']:
            source = item.get('relativePath', item.get('source'))
            member = group + '/' + item.get('archivePath', safe_name(source))
            include(member, source_file(source), item['sha256'], item['bytes'])
        bindings.append({'group': group, 'source': filename, 'sha256': expected_sha, 'retainedFiles': expected_count,
                         'declaredUncompressedBytes': declared_size, 'scope': scope})
        allowlists[group] = value
    for filename, expected in SUPPLEMENTS.items():
        include('supplements/' + safe_name(filename), source_file(filename), expected)
    for name in ['capture-ci-8b29359-final-archive09.py', 'verify-ci-8b29359-counts-archive09.py', 'archive-development-09.py']:
        include('scripts/' + name, source_file('build/' + name))

    # Keep native inference, routine standard CI, xtool and working snapshot04
    # cohorts separate. No success at one source/scope repairs another result.
    native = allowlists['native-diagnostics']
    production = native['productionProof']
    assert production['productionHEAD'] == COMMIT and production['conclusion'] == 'failure'
    assert production['CorePassed'] == 178 and production['RuntimePassed'] == 21
    assert production['actualUI'] == {'passed': 5, 'failed': 2, 'skipped': 0}
    assert production['hosted'] == {'passed': 24, 'skipped': 1, 'failed': 0}
    failure = json_file('build/native-ci-8b29359/native-failure-findings.json')
    proof = json_file('build/native-ci-8b29359/production-native-proof.json')
    assert failure['productionHEAD'] == proof['productionHEAD'] == COMMIT
    assert failure['smallFailureStageEvidence']['actualReply'] == 'Yes, you can take Advil and warfarin together.'
    assert proof['actualHostedPassedTestCount'] == 24 and proof['actualHostedSkippedTestCount'] == 1
    assert proof['xcresultSummary'] == {'result': 'Failed', 'totalTestCount': 32, 'passedTests': 29, 'failedTests': 2, 'skippedTests': 1}
    standard = json_file('build/ci-8b29359-final-archive09/verified-counts.json')
    receipt = json_file('build/ci-8b29359-final-archive09/receipt.json')
    assert standard['sourceCommit'] == receipt['sourceCommit'] == COMMIT and standard['conclusion'] == 'success'
    assert standard['deterministicTestsJob'] == 'success' and standard['modelAccuracyJob'] == 'skipped'
    assert standard['coreTests'] == 178 and standard['runtimeTests'] == 21
    assert standard['hosted'] == {'total': 24, 'passed': 23, 'failed': 0, 'skipped': 1}
    assert standard['UI'] == {'total': 11, 'passed': 11, 'failed': 0, 'skipped': 0}

    xtool = json_file('build/xtool-8b29359-validation/validation-status.json')
    xtool_manifest = json_file('build/xtool-8b29359-validation/source-manifest.json')
    xtool_build = json_file('build/xtool-8b29359-validation/native-build-result.json')
    assert xtool['complete'] and xtool['sourceCommit'] == COMMIT and xtool_build['exitCode'] == 0
    assert xtool['sourceIdentitySHA256'] == xtool_manifest['sourceIdentitySHA256'] == '461dba4f7f90df3b62809f6d8afae707b4b02f95562f7c192acbe2a87e398354'
    assert [(item['package'], item['passedTests']) for item in xtool['tests']] == [('HarbourCore', 178), ('HarbourRuntime', 21)]
    calendar = json_file('build/model-quality/visit-policy-correctness-04/validation-status.json')
    calendar_manifest = json_file('build/model-quality/visit-policy-correctness-04/source-manifest.json')
    assert calendar['complete'] and calendar['passed'] and calendar['nativeTotalPassed'] == 159
    assert calendar['sourceIdentitySHA256'] == calendar_manifest['sourceIdentitySHA256'] == 'f10fece3c34f3f5093946a09f9d86e09ea61b2caefc5d72d95547102b0db0aa0'
    assert [(item['package'], item['passed']) for item in calendar['tests']] == [('HarbourCore', 184), ('HarbourRuntime', 21)]
    assert calendar['sourceInventoryFilesVerified'] == 55 and len(calendar['specificScheduleScopeMethodsPassed']) == 6
    scope02 = json_file('build/model-quality/calendar-scope-fix-02-scope.json')
    preserved04 = {item['path']: item['sha256'] for item in calendar_manifest['files']}
    assert all(preserved04[name] == value for name, value in scope02['sourceSHA256'].items())
    for label, directory, current in [('xtool', 'build/xtool-8b29359-validation', xtool_manifest), ('calendar', 'build/model-quality/visit-policy-correctness-04', calendar_manifest)]:
        archive_name = 'source.tar.gz' if label == 'xtool' else 'working-source.tar.gz'
        archive_data = source_file(directory + '/' + archive_name).read_bytes()
        assert sha(archive_data) == current['archiveSHA256']
        with tarfile.open(fileobj=io.BytesIO(archive_data)) as archive:
            actual = {member.name: sha(archive.extractfile(member).read()) for member in archive.getmembers() if member.isfile()}
        assert actual == {item['path']: item['sha256'] for item in current['files']}

    external = []
    def reference(kind, url, digest, scope, **extra):
        assert isinstance(digest, str) and digest.removeprefix('sha256:') == digest[-64:]
        digest = digest.removeprefix('sha256:')
        assert len(digest) == 64 and all(letter in '0123456789abcdef' for letter in digest)
        assert urlparse(url).scheme == 'https' and urlparse(url).hostname in {'api.github.com', 'github.com', 'codeload.github.com', 'huggingface.co'}
        external.append({'kind': kind, 'url': url, 'sha256': digest, 'retainedInArchive': False, 'scope': scope, **extra})
    for run in native['previousDiagnosticArtifactReferences'] + native['readOnlyArchiveInspectionReferences']:
        for artifact in run['artifacts']:
            reference(artifact['name'], artifact['archiveDownloadURL'], artifact['digest'], 'Full original artifact ZIP not included; explicitly selected extracted text/source/metadata/PNG files may be retained.',
                      runID=run['runID'], runURL=run['runURL'], artifactID=artifact['id'], sizeBytes=artifact.get('sizeBytes'), expiredAtMetadataCapture=artifact.get('expiredAtMetadataCapture'))
    artifact = production['artifact']
    assert artifact['digestVerified'] and artifact['githubDigest'].removeprefix('sha256:') == artifact['downloadedZIP_SHA256']
    reference(artifact['name'], artifact['archiveDownloadURL'], artifact['githubDigest'], 'Original8b artifact with full XCResult preserved separately; binary artifact ZIP/XCResult not included in archive09.',
              runID=production['nativeRun'], runURL=production['nativeRunURL'], artifactID=artifact['artifactID'])
    native_metadata = json_file('build/model-quality/visit-policy-correctness-04/native159/metadata.json')
    for model in native_metadata['models']:
        assert model['verified']
        reference('Pinned ' + model['model'] + ' GGUF', model['url'], model['sha256'], 'Model weights excluded; prior native runner verification is bound in retained metadata, not a new download/quality evaluation.',
                  sizeBytes=model['bytes'], repository=model['repository'], revision=model['revision'])
    environment = json_file('build/xtool-8b29359-validation/environment-reuse.json')
    marker = environment['runtimeInputMarker']
    reference('Pinned device xcframework release', marker['source'], marker['archiveSHA256'], 'Original compiled release ZIP/framework files excluded; verified reuse of19 prepared device files is retained as metadata.')
    reference('Pinned Linux runtime source archive', native_metadata['runtime']['sourceURL'], native_metadata['runtime']['sourceSHA256'], 'Original llama.cpp source archive and compiled installed libraries excluded; exact source/runtime hashes and reproducible recipe retained.')
    excluded = allowlists['xtool-8b']['excluded']
    compiled_zip = next(item for item in excluded if item['source'].endswith('.app.zip'))
    assert compiled_zip['sha256'] == xtool['bundle']['zip']['sha256'] and compiled_zip['bytes'] == xtool['bundle']['zip']['bytes']
    assert not any(name.endswith('.app.zip') for name in files)
    omitted_local = [{'kind': 'Compiled8b arm64 app ZIP', 'sha256': compiled_zip['sha256'], 'bytes': compiled_zip['bytes'], 'retainedInArchive': False, 'scope': compiled_zip['reason']}]
    for name, path in sources.items():
        assert path.read_bytes() == files[name], 'Input changed during collection: ' + name
    assert sum(len(data) for data in files.values()) <= 64 * 1024 * 1024
    summary = {'formatVersion': 1, 'releaseEvidence': False, 'archive': archive_path.name, 'evidenceFiles': len(files),
               'previousArchivesUnchangedSHA256': previous, 'allowlistBindings': bindings,
               'standardCI8b': standard,
               'actualNativeInference8b': {'sourceCommit': COMMIT, 'runID': production['nativeRun'], 'runURL': production['nativeRunURL'], 'conclusion': 'failure',
                   'coreTests': 178, 'runtimeTests': 21, 'hosted': production['hosted'], 'UI': production['actualUI'],
                   'failedTests': production['failedUI'], 'EnglishAndFrenchScheduleControls': 'Passed exact two times/disabled Save/Cancel assertions; not aggregate Native success',
                   'FrenchFailure': failure['frenchNegationFailure'], 'SmallFailure': failure['smallFailureStageEvidence'],
                   'interpretationLimit': 'Completed unsourced affirmative reply observed; production raw tool/validation/fallback sequence was not logged, so route mechanism remains unknown',
                   'timingLimit': native['timingLimit']},
               'currentSourceXtool8b': {'sourceCommit': COMMIT, 'sourceIdentitySHA256': xtool['sourceIdentitySHA256'], 'sourceArchiveSHA256': xtool['sourceArchiveSHA256'],
                   'sourceInventoryFiles': 123, 'coreTests': 178, 'runtimeTests': 21, 'arm64IOSReleaseExitCode': 0, 'bundle': xtool['bundle'],
                   'scope': 'Fresh8b committed materialization; separate from source03 CPU model observations and later default/medical/calendar changes; no device execution',
                   'sdkScope': xtool['sdkScope'], 'signatureScope': xtool['signatureScope']},
               'restrictedCalendarWorkingSnapshot04': {'sourceIdentitySHA256': calendar['sourceIdentitySHA256'], 'sourceArchiveSHA256': calendar['sourceArchiveSHA256'],
                   'sourceInventoryFiles': 55, 'workingSourceBytes': True, 'coreTests': 184, 'runtimeTests': 21, 'nativeGrammarAndContextPassed': 159,
                   'nativePerModel': calendar['native'], 'scopeMethodsPassed': calendar['specificScheduleScopeMethodsPassed'],
                   'scope': 'Exact approved calendar/course working snapshot; not labelled committed/current Automatic or later medical-reply source; native checks are51grammar+2context/model, no quality cases'},
               'externalArtifactsNotRetained': external, 'omittedLocalCompiledArtifacts': omitted_local,
               'limits': ['Native8b actual inference workflow failed5/7 UI and remains failed despite standardCI/xtool correctness success.',
                          'StandardCI model-accuracy job was skipped, not completed/passed.',
                          'Source inventories preserve bytes; they are not per-file compiler input lists.',
                          'Selected raw/AX/PNG source evidence does not include full original artifact ZIP/XCResult binaries.',
                          'No current Automatic-default/medical-reply-safety source or unfinished experiment was captured.',
                          'No heldout output, new model-quality matrix, physical iPhone or unsampled performance evidence.',
                          'Historical scope JSONs remain unchanged; uncompiled at their capture is not contradicted by later separately bound snapshot04 proof.'],
               'builderSHA256': sha(Path(__file__).read_bytes())}
    manifest = {'formatVersion': 1, 'releaseEvidence': False, 'scope': 'Exact allowlisted current8b native/standard/xtool proof and separate restricted-calendar snapshot04 correctness; later source excluded',
                'previousArchivesUnchangedSHA256': previous, 'allowlistBindings': bindings,
                'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())},
                'externalArtifactsNotRetained': external, 'omittedLocalCompiledArtifacts': omitted_local,
                'excluded': ['GGUF weights', 'Compiled app/framework/executable/test binaries', 'Full original XCResult/artifact ZIPs', 'MP4/MOV recordings', 'Heldout generation outputs', 'Unfinished/current medical-reply/default source'],
                'builderSHA256': summary['builderSHA256']}
    if args.check_only:
        print(json.dumps({'checkOnly': True, 'evidenceFiles': len(files), 'uncompressedBytes': sum(len(data) for data in files.values()), 'externalArtifacts': len(external), 'builderSHA256': summary['builderSHA256']}))
        return
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            item = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0)); item.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(item, data)
        item = zipfile.ZipInfo('manifest.json', (1980, 1, 1, 0, 0, 0)); item.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(item, json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(files) + 1
        assert all(archive.read(name) == data for name, data in files.items())
    for number, expected in previous.items():
        assert sha(source_file(f'docs/results/model-quality-development/development-evidence-{number}.zip').read_bytes()) == expected
    summary.update(bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes()))
    summary_path.open('x', encoding='utf-8').write(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'bytes': summary['bytes'], 'sha256': summary['sha256'], 'evidenceFiles': len(files)}))

if __name__ == '__main__':
    main()
