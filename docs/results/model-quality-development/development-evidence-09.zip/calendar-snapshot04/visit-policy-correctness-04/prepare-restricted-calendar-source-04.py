import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'source-manifest.json').read_text(encoding='utf-8'))
archive_path = root / 'working-source.tar.gz'
assert manifest['sourceIdentitySHA256'] == 'f10fece3c34f3f5093946a09f9d86e09ea61b2caefc5d72d95547102b0db0aa0'
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == manifest['archiveSHA256'] == '5b94d744d0afbd6bfe42aadbb42a8fc84f72143916c3c85fb0dc4a289f439ae9'
expected = {item['path']: item for item in manifest['files']}
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    assert len(members) == len(expected) == 55
    for member in members:
        name = PurePosixPath(member.name)
        assert member.isfile() and member.name in expected
        assert not name.is_absolute() and '..' not in name.parts
        destination = root.joinpath(*name.parts)
        assert root in destination.resolve().parents and not destination.exists()
        data = archive.extractfile(member).read()
        assert len(data) == expected[member.name]['bytes'] and hashlib.sha256(data).hexdigest() == expected[member.name]['sha256']
    archive.extractall(root, filter='data')
for name, item in expected.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == item['sha256']
print(json.dumps({'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'sourceInventoryFilesVerified': len(expected)}))
