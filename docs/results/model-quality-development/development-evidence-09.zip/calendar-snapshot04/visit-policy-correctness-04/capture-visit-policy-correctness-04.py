import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[2]
destination = root / 'build/model-quality/visit-policy-correctness-04'
destination.mkdir(exist_ok=False)
selected = [root / 'Harbour/VisitsView.swift', root / 'Harbour/EvaluationView.swift']
for package in ('HarbourCore', 'HarbourRuntime'):
    selected.append(root / package / 'Package.swift')
    for directory in ('Sources', 'Tests'):
        selected.extend(path for path in (root / package / directory).rglob('*') if path.is_file())
selected.extend(root / name for name in ['scripts/evaluate-models.py', 'scripts/prepare-linux-runtime.py', 'scripts/cache-eval-models.py',
                                       'scripts/collect-model-evidence.py', 'scripts/model-eval/Dockerfile', 'evaluation/harbour-model-quality-v1.json'])
snapshots = [(path, path.read_bytes()) for path in sorted(selected)]
archive = destination / 'working-source.tar.gz'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as output:
            for path, data in snapshots:
                member = tarfile.TarInfo(path.relative_to(root).as_posix())
                member.size, member.mode, member.mtime = len(data), 0o644, 0
                output.addfile(member, io.BytesIO(data))
files = [{'path': path.relative_to(root).as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for path, data in snapshots]
assert all(path.read_bytes() == data for path, data in snapshots), 'Source changed during capture'
manifest = {'schemaVersion': 1, 'capturedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'gitHEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
            'gitStatus': subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True),
            'scope': 'Restricted-calendar exact working-source correctness snapshot04; preserved Core/Runtime Package/Sources/Tests and production visit callers, broader than each compiler input list',
            'lineEndings': 'Exact Windows working-tree bytes; no assumption of LF equivalence to Git blobs',
            'sourceIdentitySHA256': hashlib.sha256(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'archiveSHA256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': files,
            'expectedTests': {'HarbourCore': 184, 'HarbourRuntime': 21},
            'notEstablished': ['Not a committed-source label', 'No model-quality generation or user-choice-dependent matrix', 'Earlier source03/8b measurements remain unchanged']}
(destination / 'source-manifest.json').open('x', encoding='utf-8').write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(files), 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'archiveSHA256': manifest['archiveSHA256']}))
