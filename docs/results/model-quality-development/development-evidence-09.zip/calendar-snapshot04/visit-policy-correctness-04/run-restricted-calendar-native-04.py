import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'source-manifest.json').read_text(encoding='utf-8'))
for item in manifest['files']:
    assert hashlib.sha256((root / item['path']).read_bytes()).hexdigest() == item['sha256']
for package, expected in [('HarbourCore', 184), ('HarbourRuntime', 21)]:
    result = json.loads((root / (package + '-test-result.json')).read_text(encoding='utf-8'))
    assert result['exitCode'] == 0 and result['expectedCountSatisfied'] and result['executedTests'] == expected
    assert result['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
command = [sys.executable, str(root / 'scripts/evaluate-models.py'), '--models-directory', '/evalcache/models',
           '--models', 'qwen35', 'small', 'balanced', '--runtime-prefix', '/evalcache/linux-runtime-v2',
           '--output-directory', str(root / 'native159'), '--efforts', 'standard', '--repeats', '1', '--split', 'dev',
           '--context-checks', '--grammar-checks', '--diagnostics-only', '--source-label', 'working-restricted-calendar-snapshot04-f10fece3']
start = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root / 'native159.log').open('xb') as log:
    process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
metadata_path = root / 'native159/metadata.json'
complete = False
counts = {}
if metadata_path.is_file():
    metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
    complete = metadata.get('complete', False)
    for name in ['qwen35', 'small', 'balanced']:
        path = root / 'native159' / (name + '.jsonl')
        if path.is_file():
            rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line]
            counts[name] = {'rows': len(rows), 'grammar': sum(row['kind'] == 'grammar' for row in rows),
                            'context': sum(row['kind'] == 'context_boundary' for row in rows),
                            'passed': sum(row['validationSucceeded'] for row in rows),
                            'quality': sum(row['kind'] in ['routing', 'prose', 'title', 'visit'] for row in rows),
                            'rowsSHA256': hashlib.sha256(path.read_bytes()).hexdigest()}
passed = process.returncode == 0 and complete and len(counts) == 3 and all(value['rows'] == value['passed'] == 53 and value['grammar'] == 51 and value['context'] == 2 and value['quality'] == 0 for value in counts.values())
report = {'schemaVersion': 1, 'complete': complete, 'passed': passed,
          'scope': 'Native51 grammar+2 context invariant cases per pinned model; no frozen fixture/model-quality generation',
          'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'sourceArchiveSHA256': manifest['archiveSHA256'],
          'command': command, 'exitCode': process.returncode, 'startedUTC': started,
          'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsedSeconds': time.monotonic() - start,
          'counts': counts, 'metadataSHA256': hashlib.sha256(metadata_path.read_bytes()).hexdigest() if metadata_path.is_file() else None,
          'logSHA256': hashlib.sha256((root / 'native159.log').read_bytes()).hexdigest(),
          'runnerSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root / 'native159-result.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
if not passed:
    print((root / 'native159.log').read_text(encoding='utf-8', errors='replace')[-6000:])
    raise SystemExit(process.returncode or 1)
