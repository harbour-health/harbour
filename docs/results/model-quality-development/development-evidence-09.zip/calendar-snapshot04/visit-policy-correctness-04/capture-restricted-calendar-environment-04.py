import datetime
import hashlib
import json
from pathlib import Path
import subprocess

directory = Path(__file__).resolve().parent / 'visit-policy-correctness-04'
manifest = json.loads((directory / 'source-manifest.json').read_text(encoding='utf-8'))
image = subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '100.83.225.2', 'docker image inspect harbour-model-eval:00jdaq --format {{.Id}}'], text=True).strip()
assert image == 'sha256:4e2d836d1252e502c2c5ac92bc73e675d5d9a1780a82ad4c4127624e5792d756'
base = ['docker', 'run', '--rm', '--network', 'none', '--mount', 'type=bind,source=/tmp/harbour-evals.00JDAq,target=/evalcache',
        '-w', '/evalcache/visit-policy-correctness-04', 'harbour-model-eval:00jdaq', 'python3']
scripts = ['capture-visit-policy-correctness-04.py', 'prepare-restricted-calendar-source-04.py', 'run-restricted-calendar-correctness-04.py',
           'run-restricted-calendar-native-04.py', 'audit-restricted-calendar-contract-04.py', 'capture-restricted-calendar-environment-04.py']
report = {'schemaVersion': 1, 'capturedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Supplemental retrospective execution environment receipt for snapshot04 correctness; no preregistered quality protocol claim',
          'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'containerImageID': image,
          'baseImage': 'ghcr.io/xtool-org/xtool:1.21.0@sha256:032d20a18c8015e49fa99fddfc4ba236795731fd8543d69971ff76d388e8430f',
          'testCommand': base + ['/evalcache/visit-policy-correctness-04/run-restricted-calendar-correctness-04.py', '--expected-core-tests', '184'],
          'nativeCommand': base + ['/evalcache/visit-policy-correctness-04/run-restricted-calendar-native-04.py'],
          'runtimeCache': '/evalcache/linux-runtime-v2', 'modelCache': '/evalcache/models',
          'helperScriptsSHA256': {name: hashlib.sha256((directory.parent / name).read_bytes()).hexdigest() for name in scripts},
          'noCompetingRemoteCompilationOrInferenceDuringMeasuredChecks': True,
          'noModelQualityMatrix': True}
(directory / 'execution-environment.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'containerImageID': image, 'sourceIdentitySHA256': report['sourceIdentitySHA256']}))
