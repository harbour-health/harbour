import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
directory = root / 'build/model-quality/visit-policy-correctness-04'
helpers = ['capture-visit-policy-correctness-04.py', 'prepare-restricted-calendar-source-04.py', 'run-restricted-calendar-correctness-04.py',
           'run-restricted-calendar-native-04.py', 'audit-restricted-calendar-contract-04.py', 'capture-restricted-calendar-environment-04.py',
           'audit-restricted-calendar-remote-04.py', 'verify-restricted-calendar-evidence-04.py', 'prepare-restricted-calendar-allowlist-04.py']
selected = sorted(path for path in directory.rglob('*') if path.is_file())
selected.extend(directory.parent / name for name in helpers)
status = json.loads((directory / 'validation-status.json').read_text(encoding='utf-8'))
files = []
for path in selected:
    relative = path.relative_to(directory).as_posix() if directory in path.parents else path.name
    files.append({'source': path.relative_to(root).as_posix(), 'archivePath': 'visit-policy-correctness-04/' + relative,
                  'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
report = {'schemaVersion': 1, 'scope': 'Publishable exact snapshot04 correctness allowlist only; no publication/commit performed',
          'sourceIdentitySHA256': status['sourceIdentitySHA256'], 'validationStatusSHA256': hashlib.sha256((directory / 'validation-status.json').read_bytes()).hexdigest(),
          'files': files, 'fileCount': len(files), 'totalUncompressedBytes': sum(item['bytes'] for item in files),
          'omissions': 'Model weights, native libraries and XCTest/ModelEval binaries omitted; exact hashes retained in bound metadata and audit',
          'notEstablished': 'No model-quality/default release decision or later-source validation'}
(directory / 'publishable-allowlist.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'files': len(files), 'totalBytes': report['totalUncompressedBytes'],
                  'allowlistSHA256': hashlib.sha256((directory / 'publishable-allowlist.json').read_bytes()).hexdigest()}))
