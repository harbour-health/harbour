import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
old = json.loads((root / 'visit-policy-correctness-03/source-manifest.json').read_text(encoding='utf-8'))
current_dir = root / 'visit-policy-correctness-04'
new = json.loads((current_dir / 'source-manifest.json').read_text(encoding='utf-8'))
a = {item['path']: item for item in old['files']}
b = {item['path']: item for item in new['files']}
unchanged_required = ['HarbourRuntime/Sources/ModelEval/main.swift', 'HarbourRuntime/Sources/HarbourRuntime/ModelPromptFormat.swift',
                      'HarbourRuntime/Sources/HarbourRuntime/JSONEnvelope.swift', 'HarbourRuntime/Sources/HarbourRuntime/ToolOutputGrammar.swift',
                      'HarbourRuntime/Sources/HarbourRuntime/TitleOutputGrammar.swift', 'HarbourRuntime/Package.swift',
                      'scripts/evaluate-models.py', 'scripts/prepare-linux-runtime.py', 'scripts/cache-eval-models.py',
                      'evaluation/harbour-model-quality-v1.json']
assert all(a[path]['sha256'] == b[path]['sha256'] for path in unchanged_required)
report = {'schemaVersion': 1, 'scope': 'Native159 harness and existing diagnostic expectations unchanged from source03; newly restrictive minimum/parse/apply checks are separately tested by full Core184 suite',
          'priorSourceIdentitySHA256': old['sourceIdentitySHA256'], 'currentSourceIdentitySHA256': new['sourceIdentitySHA256'],
          'unchangedHarnessAndProtocolSHA256': {path: b[path]['sha256'] for path in unchanged_required},
          'changedSourceInventory': [path for path in sorted(set(a) | set(b)) if a.get(path, {}).get('sha256') != b.get(path, {}).get('sha256')],
          'diagnosticCount': {'grammarPerModel': 51, 'contextPerModel': 2, 'models': 3, 'total': 159},
          'ordinarySourceIntent': 'Existing source-bound positive, negative, cardinality and context controls remain regression checks; no model-quality cases generated',
          'notEstablished': 'Native159 does not exhaustively test all restricted phrases; Core minimum/parse/apply cases are explicit bounded examples',
          'auditorSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(current_dir / 'native-contract-comparison.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
