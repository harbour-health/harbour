import hashlib
import json
from pathlib import Path
import re
import tarfile

directory = Path(__file__).resolve().parent / 'visit-policy-correctness-04'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):
    return json.loads((directory / name).read_text(encoding='utf-8'))
manifest = load('source-manifest.json')
remote = load('remote-preserved-source-audit.json')
metadata = load('native159/metadata.json')
native_result = load('native159-result.json')
assert digest(directory / 'working-source.tar.gz') == manifest['archiveSHA256']
with tarfile.open(directory / 'working-source.tar.gz') as archive:
    source = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
assert len(source) == len(manifest['files']) == 55
assert remote['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
for item in manifest['files']:
    assert len(source[item['path']]) == item['bytes']
    assert hashlib.sha256(source[item['path']]).hexdigest() == item['sha256'] == remote['preservedSourceInventorySHA256'][item['path']]
assert all(remote['preservedSourceInventorySHA256'][name] == value for name, value in metadata['sourceSHA256'].items())
assert remote['measuredNativeMetadataSourceInventorySHA256'] == metadata['sourceSHA256']
assert metadata['runtimeFilesSHA256'] == remote['nativeRuntimeFilesSHA256']
assert metadata['executableSHA256'] == remote['executableSHA256']
assert native_result['complete'] and native_result['passed'] and native_result['exitCode'] == 0
assert native_result['metadataSHA256'] == digest(directory / 'native159/metadata.json')
assert native_result['logSHA256'] == digest(directory / 'native159.log')
tests = []
for package, count in [('HarbourCore', 184), ('HarbourRuntime', 21)]:
    report = load(package + '-test-result.json')
    assert report['complete'] and report['exitCode'] == 0 and report['executedTests'] == count and report['failures'] == 0
    assert report['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256'] and report['sourceArchiveSHA256'] == manifest['archiveSHA256']
    assert report['sourceManifestSHA256'] == digest(directory / 'source-manifest.json')
    assert report['logSHA256'] == digest(directory / (package + '-swift-test.log'))
    assert report['runtimeFilesSHA256'] == metadata['runtimeFilesSHA256']
    assert all(remote['testArtifactsSHA256'][name] == value for name, value in report['testArtifactsSHA256'].items())
    tests.append({'package': package, 'passed': count, 'logSHA256': report['logSHA256'], 'resultSHA256': digest(directory / (package + '-test-result.json'))})
methods = re.findall(r'func (test\w+)\(', source['HarbourCore/Tests/HarbourCoreTests/VisitScheduleScopeTests.swift'].decode())
core_log = (directory / 'HarbourCore-swift-test.log').read_text(encoding='utf-8')
assert len(methods) == 6 and all(f"VisitScheduleScopeTests.{name}' passed" in core_log for name in methods)
counts = {}
for name in ['qwen35', 'small', 'balanced']:
    path = directory / 'native159' / (name + '.jsonl')
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line]
    assert len(rows) == 53 and all(row['validationSucceeded'] for row in rows)
    assert sum(row['kind'] == 'grammar' for row in rows) == 51 and sum(row['kind'] == 'context_boundary' for row in rows) == 2
    assert not any(row['kind'] in ['routing', 'prose', 'title', 'visit'] for row in rows)
    assert digest(path) == native_result['counts'][name]['rowsSHA256'] == metadata['resultSHA256'][name]
    for row in rows:
        if row['kind'] == 'grammar':
            assert row['grammarAccepted'] == row['expectedAcceptance']
    expected_grammars = {(item['caseID'], item['effort'], item['repeatIndex']): item['sha256'] for item in metadata['responseGrammarSHA256'][name]}
    for row in rows:
        key = (row['caseID'], row['effort'], row['repeatIndex'])
        value = hashlib.sha256(row['responseGrammar'].encode()).hexdigest() if row.get('responseGrammar') else None
        assert expected_grammars[key] == value
    counts[name] = {'passed': 53, 'grammar': 51, 'context': 2, 'rowsSHA256': digest(path)}
report = {'schemaVersion': 1, 'complete': True, 'passed': True,
          'scope': 'Snapshot04 restricted-calendar working-source correctness proof; no model-quality matrix, device execution or later-source approval',
          'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'sourceArchiveSHA256': manifest['archiveSHA256'],
          'sourceInventoryFilesVerified': 55, 'measuredNativeMetadataSourceInventoryFiles': 28,
          'sourceInventoryScope': 'Preserved file inventory, broader than each compiler input list',
          'tests': tests, 'specificScheduleScopeMethodsPassed': methods, 'native': counts,
          'nativeTotalPassed': 159, 'nativeExectuableSHA256': metadata['executableSHA256'],
          'runtimeFilesVerified': len(metadata['runtimeFilesSHA256']), 'testArtifactsVerified': len(remote['testArtifactsSHA256']),
          'verifierSHA256': digest(Path(__file__)),
          'filesSHA256': {path.relative_to(directory).as_posix(): digest(path) for path in sorted(directory.rglob('*')) if path.is_file()}}
(directory / 'validation-status.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'sourceIdentitySHA256': report['sourceIdentitySHA256'], 'tests': tests, 'nativeTotalPassed': 159,
                  'validationStatusSHA256': digest(directory / 'validation-status.json')}, indent=2))
