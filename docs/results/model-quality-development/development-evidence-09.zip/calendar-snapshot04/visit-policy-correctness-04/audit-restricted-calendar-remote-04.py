import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
cache = root.parent
manifest = json.loads((root / 'source-manifest.json').read_text(encoding='utf-8'))
metadata = json.loads((root / 'native159/metadata.json').read_text(encoding='utf-8'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def host_path(path):
    assert path.startswith('/evalcache/')
    result = cache / path.removeprefix('/evalcache/')
    assert cache in result.resolve().parents
    return result
source = {item['path']: digest(root / item['path']) for item in manifest['files']}
assert all(source[item['path']] == item['sha256'] for item in manifest['files'])
assert all(source[name] == value for name, value in metadata['sourceSHA256'].items())
executable = host_path(metadata['commands'][0][0])
assert digest(executable) == metadata['executableSHA256']
runtime = {name: digest(cache / 'linux-runtime-v2' / name) for name in metadata['runtimeFilesSHA256']}
assert runtime == metadata['runtimeFilesSHA256']
assert metadata['runtime']['runtimeBuild'] == 'b10549'
assert metadata['runtime']['sourceSHA256'] == '418ef98f058952c4f2e1fba0f77a73cbbfac2e5bf4146a0dc3202777ed5d9c1f'
assert all(runtime[name] == value for name, value in metadata['runtime']['installedFilesSHA256'].items())
test_artifacts = {}
for package in ['HarbourCore', 'HarbourRuntime']:
    result = json.loads((root / (package + '-test-result.json')).read_text(encoding='utf-8'))
    assert result['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
    assert result['runtimeFilesSHA256'] == runtime
    actual = {name: digest(root / name) for name in result['testArtifactsSHA256']}
    assert actual == result['testArtifactsSHA256'] and len(actual) == 2
    test_artifacts.update(actual)
report = {'schemaVersion': 1, 'complete': True,
          'scope': 'Read-only preserved remote source inventory/executable/test-artifact/runtime byte audit after snapshot04 correctness; not a compiler input list or model-quality result',
          'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'preservedSourceInventorySHA256': source,
          'measuredNativeMetadataSourceInventorySHA256': metadata['sourceSHA256'], 'executableSHA256': digest(executable),
          'nativeRuntimeFilesSHA256': runtime, 'testArtifactsSHA256': test_artifacts,
          'modelFileSizes': {item['model']: (cache / 'models' / item['filename']).stat().st_size for item in metadata['models']},
          'auditorSHA256': digest(Path(__file__))}
(root / 'remote-preserved-source-audit.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'sourceInventoryFiles': len(source), 'nativeMetadataSourceFiles': len(metadata['sourceSHA256']),
                  'runtimeFiles': len(runtime), 'testArtifacts': len(test_artifacts), 'executableSHA256': report['executableSHA256']}))
