"""Audit sealed symptom scope/caller bindings; no inference or record writes."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--reason', required=True, help='Accepted symptom fallback reason from the committed helper')
args = parser.parse_args()
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'source-manifest.json').read_text(encoding='utf-8'))
assert manifest['expectedTests']['HarbourCore'] == 210
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for item in manifest['files']:
    assert digest(root / item['path']) == item['sha256']
scope_path = root / manifest['sourceSymptomScopePath']
scope_bytes = scope_path.read_bytes()
assert digest(scope_path) == manifest['sourceSymptomScopeActualMaterializedSHA256']
assert hashlib.sha256(scope_bytes.replace(b'\r\n', b'\n')).hexdigest() == manifest['sourceSymptomScopeCanonicalRawGitSHA256']
assert isinstance(json.loads(scope_bytes), dict)
paths = ['HarbourCore/Sources/HarbourCore/ToolPlanner.swift', 'Harbour/ModelManager.swift',
         'HarbourRuntime/Sources/ModelEval/main.swift', 'HarbourRuntime/Sources/ModelProbe/main.swift']
core, app, evaluator, probe = [(root / name).read_text(encoding='utf-8') for name in paths]
helper = core.split('public static func replyFallback(', 1)[1].split('public static func prompt(', 1)[0]
assert 'tool: .captureSymptom' in helper and 'action: .symptom(' in helper
assert 'reason: "' + args.reason + '"' in helper
assert app.index('let decision = try ToolPlanner.parse(output)') < app.index('if let fallback = ToolPlanner.replyFallback(original: input')
assert 'return fallback.decision' in app
assert 'result.routeOutput = raw' in evaluator and 'result.observedTool = decision.tool.rawValue' in evaluator
assert 'result.actionSummary = actionSummary(fallback.action)' in evaluator
assert 'result.actionOrigin = "application"; result.applicationDecision = fallback.decision' in evaluator
assert 'result.rawTool = decision?.tool.rawValue' in probe and 'action = fallback.action' in probe
assert 'result.actionOrigin = "application"; result.applicationDecision = fallback.decision' in probe
report = {'schemaVersion': 1, 'passed': True, 'sourceCommit': manifest['sourceCommit'],
          'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
          'scope': 'Static accepted symptom scope and post-routing caller/origin consistency only; source/bounds behavior requires full Core210 proof, no UI/model quality or record-save claim',
          'sourceSymptomScopeActualMaterializedSHA256': manifest['sourceSymptomScopeActualMaterializedSHA256'],
          'sourceSymptomScopeCanonicalRawGitSHA256': manifest['sourceSymptomScopeCanonicalRawGitSHA256'],
          'fallbackReason': args.reason, 'sourceFilesSHA256': {name: digest(root / name) for name in paths},
          'rawRoutingPreserved': True, 'applicationRecoverySeparated': True,
          'recordExecutionPerformed': False, 'auditorSHA256': digest(Path(__file__))}
(root / 'symptom-caller-origin-scope-audit.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': True, 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
                  'auditSHA256': digest(root / 'symptom-caller-origin-scope-audit.json')}))
