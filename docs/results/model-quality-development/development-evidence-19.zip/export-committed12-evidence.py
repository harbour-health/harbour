"""Export gate evidence only, excluding source/build binaries and weights."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
paths = [p for p in root.iterdir() if p.is_file() and p.suffix in ['.json','.log','.py']]
paths += [p for p in (root / 'native159').rglob('*') if p.is_file()]
target = root / 'gate-evidence.tar.gz'
with tarfile.open(target, 'x:gz') as archive:
    for path in sorted(paths): archive.add(path, arcname=path.relative_to(root).as_posix())
print(json.dumps({'files':len(paths),'archiveSHA256':hashlib.sha256(target.read_bytes()).hexdigest()}))
