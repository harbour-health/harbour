"""Independently bind archived materialization to the named committed blobs."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

directory = Path(__file__).resolve().parent / 'committed-source12'
manifest = json.loads((directory / 'source-manifest.json').read_text(encoding='utf-8'))
commit = manifest['sourceCommit']
assert commit == '740a797ffcd7f15c9a21c8db8f86d729a362b863'
requests = ''.join(commit + ':' + item['path'] + '\n' for item in manifest['files']).encode()
data = subprocess.run(['git', 'cat-file', '--batch'], input=requests, stdout=subprocess.PIPE, check=True).stdout
offset = 0
comparisons = []
with tarfile.open(directory / 'source.tar.gz') as archive:
    for item in manifest['files']:
        end = data.index(b'\n', offset)
        header = data[offset:end].decode().split()
        assert len(header) == 3 and header[1] == 'blob'
        size = int(header[2])
        blob = data[end + 1:end + 1 + size]
        offset = end + 2 + size
        captured = archive.extractfile(item['path']).read()
        assert len(blob) == size == item['rawGitBlobBytes']
        assert hashlib.sha256(blob).hexdigest() == item['rawGitBlobSHA256']
        assert hashlib.sha256(captured).hexdigest() == item['sha256']
        assert captured.replace(b'\r\n', b'\n') == blob.replace(b'\r\n', b'\n')
        comparisons.append({'path': item['path'], 'blobObject': header[0], 'rawGitBlobSHA256': item['rawGitBlobSHA256'],
                            'actualMaterializedSHA256': item['sha256'], 'rawBlobByteExact': captured == blob,
                            'byteExactAfterCRLFNormalization': True})
        if item['path'] == 'evaluation/optional-model-scope-v1.json':
            assert hashlib.sha256(blob).hexdigest() == manifest['optionalModelScopeCanonicalRawGitSHA256']
            assert json.loads(blob) == json.loads(captured)
            (directory / 'optional-model-scope-v1.raw-git.json').open('xb').write(blob)
        if item['path'] == 'evaluation/optional-model-source-reading-scope-v1.json':
            assert hashlib.sha256(blob).hexdigest() == manifest['sourceReadingScopeCanonicalRawGitSHA256']
            assert hashlib.sha256(captured).hexdigest() == manifest['sourceReadingScopeActualMaterializedSHA256']
            assert json.loads(blob) == json.loads(captured)
            (directory / 'optional-model-source-reading-scope-v1.raw-git.json').open('xb').write(blob)
        if item['path'] == manifest['sourceSymptomScopePath']:
            assert hashlib.sha256(blob).hexdigest() == manifest['sourceSymptomScopeCanonicalRawGitSHA256']
            assert hashlib.sha256(captured).hexdigest() == manifest['sourceSymptomScopeActualMaterializedSHA256']
            assert json.loads(blob) == json.loads(captured)
            (directory / 'optional-model-source-symptom-scope-v1.raw-git.json').open('xb').write(blob)
assert offset == len(data)
report = {'schemaVersion': 1, 'complete': True, 'passed': True, 'sourceCommit': commit,
          'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
          'scope': 'Read-only independent raw committed Git blob versus exact measured archive representation proof; EOL equivalence is not a byte identity claim',
          'filesVerified': len(comparisons), 'files': comparisons,
          'auditorSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(directory / 'git-materialization-audit.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'filesVerified': len(comparisons), 'auditSHA256': hashlib.sha256((directory / 'git-materialization-audit.json').read_bytes()).hexdigest()}))
