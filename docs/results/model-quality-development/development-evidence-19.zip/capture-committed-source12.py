"""Capture an explicitly approved committed source; do not invoke before root go."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--commit', required=True, help='Exact accepted commit supplied by root after source freeze')
parser.add_argument('--symptom-scope-path', default='evaluation/optional-model-source-symptom-scope-v1.json')
parser.add_argument('--symptom-scope-canonical-sha256', required=True, help='Accepted new scope raw Git identity, supplied/bound after root approves the exact commit')
args = parser.parse_args()
assert len(args.symptom_scope_canonical_sha256) == 64 and all(c in '0123456789abcdef' for c in args.symptom_scope_canonical_sha256)
assert args.symptom_scope_path.startswith('evaluation/') and '..' not in args.symptom_scope_path.split('/')
assert len(args.commit) == 40 and all(char in '0123456789abcdef' for char in args.commit)
commit = subprocess.check_output(['git', 'rev-parse', '--verify', args.commit + '^{commit}'], cwd=root, text=True).strip()
assert commit == args.commit
directory = root / 'build/model-quality/committed-source12'
directory.mkdir(exist_ok=False)
paths = ['Package.swift', 'xtool.yml', 'README.md', '.github/workflows', 'Harbour', 'Harbour.xcodeproj', 'HarbourCore',
         'HarbourRuntime', 'HarbourTests', 'HarbourUITests', 'scripts', 'evaluation']
data = subprocess.check_output(['git', 'archive', '--format=tar', commit, *paths], cwd=root)
archive_path = directory / 'source.tar.gz'
with archive_path.open('xb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as output:
        output.write(data)
files = []
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive.getmembers():
        assert member.isdir() or member.isfile()
        if not member.isfile():
            continue
        content = archive.extractfile(member).read()
        blob = subprocess.check_output(['git', 'show', commit + ':' + member.name], cwd=root)
        files.append({'path': member.name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(),
                      'CRLFCount': content.count(b'\r\n'), 'LFCount': content.count(b'\n'),
                      'rawGitBlobSHA256': hashlib.sha256(blob).hexdigest(), 'rawGitBlobBytes': len(blob),
                      'rawBlobByteExact': content == blob,
                      'byteExactAfterCRLFNormalization': content.replace(b'\r\n', b'\n') == blob.replace(b'\r\n', b'\n')})
identity = [{key: item[key] for key in ['path', 'bytes', 'sha256']} for item in sorted(files, key=lambda item: item['path'])]
manifest = {'schemaVersion': 1, 'sourceCommit': commit, 'gitHEAD': commit,
            'scope': 'New committed source12 actual git-archive materialization for correctness and DEV/supplement evaluation; not a relabel of source8b4 passed gates/failed app flow or earlier proofs',
            'sourceInventoryScope': 'Captured app/package/test/fixture/audit inventory is broader than each compiler input list',
            'lineEndings': 'Actual materialized bytes recorded and separately compared with raw Git blobs; no LF or semantic-equivalence assumption',
            'sourceIdentitySHA256': hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'archiveSHA256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'files': files,
            'expectedTests': {'HarbourCore': 210, 'HarbourRuntime': 21, 'nativeGrammarAndContext': 159, 'PythonIntegrity': 60},
            'expectedQualityScopes': {'DEV': {'uniqueCasesPerModel': 59, 'primaryRowsPerModel': 89, 'additionalStandardTimingRowsPerModel': 8, 'rowsPerModel': 97, 'allModelsPrimaryRows': 267, 'allModelsAdditionalTimingRows': 24, 'allModelsRows': 291, 'efforts': ['standard', 'quick', 'extended'], 'repeats': 3},
                                     'supplemental': {'routingPerModel': 31, 'visitPerModel': 9, 'rowsPerModel': 40, 'allModelsRows': 120}, 'heldoutAuthorized': False},
            'notEstablished': ['Capture alone proves no compilation or model quality', 'No heldout output generated/reviewed', 'Qwen default-promotion gate remains blocked']}
required = ['HarbourCore/Tests/HarbourCoreTests/ReplyFallbackTests.swift', 'HarbourCore/Tests/HarbourCoreTests/VisitScheduleScopeTests.swift', 'evaluation/optional-model-scope-v1.json', 'evaluation/optional-model-source-reading-scope-v1.json']
lookup = {item['path']: item for item in files}
assert args.symptom_scope_path in lookup, 'Accepted symptom scope is missing'
assert all(name in lookup for name in required), 'Accepted source commit is missing required source/tests/scope'
manifest['optionalModelScopeSHA256'] = lookup['evaluation/optional-model-scope-v1.json']['sha256']
manifest['optionalModelScopeCanonicalRawGitSHA256'] = lookup['evaluation/optional-model-scope-v1.json']['rawGitBlobSHA256']
assert manifest['optionalModelScopeCanonicalRawGitSHA256'] == '95e309cf97c14ca7cb9904bfd60f44cd7845d55c2b85867d1cd70c52c26259bd'
assert lookup['evaluation/optional-model-scope-v1.json']['byteExactAfterCRLFNormalization']
manifest['optionalModelScopeBinding'] = 'Canonical preregistration raw Git blob hash and actual compiled-workspace materialization hash are recorded separately; only CRLF normalization differs'
reading_scope = lookup['evaluation/optional-model-source-reading-scope-v1.json']
assert reading_scope['rawGitBlobSHA256'] == '4db2b619edd640d26763874358a061bf4093b253b16a734505278bc7293b5b74'
assert reading_scope['byteExactAfterCRLFNormalization']
manifest['sourceReadingScopeActualMaterializedSHA256'] = reading_scope['sha256']
manifest['sourceReadingScopeCanonicalRawGitSHA256'] = reading_scope['rawGitBlobSHA256']
manifest['sourceReadingScopeBinding'] = 'New bounded post-routing source reading disposition; canonical registration and actual materialized bytes separately recorded, no fixture/scorer/promotion threshold changes'
symptom_scope = lookup[args.symptom_scope_path]
assert symptom_scope['rawGitBlobSHA256'] == args.symptom_scope_canonical_sha256
assert symptom_scope['byteExactAfterCRLFNormalization']
manifest['sourceSymptomScopePath'] = args.symptom_scope_path
manifest['sourceSymptomScopeActualMaterializedSHA256'] = symptom_scope['sha256']
manifest['sourceSymptomScopeCanonicalRawGitSHA256'] = symptom_scope['rawGitBlobSHA256']
manifest['sourceSymptomScopeBinding'] = 'Separate bounded post-routing source symptom proposal; actual captured bytes and raw registered Git identity are distinct, no raw model quality credit or automatic record save'
assert all(item['byteExactAfterCRLFNormalization'] for item in files)
manifest['priorSource11ProofPreserved'] = 'build/model-quality/committed-source11/validation-status.json'
manifest['priorFailedTestContractProofPreserved'] = 'build/model-quality/committed-source09/HarbourCore-test-result.json'
manifest['priorPassedGatesFailedAppFlowCohort'] = 'build/model-quality/committed-source08/source-manifest.json'
manifest['priorFailedCoreProofPreserved'] = 'build/model-quality/committed-source07/failed-core-count-correction.json'
manifest['priorInterruptedQualityAttemptPreserved'] = 'build/model-quality/final-dev-291-source063-01/partial-preservation-status.json'
assert lookup['evaluation/harbour-model-quality-v1.json']['sha256'] == '7a013eae0da56e0d829513ebd4c33a54eccd45c4ce6e8da4ffa81857d42fb5d9'
(directory / 'source-manifest.json').open('x', encoding='utf-8').write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'sourceCommit': commit, 'files': len(files), 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'archiveSHA256': manifest['archiveSHA256']}))
