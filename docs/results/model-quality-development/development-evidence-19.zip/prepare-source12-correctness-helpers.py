"""Prepare/capture a Root-reviewed commit for fresh correctness checks only.

Never run on unfinished work. Counts are supplied and checked against the
accepted commit before tests; no model quality or heldout execution here.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = '7a4181264af9c5443811796aacd6d64c13a76339'
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--commit', required=True)
p.add_argument('--expected-core-tests', type=int, required=True)
p.add_argument('--root-reviewed-commit-go', action='store_true', required=True)
args = p.parse_args()
assert args.root_reviewed_commit_go and re.fullmatch('[0-9a-f]{40}', args.commit)
assert subprocess.check_output(['git','rev-parse',args.commit+'^{commit}'],cwd=ROOT,text=True).strip()==args.commit
assert not (HERE/'committed-source12').exists()
old_helpers = ['capture-committed-source11.py','prepare-committed11-source.py','run-committed11-correctness.py',
               'run-committed11-native.py','run-committed11-auxiliary.py','run-committed11-symptom-scope-audit.py',
               'audit-committed11-remote.py','verify-committed11-evidence.py','audit-committed11-git-bytes.py','export-committed11-evidence.py']
records=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_new(path,text):
    ast.parse(text,filename=path.name)
    path.open('x',encoding='utf-8',newline='\n').write(text)
def adapt(text):
    return text.replace('source11','source12').replace('committed11','committed12').replace(OLD,args.commit).replace('7a418126',args.commit[:8]).replace('7a41812',args.commit[:7])
def blob(path):return subprocess.check_output(['git','show',args.commit+':'+path],cwd=ROOT)
tree=subprocess.check_output(['git','ls-tree','-r','--name-only',args.commit,'HarbourCore/Tests'],cwd=ROOT,text=True).splitlines()
core_methods=sum(len(re.findall(rb'\bfunc\s+test\w+\s*\(',blob(name)))for name in tree if name.endswith('.swift'))
assert core_methods==args.expected_core_tests, (core_methods,args.expected_core_tests)
reply_methods=len(re.findall(rb'\bfunc\s+test\w+\s*\(',blob('HarbourCore/Tests/HarbourCoreTests/ReplyFallbackTests.swift')))
capture_old=HERE/old_helpers[0];capture_new=HERE/'capture-committed-source12.py'
capture=adapt(capture_old.read_text(encoding='utf-8')).replace("'HarbourCore': 200",f"'HarbourCore': {core_methods}")
capture=capture.replace("manifest['priorSource545ProofPreserved'] = 'build/model-quality/committed-source10/validation-status.json'", "manifest['priorSource11ProofPreserved'] = 'build/model-quality/committed-source11/validation-status.json'")
write_new(capture_new,capture)
records.append({'original':capture_old.name,'originalSHA256':sha(capture_old),'new':capture_new.name,'newSHA256':sha(capture_new)})
subprocess.run([sys.executable,'-X','utf8',str(capture_new),'--commit',args.commit,'--symptom-scope-canonical-sha256','7cdaa3961fde529c5ca19056568d39114cecb2aa71cde2f0e2a5ff3685d22905'],cwd=ROOT,check=True)
directory=HERE/'committed-source12'
manifest=json.loads((directory/'source-manifest.json').read_bytes())
assert manifest['sourceCommit']==args.commit and manifest['expectedTests']['HarbourCore']==core_methods
for name in old_helpers[1:]:
    old=HERE/name;new=HERE/name.replace('committed11','committed12')
    text=adapt(old.read_text(encoding='utf-8'))
    text=text.replace('38cbb809476100fe09e5eb3f000e9d01c6cef2d875a5990e64f3e51b149b32b3',manifest['sourceIdentitySHA256'])
    text=text.replace('c1d525289d2784eece047b297a3fdde1bbc3fff144420352c8675834c508a005',manifest['archiveSHA256'])
    text=re.sub(r'\b200\b',str(core_methods),text)
    text=text.replace('Core200','Core'+str(core_methods))
    text=re.sub(r'\b131\b',str(len(manifest['files'])),text)
    text=text.replace('source12-38cbb809','source12-'+manifest['sourceIdentitySHA256'][:8])
    if name=='verify-committed11-evidence.py':
        assert 'len(reply_methods) == 14' in text
        text=text.replace('len(reply_methods) == 14',f'len(reply_methods) == {reply_methods}')
    write_new(new,text)
    records.append({'original':name,'originalSHA256':sha(old),'new':new.name,'newSHA256':sha(new)})
sequence='''"""Sequential correctness on the Root-reviewed source12 snapshot only."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for helper,args in [
 ('prepare-committed12-source.py',[]),
 ('run-committed12-correctness.py',['--expected-core-tests','CORE_COUNT']),
 ('run-committed12-native.py',[]),
 ('run-committed12-auxiliary.py',[]),
 ('run-committed12-symptom-scope-audit.py',['--reason','symptom_draft']),
 ('audit-committed12-remote.py',[]),
 ('export-committed12-evidence.py',[]),
]:
 print('START '+helper,flush=True)
 code=subprocess.run([sys.executable,str(root/helper),*args],cwd=root).returncode
 print('EXIT '+helper+' '+str(code),flush=True)
 if code:raise SystemExit(code)
'''.replace('CORE_COUNT',str(core_methods))
write_new(HERE/'run-committed12-sequence.py',sequence)
records.append({'new':'run-committed12-sequence.py','newSHA256':sha(HERE/'run-committed12-sequence.py')})
receipt={'schemaVersion':1,'sourceCommit':args.commit,'sourceIdentitySHA256':manifest['sourceIdentitySHA256'],
         'sourceArchiveSHA256':manifest['archiveSHA256'],'sourceFiles':len(manifest['files']),
         'expectedCoreMethodsFromReviewedCommit':core_methods,'expectedReplyMethodsFromReviewedCommit':reply_methods,
         'helpers':records,'noCPUCompilerTestsScorerModelOrHeldoutInvoked':True,'finalHeldoutFreezeOrGO':False,
         'scope':'Root-reviewed implementation snapshot capture and helpers. Test counts fixed from committed source before execution; all old helpers and source11 failures preserved.',
         'preparerSHA256':sha(__file__)}
(HERE/'source12-correctness-helper-preparation.json').open('x',encoding='utf-8').write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'prepared':True,'sourceFiles':len(manifest['files']),'CoreExpected':core_methods,'heldoutAuthorized':False}))
