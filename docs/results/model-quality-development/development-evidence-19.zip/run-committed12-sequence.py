"""Sequential correctness on the Root-reviewed source12 snapshot only."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for helper,args in [
 ('prepare-committed12-source.py',[]),
 ('run-committed12-correctness.py',['--expected-core-tests','210']),
 ('run-committed12-native.py',[]),
 ('run-committed12-auxiliary.py',[]),
 ('run-committed12-symptom-scope-audit.py',['--reason','symptom_draft']),
 ('audit-committed12-remote.py',[]),
 ('export-committed12-evidence.py',[]),
]:
 print('START '+helper,flush=True)
 code=subprocess.run([sys.executable,str(root/helper),*args],cwd=root).returncode
 print('EXIT '+helper+' '+str(code),flush=True)
 if code:raise SystemExit(code)
