import hashlib
import json
from pathlib import Path
import re
import tarfile

directory = Path(__file__).resolve().parent / 'committed-source12'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):
    return json.loads((directory / name).read_text(encoding='utf-8'))
manifest = load('source-manifest.json')
remote = load('remote-preserved-source-audit.json')
metadata = load('native159/metadata.json')
native_result = load('native159-result.json')
assert digest(directory / 'source.tar.gz') == manifest['archiveSHA256']
with tarfile.open(directory / 'source.tar.gz') as archive:
    source = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
assert len(source) == len(manifest['files']) == 133
assert remote['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
for item in manifest['files']:
    assert len(source[item['path']]) == item['bytes']
    assert hashlib.sha256(source[item['path']]).hexdigest() == item['sha256'] == remote['preservedSourceInventorySHA256'][item['path']]
assert all(remote['preservedSourceInventorySHA256'][name] == value for name, value in metadata['sourceSHA256'].items())
assert remote['measuredNativeMetadataSourceInventorySHA256'] == metadata['sourceSHA256']
assert metadata['runtimeFilesSHA256'] == remote['nativeRuntimeFilesSHA256']
assert metadata['executableSHA256'] == remote['executableSHA256']
assert native_result['complete'] and native_result['passed'] and native_result['exitCode'] == 0
assert native_result['metadataSHA256'] == digest(directory / 'native159/metadata.json')
assert native_result['logSHA256'] == digest(directory / 'native159.log')
tests = []
for package, count in [('HarbourCore', 210), ('HarbourRuntime', 21)]:
    report = load(package + '-test-result.json')
    assert report['complete'] and report['exitCode'] == 0 and report['executedTests'] == count and report['failures'] == 0
    assert report['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256'] and report['sourceArchiveSHA256'] == manifest['archiveSHA256']
    assert report['sourceManifestSHA256'] == digest(directory / 'source-manifest.json')
    assert report['logSHA256'] == digest(directory / (package + '-swift-test.log'))
    assert report['runtimeFilesSHA256'] == metadata['runtimeFilesSHA256']
    assert all(remote['testArtifactsSHA256'][name] == value for name, value in report['testArtifactsSHA256'].items())
    tests.append({'package': package, 'passed': count, 'logSHA256': report['logSHA256'], 'resultSHA256': digest(directory / (package + '-test-result.json'))})
methods = re.findall(r'func (test\w+)\(', source['HarbourCore/Tests/HarbourCoreTests/VisitScheduleScopeTests.swift'].decode())
core_log = (directory / 'HarbourCore-swift-test.log').read_text(encoding='utf-8')
assert len(methods) == 8 and all(f"VisitScheduleScopeTests.{name}' passed" in core_log for name in methods)
counts = {}
for name in ['qwen35', 'small', 'balanced']:
    path = directory / 'native159' / (name + '.jsonl')
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line]
    assert len(rows) == 53 and all(row['validationSucceeded'] for row in rows)
    assert sum(row['kind'] == 'grammar' for row in rows) == 51 and sum(row['kind'] == 'context_boundary' for row in rows) == 2
    assert not any(row['kind'] in ['routing', 'prose', 'title', 'visit'] for row in rows)
    assert digest(path) == native_result['counts'][name]['rowsSHA256'] == metadata['resultSHA256'][name]
    for row in rows:
        if row['kind'] == 'grammar':
            assert row['grammarAccepted'] == row['expectedAcceptance']
    expected_grammars = {(item['caseID'], item['effort'], item['repeatIndex']): item['sha256'] for item in metadata['responseGrammarSHA256'][name]}
    for row in rows:
        key = (row['caseID'], row['effort'], row['repeatIndex'])
        value = hashlib.sha256(row['responseGrammar'].encode()).hexdigest() if row.get('responseGrammar') else None
        assert expected_grammars[key] == value
    counts[name] = {'passed': 53, 'grammar': 51, 'context': 2, 'rowsSHA256': digest(path)}
reply_methods = re.findall(r'func (test\w+)\(', source['HarbourCore/Tests/HarbourCoreTests/ReplyFallbackTests.swift'].decode())
assert len(reply_methods) == 18 and all(f"ReplyFallbackTests.{name}' passed" in core_log for name in reply_methods)
aux = load('auxiliary-checks-result.json')
assert aux['complete'] and aux['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
assert all(item['exitCode'] == 0 for item in aux['checks'])
assert aux['checks'][0]['executedTests'] == 60
assert aux['checks'][0]['logSHA256'] == digest(directory / 'python-integrity.log')
assert aux['checks'][1]['audit']['catalog_keys'] == 598 and not aux['checks'][1]['audit']['errors']
assert aux['checks'][1]['logSHA256'] == digest(directory / 'localization-audit.log')
assert aux['sourceProvenanceAuditSHA256'] == digest(directory / 'model-source-provenance-audit.json')
assert load('model-source-provenance-audit.json')['passed']
assert aux['readingCallerOriginAuditSHA256'] == digest(directory / 'reading-caller-origin-audit.json')
assert load('reading-caller-origin-audit.json')['passed']
assert load('reading-caller-origin-audit.json')['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
symptom_audit = load('symptom-caller-origin-scope-audit.json')
assert symptom_audit['passed'] and symptom_audit['sourceIdentitySHA256'] == manifest['sourceIdentitySHA256']
symptom_scope_bytes = source[manifest['sourceSymptomScopePath']]
assert hashlib.sha256(symptom_scope_bytes).hexdigest() == manifest['sourceSymptomScopeActualMaterializedSHA256']
assert hashlib.sha256(symptom_scope_bytes.replace(b'\r\n', b'\n')).hexdigest() == manifest['sourceSymptomScopeCanonicalRawGitSHA256']
policy_path = 'evaluation/optional-model-scope-v1.json'
policy_bytes = source[policy_path]
assert hashlib.sha256(policy_bytes).hexdigest() == manifest['optionalModelScopeSHA256']
assert hashlib.sha256(policy_bytes.replace(b'\r\n', b'\n')).hexdigest() == manifest['optionalModelScopeCanonicalRawGitSHA256']
assert manifest['sourceCommit'] == '740a797ffcd7f15c9a21c8db8f86d729a362b863'
assert all(item['byteExactAfterCRLFNormalization'] for item in manifest['files'])
reading_scope_bytes = source['evaluation/optional-model-source-reading-scope-v1.json']
assert hashlib.sha256(reading_scope_bytes).hexdigest() == manifest['sourceReadingScopeActualMaterializedSHA256']
assert hashlib.sha256(reading_scope_bytes.replace(b'\r\n', b'\n')).hexdigest() == manifest['sourceReadingScopeCanonicalRawGitSHA256']
report = {'schemaVersion': 1, 'complete': True, 'passed': True,
          'scope': 'Committed740a797 materialized-source12 correctness proof; no model-quality matrix or device execution',
          'sourceCommit': manifest['sourceCommit'], 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'sourceArchiveSHA256': manifest['archiveSHA256'],
          'optionalModelScopeActualMaterializedSHA256': manifest['optionalModelScopeSHA256'],
          'optionalModelScopeCanonicalRawGitSHA256': manifest['optionalModelScopeCanonicalRawGitSHA256'],
          'sourceReadingScopeActualMaterializedSHA256': manifest['sourceReadingScopeActualMaterializedSHA256'],
          'sourceReadingScopeCanonicalRawGitSHA256': manifest['sourceReadingScopeCanonicalRawGitSHA256'],
          'readingCallerOriginAuditSHA256': aux['readingCallerOriginAuditSHA256'],
          'sourceSymptomScopeActualMaterializedSHA256': manifest['sourceSymptomScopeActualMaterializedSHA256'],
          'sourceSymptomScopeCanonicalRawGitSHA256': manifest['sourceSymptomScopeCanonicalRawGitSHA256'],
          'symptomCallerOriginScopeAuditSHA256': digest(directory / 'symptom-caller-origin-scope-audit.json'),
          'gitBlobEOLProof': 'Every captured file is byte-exact to the raw committed blob after CRLF normalization; actual captured bytes, not raw-blob bytes, were verified and measured',
          'sourceInventoryFilesVerified': 133, 'measuredNativeMetadataSourceInventoryFiles': 28,
          'sourceInventoryScope': 'Preserved file inventory, broader than each compiler input list',
          'tests': tests, 'specificScheduleScopeMethodsPassed': methods, 'specificReplyFallbackMethodsPassed': reply_methods, 'auxiliaryChecksResultSHA256': digest(directory / 'auxiliary-checks-result.json'), 'native': counts,
          'nativeTotalPassed': 159, 'nativeExecutableSHA256': metadata['executableSHA256'],
          'runtimeFilesVerified': len(metadata['runtimeFilesSHA256']), 'testArtifactsVerified': len(remote['testArtifactsSHA256']),
          'verifierSHA256': digest(Path(__file__)),
          'filesSHA256': {path.relative_to(directory).as_posix(): digest(path) for path in sorted(directory.rglob('*')) if path.is_file()}}
(directory / 'validation-status.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'sourceIdentitySHA256': report['sourceIdentitySHA256'], 'tests': tests, 'nativeTotalPassed': 159,
                  'validationStatusSHA256': digest(directory / 'validation-status.json')}, indent=2))
