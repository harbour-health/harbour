import datetime
import hashlib
import json
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'source-manifest.json').read_text(encoding='utf-8'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for item in manifest['files']:
    assert digest(root / item['path']) == item['sha256']
results = []
for name, command in [
    ('python-integrity', [sys.executable, '-m', 'unittest', 'discover', '-s', 'evaluation', '-p', 'test_*.py', '-v']),
    ('localization-audit', [sys.executable, 'scripts/audit-localization.py', '--root', str(root), '--json']),
]:
    log_path = root / (name + '.log')
    start = time.monotonic()
    with log_path.open('xb') as log:
        process = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    text = log_path.read_text(encoding='utf-8')
    result = {'name': name, 'command': command, 'exitCode': process.returncode, 'elapsedSeconds': time.monotonic() - start,
              'logSHA256': digest(log_path), 'sourceIdentitySHA256': manifest['sourceIdentitySHA256']}
    if name == 'python-integrity':
        found = re.search(r'Ran (\d+) tests', text)
        result['executedTests'] = int(found.group(1)) if found else None
        assert process.returncode == 0 and result['executedTests'] == 60, text[-6000:]
    else:
        report = json.loads(text)
        result['audit'] = report
        assert process.returncode == 0 and not report['errors'], text
    results.append(result)
    print(json.dumps({'name': name, 'exitCode': result['exitCode'], 'executedTests': result.get('executedTests'),
                      'catalogKeys': result.get('audit', {}).get('catalog_keys')}, ensure_ascii=False), flush=True)

app = (root / 'Harbour/ModelManager.swift').read_text(encoding='utf-8')
specifications = runpy.run_path(str(root / 'scripts/cache-eval-models.py'))['MODELS']
def section(start, end):
    return app.split(start, 1)[1].split(end, 1)[0]
size_body = section('var size: Int64 {', 'var hash: String {')
hash_body = section('var hash: String {', 'var filename: String {')
filename_body = section('var filename: String {', 'var url: URL {')
url_body = section('var url: URL {', 'var promptFormat: ModelPromptFormat')
pins = []
for name, spec in specifications.items():
    repository, revision, filename, size, model_sha = spec
    case = r'case\s+(?:\.automatic,\s*)?\.' + name + r'\s*:'
    size_match = re.search(case + r'\s*([0-9_]+)', size_body)
    assert size_match and int(size_match.group(1).replace('_', '')) == size
    assert re.search(case + r'\s*"' + re.escape(model_sha) + r'"', hash_body)
    assert re.search(case + r'\s*"' + re.escape(filename) + r'"', filename_body)
    assert re.search(case + r'\s*repo\s*=\s*"' + re.escape(repository) + r'";\s*revision\s*=\s*"' + re.escape(revision) + r'"', url_body)
    pins.append({'model': name, 'repository': repository, 'revision': revision, 'filename': filename, 'bytes': size, 'sha256': model_sha})
assert re.search(r'static let defaultModel:\s*ModelChoice\s*=\s*\.automatic', app)
assert 'memoryBytes >= 8_000_000_000 && !isLowPowerModeEnabled && thermalState == .nominal ? .balanced : .small' in app
assert 'guard selection == .automatic else { return selection }' in app
assert '#if targetEnvironment(simulator)\n        return .small' in app
policy = json.loads((root / 'evaluation/optional-model-scope-v1.json').read_text(encoding='utf-8'))
assert digest(root / 'evaluation/optional-model-scope-v1.json') == manifest['optionalModelScopeSHA256']
assert policy['defaultPolicy']['freshOrUnknownPreference'] == 'automatic' and policy['defaultPolicy']['qwen35SelectedAutomatically'] is False
provenance = {'scope': 'Static captured app/cache download pin and Automatic policy source audit; not SwiftUI compilation/device behavior',
              'passed': True, 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
              'appSHA256': digest(root / 'Harbour/ModelManager.swift'), 'cacheHelperSHA256': digest(root / 'scripts/cache-eval-models.py'),
              'optionalPolicySHA256': manifest['optionalModelScopeSHA256'], 'pins': pins, 'defaultPolicy': policy['defaultPolicy']}
(root / 'model-source-provenance-audit.json').open('x', encoding='utf-8').write(json.dumps(provenance, indent=2) + '\n')
core = (root / 'HarbourCore/Sources/HarbourCore/ToolPlanner.swift').read_text(encoding='utf-8')
evaluator = (root / 'HarbourRuntime/Sources/ModelEval/main.swift').read_text(encoding='utf-8')
probe = (root / 'HarbourRuntime/Sources/ModelProbe/main.swift').read_text(encoding='utf-8')
assert 'WriteRequestValidation.permits(original, tool: .logReading), let reading = ReadingParser.parse(original)' in core
assert 'action: .reading(reading), reason: "reading_draft"' in core
assert app.index('let decision = try ToolPlanner.parse(output)') < app.index('if let fallback = ToolPlanner.replyFallback(original: input')
assert 'return fallback.decision' in app
assert 'result.routeOutput = raw' in evaluator and 'result.observedTool = decision.tool.rawValue' in evaluator
assert 'result.actionSummary = actionSummary(fallback.action)' in evaluator
assert 'result.actionOrigin = "application"; result.applicationDecision = fallback.decision' in evaluator
assert 'result.rawTool = decision?.tool.rawValue' in probe
assert 'action = fallback.action' in probe and 'result.actionOrigin = "application"; result.applicationDecision = fallback.decision' in probe
reading_scope_path = root / 'evaluation/optional-model-source-reading-scope-v1.json'
reading_scope = json.loads(reading_scope_path.read_text(encoding='utf-8'))
assert digest(reading_scope_path) == manifest['sourceReadingScopeActualMaterializedSHA256']
assert hashlib.sha256(reading_scope_path.read_bytes().replace(b'\r\n', b'\n')).hexdigest() == manifest['sourceReadingScopeCanonicalRawGitSHA256']
assert reading_scope['originalOptionalScopeCanonicalSHA256'] == manifest['optionalModelScopeCanonicalRawGitSHA256']
assert reading_scope['defaultPolicyChanged'] is False and reading_scope['fixtureScorerAndPromotionThresholdsChanged'] is False
reading_audit = {'schemaVersion': 1, 'passed': True,
                 'scope': 'Static captured caller/origin and scope consistency; functional source/bounds/revalidation behavior is covered by actual Core tests, no SwiftUI compilation or model-quality claim',
                 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
                 'sourceReadingScopeActualMaterializedSHA256': manifest['sourceReadingScopeActualMaterializedSHA256'],
                 'sourceReadingScopeCanonicalRawGitSHA256': manifest['sourceReadingScopeCanonicalRawGitSHA256'],
                 'sourceFilesSHA256': {name: digest(root / name) for name in ['HarbourCore/Sources/HarbourCore/ToolPlanner.swift', 'Harbour/ModelManager.swift', 'HarbourRuntime/Sources/ModelEval/main.swift', 'HarbourRuntime/Sources/ModelProbe/main.swift']},
                 'rawRoutingPreserved': True, 'applicationOriginRecordedSeparately': True,
                 'modelQualityOrSavedRecordExecutionEstablished': False}
(root / 'reading-caller-origin-audit.json').open('x', encoding='utf-8').write(json.dumps(reading_audit, indent=2) + '\n')
for item in manifest['files']:
    assert digest(root / item['path']) == item['sha256']
result = {'schemaVersion': 1, 'complete': True, 'scope': 'Committed-source12 Python integrity/localization/static source provenance checks, not model quality or device execution or model accuracy',
          'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
          'checks': results, 'sourceProvenanceAuditSHA256': digest(root / 'model-source-provenance-audit.json'), 'runnerSHA256': digest(Path(__file__))}
result['readingCallerOriginAuditSHA256'] = digest(root / 'reading-caller-origin-audit.json')
(root / 'auxiliary-checks-result.json').open('x', encoding='utf-8').write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'complete': True, 'sourcePinsAndDefaultAudit': 'passed'}), flush=True)
