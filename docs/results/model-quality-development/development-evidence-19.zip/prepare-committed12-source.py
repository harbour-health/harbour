import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'source-manifest.json').read_text(encoding='utf-8'))
archive_path = root / 'source.tar.gz'
assert manifest['sourceCommit'] == '740a797ffcd7f15c9a21c8db8f86d729a362b863'
assert manifest['sourceIdentitySHA256'] == '124682519a119c73d7db451393dd7b8f083f1b24e844634478c17f7ee0e7d11e'
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == manifest['archiveSHA256'] == '413c0d538caf4b043ac35e7d51fb1ca2e371200ec501380c64c5daa19067ae2c'
expected = {item['path']: item for item in manifest['files']}
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    files = [member for member in members if member.isfile()]
    assert len(files) == len(expected) == 133
    assert len({member.name for member in members}) == len(members)
    for member in members:
        name = PurePosixPath(member.name)
        assert member.isdir() or member.isfile()
        assert not name.is_absolute() and '..' not in name.parts
        destination = root.joinpath(*name.parts)
        assert root in destination.resolve().parents
        if member.isdir():
            continue
        assert member.name in expected and not destination.exists()
        data = archive.extractfile(member).read()
        assert len(data) == expected[member.name]['bytes'] and hashlib.sha256(data).hexdigest() == expected[member.name]['sha256']
    archive.extractall(root, filter='data')
for name, item in expected.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == item['sha256']
report = {'schemaVersion': 1, 'sourceCommit': manifest['sourceCommit'], 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
          'sourceInventoryFilesVerified': len(expected), 'archiveMembers': len(members), 'directoryMembers': len(members) - len(files),
          'preparationSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root / 'source-preparation-result.json').open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
