import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--expected-core-tests', type=int, required=True)
args = parser.parse_args()
workspace = Path(__file__).resolve().parent
manifest_path = workspace / 'source-manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
prefix = Path('/evalcache/linux-runtime-v2')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_source():
    for entry in manifest['files']:
        path = workspace / entry['path']
        assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256'], entry['path']

verify_source()
runtime_metadata = json.loads((prefix / 'harbour-runtime.json').read_text(encoding='utf-8'))
runtime_files = {path.relative_to(prefix).as_posix(): digest(path) for path in sorted(prefix.rglob('*')) if path.is_file()}
environment = dict(os.environ, HARBOUR_LINUX_RUNTIME='1', HARBOUR_DEVICE_RUNTIME='0', SWIFT_DETERMINISTIC_HASHING='1',
                   PKG_CONFIG_PATH=str(prefix / 'lib/pkgconfig'), LD_LIBRARY_PATH=str(prefix / 'lib'))
environment.pop('SDKROOT', None)
for package, expected in [('HarbourCore', args.expected_core_tests), ('HarbourRuntime', 21)]:
    log = workspace / (package + '-swift-test.log')
    report_path = workspace / (package + '-test-result.json')
    if log.exists() or report_path.exists():
        raise SystemExit('Refusing to overwrite test evidence')
    start = time.monotonic()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    command = ['swift', 'test', '--configuration', 'release', '--jobs', '4']
    with log.open('xb') as output:
        process = subprocess.run(command, cwd=workspace / package, env=environment, stdout=output, stderr=subprocess.STDOUT)
    log_text = log.read_text(encoding='utf-8', errors='replace')
    found = re.findall(r'Executed (\d+) tests?, with (\d+) failures?', log_text)
    full_count, failures = (int(value) for value in found[-1]) if found else (None, None)
    artifacts = {path.relative_to(workspace).as_posix(): digest(path) for path in sorted((workspace / package / '.build').rglob('*'))
                 if path.is_file() and (path.name.endswith('Tests.so') or path.name.endswith('Tests-test-runner') or path.suffix == '.xctest')}
    verify_source()
    report = {'schemaVersion': 1, 'complete': True, 'scope': 'Fresh committed-source12 correctness only; no model generation or device execution',
              'package': package, 'expectedTests': expected, 'executedTests': full_count, 'failures': failures,
              'startedUTC': started, 'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'elapsedSeconds': time.monotonic() - start, 'exitCode': process.returncode,
              'expectedCountSatisfied': full_count == expected and failures == 0,
              'command': command, 'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
              'sourceArchiveSHA256': manifest['archiveSHA256'], 'sourceManifestSHA256': digest(manifest_path),
              'sourceInventoryScope': 'Preserved exact source inventory; broader than per-file compiler input lists',
              'logSHA256': digest(log), 'runnerSHA256': digest(Path(__file__)),
              'swiftVersion': subprocess.check_output(['swift', '--version'], text=True).strip(),
              'testArtifactsSHA256': artifacts, 'testArtifactScope': 'SwiftBuild native XCTest shared object and runner, or SwiftPM xctest executable, when produced',
              'runtime': runtime_metadata, 'runtimeFilesSHA256': runtime_files,
              'environment': {key: environment[key] for key in ['HARBOUR_LINUX_RUNTIME', 'HARBOUR_DEVICE_RUNTIME', 'SWIFT_DETERMINISTIC_HASHING', 'PKG_CONFIG_PATH', 'LD_LIBRARY_PATH']}}
    report_path.open('x', encoding='utf-8').write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    print(log_text[-1800:], flush=True)
    if process.returncode or full_count != expected or failures != 0:
        raise SystemExit(process.returncode or 1)
