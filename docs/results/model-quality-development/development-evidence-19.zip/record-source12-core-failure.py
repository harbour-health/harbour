"""Preserve the failed source12 Core outcome without executing later gates."""
import datetime
import hashlib
import json
from pathlib import Path
import re

directory = Path(__file__).resolve().parent
cohort = directory / 'committed-source12'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = json.loads((cohort/'HarbourCore-test-result.json').read_bytes())
assert report['executedTests'] == 210 and report['failures'] == 13 and report['exitCode'] == 1
manifest = json.loads((cohort/'source-manifest.json').read_bytes())
assert manifest['sourceCommit'] == '740a797ffcd7f15c9a21c8db8f86d729a362b863'
log = (cohort/'HarbourCore-swift-test.log').read_text(encoding='utf-8')
errors = [line for line in log.splitlines() if re.search(r'error: .*XCT(?:Assert|Unwrap)', line)]
assert len(errors) == 13, len(errors)
later = ['HarbourRuntime-test-result.json', 'native-diagnostics.json', 'validation-status.json']
assert all(not (cohort/name).exists() for name in later)
files = ['source.tar.gz', 'source-manifest.json', 'source-preparation-result.json',
         'HarbourCore-test-result.json', 'HarbourCore-swift-test.log']
receipt = {
    'schemaVersion': 1,
    'recordedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceCommit': manifest['sourceCommit'],
    'sourceIdentitySHA256': manifest['sourceIdentitySHA256'],
    'sourceArchiveSHA256': manifest['archiveSHA256'],
    'Core': {'tests': 210, 'failedAssertions': 13, 'failedMethods': 4, 'exitCode': 1,
             'startedUTC': report['startedUTC'], 'finishedUTC': report['finishedUTC']},
    'failedAssertions': errors,
    'evidence': [{'path': name, 'bytes': (cohort/name).stat().st_size, 'sha256': sha(cohort/name)} for name in files],
    'notExecuted': ['Runtime tests', 'native diagnostics', 'Python tests', 'localization audit',
                    'xtool build', 'source12 DEV or supplemental', 'heldout'],
    'scope': 'Immutable failed implementation snapshot retained. This receipt does not claim a passed build or model-quality result.',
    'frozenFixtureAndScorerChanged': False,
    'helperSHA256': sha(Path(__file__)),
}
(cohort/'failed-core-preservation.json').open('x', encoding='utf-8').write(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'preserved': True, 'tests': 210, 'failedAssertions': 13,
                  'receiptSHA256': sha(cohort/'failed-core-preservation.json')}))
