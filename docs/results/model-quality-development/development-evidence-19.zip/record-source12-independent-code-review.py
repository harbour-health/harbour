"""Record read-only exact-file review; execute no source helpers or tests."""
import ast
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
files = {
    "HarbourCore/Sources/HarbourCore/VisitSourceGrounding.swift": "c9a597a63a759a501da5dcd5fe5374accd1529fabfcb24f7cd2d434c614cfd92",
    "HarbourCore/Sources/HarbourCore/Visits.swift": "5532f0796453ee9e27bcd8ea6fb44047bbae1560827956d952056290efce8d93",
    "HarbourCore/Tests/HarbourCoreTests/VisitSourceGroundingTests.swift": "1f8f595ac6f2aa3f018537b18b5de584dfe74db0f3ea7c30d94225578d149269",
    "HarbourCore/Sources/HarbourCore/ToolPlanner.swift": "c99967ba74b6e9aad6d4713769203b55d3204eb0306fac9561e67291a502b53a",
    "HarbourCore/Tests/HarbourCoreTests/ReplyFallbackTests.swift": "aa69d91d565d0aa592c1458e18f19c76e83edfa8c706e17d0ec14db556ce2c99",
    "evaluation/optional-model-source-question-scope-v1.json": "d8cc1e2d4535cee9c0bc495b3d5110ff9667795cab4770d9df355ae0c6343b1d",
    "evaluation/optional-model-source-reminder-scope-v1.json": "e851c3c544fd1169ecfa6d1d94a60114d5fb15e0736fa759eb7296c0b3882011",
}
for name, expected in files.items(): assert sha(ROOT / name) == expected, name
manifest = ROOT / "build/model-quality/visit-source-completeness-fix-01/revision04/candidate-manifest.json"
patch = manifest.with_name("visit-source-completeness-fix-04.patch")
assert sha(manifest) == "86b8d98d1649b21a2b40f5a03be5ea92be085147dfb4f3d06e3a7ea974b551e6"
if not patch.exists():
    matches = [p for p in manifest.parent.glob("*.patch") if sha(p) == "b6873cf7643f07a55b04fb700ad2f8dd880bfa9ee272c33bed89912957a3c8eb"]
    assert len(matches) == 1; patch = matches[0]
assert sha(patch) == "b6873cf7643f07a55b04fb700ad2f8dd880bfa9ee272c33bed89912957a3c8eb"
helper = ROOT / "build/model-quality/prepare-source12-correctness-helpers.py"
assert sha(helper) == "2319dec84a2d50798d3521f3475838575946e0adca742e889d9794eeec66c44e"
helper_text = helper.read_text(encoding="utf-8"); ast.parse(helper_text)
result = {"formatVersion": 1, "kind": "source12-independent-readonly-code-review", "createdUTC": dt.datetime.now(dt.timezone.utc).isoformat(),
    "recorderSHA256": sha(Path(__file__)), "reviewedSource": [{"path": name, "sha256": digest} for name, digest in files.items()],
    "byteScope": "Exact working-file bytes reviewed before/around Root's commit740a797. The future compiled materialization and raw Git EOL identities are separately captured; this review does not relabel these working hashes as compiled-input hashes.",
    "medicineRevision04": {"manifestSHA256": sha(manifest), "patchSHA256": sha(patch), "decision": "accepted_for_fresh_tests", "remainingConcreteFindings": [],
        "reviewedContracts": ["Whole medicine-specific dose/frequency/clock/direction spans must match; shared or borrowed spans remain rejected.",
            "Explicit joined appointment/test/call/return/repeat actions bound the medicine clause at and/et/comma/semicolon with bounded courtesy; their clocks cannot become medicine schedule clocks.",
            "Complete unsupported calendar/course/weekday source statements are retained before completeness rejects medicine proposals.",
            "Displayed qualified quotes preserve complete negation, history, conditions, exceptions and courses; only one terminal full stop may be omitted, never decimal digits, question/exclamation marks or ellipsis runs.",
            "Stop instructions remain empty and saved-draft applying revalidates through production parse; the independent controls cover shortened direction and follow-up-clock tampering.",
            "Empty saved names cannot stall enumeration; explicit separately attributed compound directions remain supported."]},
    "questionReminder": {"decision": "followup_required_for_recognized_question_typed_write_contradiction",
        "reviewedPositiveContracts": ["Only finite whole-source current organizational reminder tasks recover; clinical, ambiguous, malformed, quoted outer and compound tails stay outside that recovery.",
            "Saved question matching retains the existing CareRules.question extraction contract and all original question contents/quotes; quoted clinical questions are data, not operations.",
            "Recovery calls validate only saveQuestion/createReminder, whose branches return directly; no recursive reply validation or model invocation is added.",
            "The existing captureSymptom and reminder/createAppointment contradiction guards reject their specified wrong typed writes.",
            "All21 raw routing alternatives and existing prompts/defaults/token budgets/sampler/scorer/fixture expectations remain unchanged in this patch."],
        "finding": {"title": "Closed saved-question requests can still validate as other record writes", "status": "static_code_counterexample_reported_to_Root_before_freeze", "runtimeCounterexampleExecuted": False,
            "examples": ["Add this question: Can I take aspirin?", "Enregistre cette question : « Puis-je prendre aspirine? »", "Add this question: Is my blood pressure 120/80 normal?"],
            "trace": "The finite question recognizer accepts the outer question target. Wrong add/log-reading validation currently lacks that target check: generic WriteRequestValidation permits the shared outer add/enregistre verb, and medicine/reading parsing then consumes the question payload. ModelManager gives a validated nonreply priority before question recovery. Other saved-medicine write branches can similarly inspect body names/frequency. No persisted operation or new model output is claimed.",
            "boundedCorrection": "Apply the already-existing finite recognized-question target consistently to contradictory write validation, while leaving saveQuestion/createReminder recovery validation nonrecursive. Preserve raw routing failure/application origin and add independent examples to an existing question method.",
            "scope": "Same closed request grammar already authorized; no early model tool classifier, output-phrase rule, new fixture or threshold."}},
    "preparedCorrectnessHelper": {"path": str(helper.relative_to(ROOT)), "sha256": sha(helper), "ASTValid": True,
        "decision": "prepared_helper_binding_and_label_checks_accepted", "executionScope": "Read source, AST and help only; no capture, build, tests or model execution by reviewer.",
        "contracts": ["Requires accepted40-character commit and Root GO; static Core/reply method counts are read from the actual committed blobs before execution.",
            "New capture/helper outputs refuse overwrite; old source11 helpers and receipts remain preserved.",
            "Actual git-archive byte hashes, raw Git blobs, EOL difference and source identity remain separately recorded; canonical policy/reading/symptom and frozen fixture hashes are preserved.",
            "The symptom sequence supplies required --reason=symptom_draft and the embedded Core200 scope label is now adapted to the committed count."],
        "initialObservationCorrection": "An initial review command had a PowerShell quoting syntax error before execution; corrected local AST/hash reads succeeded. No source/helper capture or model/test process was affected."},
    "scope": "Independent read-only source review, not test success, model-quality/clinical validation, default-promotion waiver, final source freeze or held-out authorization. Medicine/helper approval is for fresh checks. The recognized-question typed-write finding remains explicit; previously sent overall no-blocker wording was premature for that boundary. Root's immutable source12 tests may complete separately but do not establish resolution of this new counterexample."}
path = ROOT / "build/model-quality/source12-independent-code-review.json"
with path.open("x", encoding="utf-8", newline="\n") as stream: stream.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"path": str(path.relative_to(ROOT)), "sha256": sha(path), "medicine": "accepted_for_fresh_tests", "questionTarget": "followup_required"}))
