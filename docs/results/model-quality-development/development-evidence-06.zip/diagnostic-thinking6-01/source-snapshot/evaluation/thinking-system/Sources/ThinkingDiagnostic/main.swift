import Foundation
import HarbourRuntime

private struct DiagnosticCase: Decodable {
    let id: String
    let language: String
    let prompt: String
}
private struct DiagnosticSuite: Decodable {
    let id: String
    let cases: [DiagnosticCase]
}
private struct DiagnosticResult: Encodable {
    let caseID: String
    let kind = "qwen35_thinking_diagnostic"
    let model: String
    let language: String
    let coldLoad: Bool
    let budget = 2048
    let context = 4096
    let batch = 512
    let threads = max(1, min(4, ProcessInfo.processInfo.processorCount - 2))
    let grammar: String? = nil
    let stopAtJSON = false
    let sampler = "production greedy"
    let prompt: String
    var promptTokens: Int?
    var output = ""
    var seconds: Double = 0
    var error: String?
    var thinkDelimiterPresent = false
    var finalAnswer: String?
    var failureToProduceFinal: String?
    let rawGenerationStopCause = "unknown: production actor returns text only"
    let finalCompletenessRequiresManualReview = true
}

@main private enum ThinkingDiagnostic {
    static func main() async throws {
        var arguments = Array(CommandLine.arguments.dropFirst()), values: [String: String] = [:]
        while !arguments.isEmpty {
            let key = arguments.removeFirst()
            guard ["--model", "--model-id", "--suite", "--output"].contains(key), !arguments.isEmpty, values[key] == nil else {
                throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid or repeated diagnostic argument: \(key)"])
            }
            values[key] = arguments.removeFirst()
        }
        guard let modelPath = values["--model"], let modelID = values["--model-id"],
              modelID == "qwen35", let suitePath = values["--suite"], let outputPath = values["--output"] else {
            throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require model, model-id, suite and output"])
        }
        let suite = try JSONDecoder().decode(DiagnosticSuite.self, from: Data(contentsOf: URL(fileURLWithPath: suitePath)))
        guard suite.cases.count == 6, Set(suite.cases.map(\.id)).count == 6,
              suite.cases.allSatisfy({ ["en", "fr-CA"].contains($0.language) }) else {
            throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require six unique preregistered bilingual cases"])
        }
        let output = URL(fileURLWithPath: outputPath)
        try Data().write(to: output, options: .withoutOverwriting)
        let stream = try FileHandle(forWritingTo: output)
        defer { try? stream.close() }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        let actor = LocalModel(useGPU: false)
        let model = URL(fileURLWithPath: modelPath)
        let format: ModelPromptFormat = .qwen25
        for (index, fixture) in suite.cases.enumerated() {
            guard fixture.prompt.hasSuffix("<|im_start|>assistant\n<think>\n") else {
                throw NSError(domain: "DiagnosticOptions", code: 1, userInfo: [NSLocalizedDescriptionKey: "Require exact official enable_thinking=true generation prefix"])
            }
            let prepared = try format.prepare(fixture.prompt)
            var result = DiagnosticResult(caseID: fixture.id, model: modelID, language: fixture.language, coldLoad: index == 0, prompt: prepared)
            let started = Date()
            do {
                result.promptTokens = try await actor.tokenCount(file: model, prompt: fixture.prompt, promptFormat: format)
                result.output = try await actor.generate(file: model, prompt: fixture.prompt, maxTokens: 2048, grammar: nil, stopAtJSON: false, promptFormat: format)
                if let delimiter = result.output.range(of: "</think>") {
                    result.thinkDelimiterPresent = true
                    let final = String(result.output[delimiter.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                    if final.isEmpty { result.failureToProduceFinal = "Empty final answer after thinking delimiter" }
                    else { result.finalAnswer = final }
                } else {
                    result.failureToProduceFinal = "No complete thinking delimiter/final answer within 2048-token generation budget"
                }
            } catch {
                result.error = error.localizedDescription
                result.failureToProduceFinal = "Generation failed"
            }
            result.seconds = Date().timeIntervalSince(started)
            try stream.write(contentsOf: encoder.encode(result) + Data([10]))
            FileHandle.standardError.write(Data("\(modelID) diagnostic \(fixture.id) error=\(result.error ?? "none") seconds=\(String(format: "%.2f", result.seconds))\n".utf8))
        }
        await actor.unload()
        FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject: ["suite": suite.id, "rows": 6, "complete": true, "releaseEvidence": false], options: [.sortedKeys]))
        FileHandle.standardOutput.write(Data([10]))
    }
}
