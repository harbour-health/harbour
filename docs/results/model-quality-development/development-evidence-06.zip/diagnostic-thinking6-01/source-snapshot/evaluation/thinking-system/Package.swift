// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "ThinkingDiagnostic",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "thinking-diagnostic", targets: ["ThinkingDiagnostic"])],
    dependencies: [.package(path: "../../HarbourRuntime")],
    targets: [.executableTarget(name: "ThinkingDiagnostic", dependencies: [.product(name: "HarbourRuntime", package: "HarbourRuntime")])]
)
