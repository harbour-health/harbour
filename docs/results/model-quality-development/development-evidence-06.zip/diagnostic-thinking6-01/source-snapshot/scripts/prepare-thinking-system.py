#!/usr/bin/env python3
"""Seal Qwen3.5 thinking diagnostics by changing only the original generation prefix and budget."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-registration', type=Path, required=True)
    parser.add_argument('--focused-run', type=Path, required=True)
    parser.add_argument('--controls-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    original = json.loads(args.source_registration.read_text(encoding='utf-8'))
    rows = {}
    for phase in [args.focused_run, args.controls_run]:
        metadata = json.loads((phase / 'metadata.json').read_text(encoding='utf-8'))
        assert metadata['complete'] is True and metadata['sourceSHA256'] == original['originalSourceSHA256']
        for line in (phase / 'qwen35.jsonl').read_text(encoding='utf-8').splitlines():
            row = json.loads(line)
            if row['caseID'] in {case['id'] for case in original['cases']}:
                assert row['caseID'] not in rows
                rows[row['caseID']] = row
    closed = '\n<think>\n\n</think>\n\n'
    opened = '\n<think>\n'
    cases = []
    for case in original['cases']:
        row = rows[case['id']]
        prompt = row['prompt']
        assert hashlib.sha256(prompt.encode()).hexdigest() == case['originalPreparedPromptSHA256']['qwen35']
        assert prompt.endswith('<|im_start|>assistant' + closed)
        thinking = prompt[:-len(closed)] + opened
        assert thinking[:-len(opened)] == prompt[:-len(closed)]
        cases.append({'id': case['id'], 'language': case['language'], 'prompt': thinking,
            'originalPreparedPromptSHA256': hashlib.sha256(prompt.encode()).hexdigest(),
            'thinkingPreparedPromptSHA256': hashlib.sha256(thinking.encode()).hexdigest()})
    paths = ['evaluation/thinking-system/Package.swift', 'evaluation/thinking-system/Sources/ThinkingDiagnostic/main.swift', 'scripts/prepare-thinking-system.py', 'scripts/evaluate-thinking-system.py']
    registration = {'schemaVersion': 1, 'id': 'qwen35-official-thinking-factual-diagnostic-v1',
        'preregisteredUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'releaseEvidence': False,
        'baseCommit': original['baseCommit'], 'originalSourceSHA256': original['originalSourceSHA256'],
        'runtimeFilesSHA256': original['runtimeFilesSHA256'], 'models': [model for model in original['models'] if model['model'] == 'qwen35'],
        'sourceRegistrationSHA256': digest(args.source_registration), 'sourceStreams': original['sourceStreams'],
        'diagnosticSourceSHA256': {path: digest(ROOT / path) for path in paths},
        'design': 'Exact original source80d full system policy/snapshot/history/user messages retained. Only official enable_thinking=true generation suffix and output budget change; no answer facts enter prompts.',
        'officialTemplate': 'https://huggingface.co/Qwen/Qwen3.5-2B/raw/main/chat_template.jinja',
        'pinnedGGUFTemplateSHA256': '7f0e529032c25183bcd66c7f238da2d377f43be754a94e2725a58c4e16d2ed67',
        'settings': {'context': 4096, 'batch': 512, 'physicalMicrobatch': 512, 'threads': 4, 'backend': 'Linux CPU', 'sampling': 'production greedy', 'maxTokens': 2048, 'grammar': None, 'stopAtJSON': False, 'thinking': 'exact official assistant newline + open think newline', 'promptFormat': 'qwen25 passthrough of already prepared Qwen3.5 thinking prompt', 'order': ['qwen35'], 'repetitions': 1},
        'completionPolicy': 'Raw generation stop cause is unknown. Require complete </think> delimiter and nonempty final; a human must confirm final completeness and the existing factual/language rubric. Missing or incomplete finals are quality failures.',
        'cases': cases}
    with args.output.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(registration, output, indent=2, ensure_ascii=False)
        output.write('\n')
    print(json.dumps({'sha256': digest(args.output), 'cases': len(cases)}))

if __name__ == '__main__':
    main()
