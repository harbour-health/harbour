"""Root-only Archive34 check/build: current d84 Standard PASS / Native FAIL.

Retains observed refusal and exact original proofs; no cause, source fix,
model-quality verdict, success binder, freeze or held-out authorization.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'build/archive-development-34'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--selection', type=Path, required=True)
parser.add_argument('--selection-sha256', required=True)
mode = parser.add_mutually_exclusive_group(required=True)
mode.add_argument('--check-only', action='store_true')
mode.add_argument('--build', action='store_true')
parser.add_argument('--root-reviewed-build-go', action='store_true')
args = parser.parse_args()
assert not args.build or args.root_reviewed_build_go
assert sha(args.selection) == args.selection_sha256
selection = read(args.selection)
assert selection['sourceHead'] == 'd84fe754e94a267572974a40f977ae61bf354894'
assert selection['finalSelection'] is True and selection['currentAppGate'] == 'BLOCKED_NATIVE_FAILURE'
assert selection['fileCount'] == len(selection['files'])
assert selection['totalUncompressedBytes'] == sum(ref['bytes'] for ref in selection['files'])

def verify(ref):
    path = (ROOT / ref['source']).resolve()
    assert path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink()
    assert path.stat().st_size == ref['bytes'] and sha(path) == ref['sha256']
    return path

names = set()
private_address = '.'.join(str(n) for n in (100, 83, 225, 2)).encode()
for ref in selection['files']:
    path = verify(ref)
    assert ref['source'] not in names and path.stat().st_size < 8 * 1024 * 1024
    names.add(ref['source'])
    assert private_address not in path.read_bytes()
    assert path.suffix.lower() not in {'.zip', '.gz', '.gguf', '.so', '.exe', '.mp4', '.pyc', '.sqlite3'}
    assert not any(part in {'.build', 'Data'} or part.endswith(('.xcresult', '.app', '.xtoolsdk')) for part in path.parts)
    assert not path.read_bytes().startswith((b'MZ', b'\x7fELF', b'GGUF'))
assert len(selection['previousArchives']) == 33
for ref in selection['previousArchives']:
    verify(ref)
audit = read(verify(selection['actualSplitAudit']))
assert audit['result'] == 'PASS_BYTE_COUNTS_AND_SOURCE_BINDINGS_STANDARD_SUCCESS_NATIVE_FAILURE'
assert audit['sourceHead'] == selection['sourceHead'] and audit['canonicalSourceFiles'] == 135
assert audit['currentAppGate'] == 'BLOCKED_NATIVE_FAILURE' and audit['actualFullNativeGatePassed'] is False
assert audit['nativeFailure']['sourceLine'] == 1518 and audit['nativeFailure']['navigationAndFinalMedicineAssertionsReached'] is False
assert audit['currentSuccessBinderOrFullNativePassCreated'] is False
assert audit['freezeHeldoutAuthorizationReadyOrClinicalSafetyClaimed'] is False
assert audit['runs']['standard']['runID'] == 38483988424 and audit['runs']['standard']['conclusion'] == 'success'
assert audit['runs']['native']['runID'] == 38483988404 and audit['runs']['native']['conclusion'] == 'failure'
for kind in ('standard', 'native'):
    run = audit['runs'][kind]
    assert run['packages']['HarbourCorePackageTests.xctest']['passed'] == 216
    assert run['packages']['HarbourRuntimePackageTests.xctest']['passed'] == 21
    assert run['counts'] == selection['observedCounts'][kind]
    for ref in run['bindings'].values():
        path = ROOT / ref['path']
        assert path.stat().st_size == ref['bytes'] and sha(path) == ref['sha256']
    for artifact in run['artifacts']:
        path = ROOT / artifact['archive']['path']
        assert path.stat().st_size == artifact['archive']['bytes'] and sha(path) == artifact['archive']['sha256']
        assert artifact['CRCAndEveryRetainedReceiptMemberHashVerified'] is True
assert len(selection['canonicalSourceFiles']) == 135
manifest = read(verify(selection['actualSourceManifest']))
assert manifest['sourceHead'] == selection['sourceHead'] and len(manifest['files']) == 135
assert manifest['checkoutTreeEqualsHeadTree'] is True and manifest['gitTree'] == audit['canonicalGitTree']
for item in manifest['files']:
    ref = selection['canonicalSourceFiles'][item['path']]
    assert ref['sha256'] == item['sha256'] and ref['bytes'] == item['bytes']
    verify(ref)
summary = {'schemaVersion': 1, 'checkedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'sourceHead': selection['sourceHead'], 'actualCheckout': audit['actualCheckout'],
           'selectionSHA256': args.selection_sha256, 'fileCount': len(names),
           'totalUncompressedBytes': selection['totalUncompressedBytes'], 'observedCounts': selection['observedCounts'],
           'currentAppGate': 'BLOCKED_NATIVE_FAILURE', 'nativeFailure': audit['nativeFailure'],
           'scope': selection['selectedScope'], 'externalExcluded': selection['externalExcluded'],
           'previousArchives01To33VerifiedUnchanged': True, 'causeClaimed': False,
           'sourceFixOrNewTestModelScorerTransportNetworkFreezeHeldoutOrReadyInvoked': False,
           'originalModelAndTestedAppProofIdentitiesRetained': True, 'builderSHA256': sha(Path(__file__)),
           'zipBuilt': bool(args.build)}
if args.check_only:
    path = OUT / 'preflight.json'
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'preflight': str(path), 'sha256': sha(path), 'files': len(names)}))
else:
    path = OUT / 'development-evidence-34.zip'
    assert not path.exists() and not (OUT / 'summary-34.json').exists()
    manifest_raw = (json.dumps({'schemaVersion': 1, 'evidenceFiles': selection['files'], 'selectedEvidenceCount': len(names),
                               'selectionSHA256': args.selection_sha256, 'summary': summary}, ensure_ascii=False, indent=2) + '\n').encode()
    with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for ref in selection['files']:
            archive.write(verify(ref), ref['source'])
        archive.write(args.selection, 'archive34-selection.json')
        archive.write(Path(__file__), 'archive34-builder.py')
        archive.writestr('manifest.json', manifest_raw)
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.infolist()) == len(names) + 3
    summary.update(archiveSHA256=sha(path), archiveBytes=path.stat().st_size, archiveMembers=len(names) + 3,
                   manifestSHA256=hashlib.sha256(manifest_raw).hexdigest())
    with (OUT / 'summary-34.json').open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'archive': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size, 'members': len(names) + 3}))
