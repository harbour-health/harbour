"""Build only an explicitly reviewed public evidence allowlist; never discover or grade model data."""
import argparse, hashlib, io, ipaddress, json, pathlib, re, sys, zipfile, zlib
ROOT = pathlib.Path(__file__).resolve().parents[2]
ROLES = {'final-report','source-code-binding','local-proof','current-ci-proof','dev-generation-review-and-paired-proof','exposed-v1-generation-review-and-two-baseline-proof','catalog-generation-review-and-source-safety-proof','old-v1-reuse-proof','raw-prose-projection-proof','all-stages-raw-versus-accepted-proof','retained-failure-provenance','frozen-protocol-and-scorer'}
RESERVED = {'MANIFEST.json','SCOPE.json','REPRODUCE.py'}
FORBIDDEN_PARTS = {'.git','.ssh','round2-sealed','node_modules','original-artifacts','Data','sdk','xcode','weights'}
FORBIDDEN_SUFFIXES = {'.gguf','.xtoolsdk','.xip','.pem','.key','.p12','.pfx','.exe','.dll','.dylib','.so','.ipa','.mov','.mp4','.aesgcm'}
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(o): return (json.dumps(o,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def safe_member(s):
    assert isinstance(s,str) and '\\' not in s and ':' not in s
    p=pathlib.PurePosixPath(s); assert not p.is_absolute() and p.parts and all(x not in {'.','..'} for x in p.parts)
    assert str(p)==s and s not in RESERVED; return s
def safe_path(s):
    assert isinstance(s,str) and not pathlib.Path(s).is_absolute()
    original=ROOT/s; assert not original.is_symlink()
    p=original.resolve(); assert p.is_relative_to(ROOT) and p.is_file()
    relative=p.relative_to(ROOT)
    assert not ({x.lower() for x in relative.parts}&{x.lower() for x in FORBIDDEN_PARTS})
    assert not any(x.lower().endswith(('.app','.xcresult')) for x in relative.parts)
    assert p.suffix.lower() not in FORBIDDEN_SUFFIXES
    assert not re.search(r'(?:local-private|stderr-local-only|originalsshargv|credentials|id_rsa|id_ed25519)',s,re.I)
    return p
def check_digest(v):
    assert re.fullmatch('[0-9a-f]{64}',v['sha256']) and type(v['bytes']) is int and v['bytes']>=0
def privacy_check(b,label):
    # Byte-preserving checks only. Explicit human public-allowlist review is also mandatory.
    try: text=b.decode('utf-8-sig')
    except UnicodeDecodeError:
        assert label.endswith('source.tar.gz'), ('nontext payload not explicitly supported',label)
        raise AssertionError('Source TAR must be a hash-only external reference; archive selected public source text instead')
    assert not re.search(r'-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----',text)
    assert not re.search(r'\b(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|sk-[A-Za-z0-9]{30,})\b',text)
    for candidate in re.findall(r'(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])',text):
        try: addr=ipaddress.ip_address(candidate)
        except ValueError: continue
        assert not (addr.is_private or addr.is_loopback or addr.is_link_local or addr in ipaddress.ip_network('100.64.0.0/10')), ('private host address requires labelled privacy derivative',label)
    assert not re.search(r'\b(?:ssh|scp|sftp)\s+(?:-[A-Za-z]+\s+)*[^\s]+@',text), ('private transport command',label)
def zipped(name,b):
    z=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));z.compress_type=zipfile.ZIP_DEFLATED;z.create_system=3;z.external_attr=0o100644<<16
    return z,b
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--workspace',type=pathlib.Path,default=pathlib.Path.cwd())
ap.add_argument('--selection',type=pathlib.Path,required=True);ap.add_argument('--selection-sha256',required=True)
ap.add_argument('--output',type=pathlib.Path,required=True)
mode=ap.add_mutually_exclusive_group(required=True);mode.add_argument('--check-only',action='store_true');mode.add_argument('--build',action='store_true')
args=ap.parse_args();ROOT=args.workspace.resolve();assert ROOT.is_dir()
selectionp=args.selection.resolve();selection_bytes=selectionp.read_bytes();assert sha(selection_bytes)==args.selection_sha256
privacy_check(selection_bytes,'selection-original.json')
s=json.loads(selection_bytes);assert s['schemaVersion']==1 and s['kind']=='round2-public-evidence-exact-allowlist'
assert re.fullmatch('[0-9a-f]{40}',s['sourceCommit']) and re.fullmatch('[0-9a-f]{64}',s['materializedSourceIdentitySHA256'])
assert s['publicityReviewedBy'] and s['label'] and s['limitations']
output=args.output.resolve();assert output.is_relative_to(ROOT) and not output.exists()
assert isinstance(s['files'],list) and 1<=len(s['files'])<=3000
members={};roles=set();sources=[];paths=set()
for v in s['files']:
    p=safe_path(v['path']);name=safe_member(v['archivePath']);check_digest(v)
    assert name not in members and p not in paths
    b=p.read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256'];assert len(b)<=64_000_000
    assert v['role'] and v['publicity'] in {'public-original','public-labelled-derivative'}
    if v['publicity']=='public-labelled-derivative':
        check_digest(v['originalBinding']);assert v.get('derivationDescription')
    privacy_check(b,v['path']);members[name]=b;paths.add(p);roles.add(v['role']);sources.append(dict(path=v['path'],archivePath=name,role=v['role'],bytes=len(b),sha256=sha(b),publicity=v['publicity'],**({k:v[k] for k in ['originalBinding','derivationDescription'] if k in v})))
assert ROLES<=roles, ('missing required roles',sorted(ROLES-roles))
check_digest(s['finalReport']);finalp=safe_path(s['finalReport']['path']);assert finalp in paths
assert len(finalp.read_bytes())==s['finalReport']['bytes'] and sha(finalp.read_bytes())==s['finalReport']['sha256']
assert any(v['role']=='final-report' and safe_path(v['path'])==finalp for v in s['files'])
for v in s.get('externalReferences',[]):
    assert v['included'] is False and v['role'] and v['reference'];check_digest(v)
    privacy_check(canonical(v),'external-reference')
scope=dict(schemaVersion=1,kind='public-evidence-archive-scope',label=s['label'],sourceCommit=s['sourceCommit'],materializedSourceIdentitySHA256=s['materializedSourceIdentitySHA256'],limitations=s['limitations'],externalReferences=s.get('externalReferences',[]),originalVersusDerivedLabelsPreserved=True,archiveGrantsQualityReadinessDefaultPromotionOrHeldoutAuthorization=False,modelTrainingScoringSourceModificationOrUploadExecutedByBuilder=False)
builder_bytes=pathlib.Path(__file__).read_bytes()
manifest=dict(schemaVersion=1,label=s['label'],selectionSHA256=sha(selection_bytes),publicityReviewedBy=s['publicityReviewedBy'],files=sorted(sources,key=lambda v:v['archivePath']),scopeSHA256=sha(canonical(scope)),builderSHA256=sha(builder_bytes),builderRuntime=dict(python=sys.version,zlib=zlib.ZLIB_VERSION),members=len(members)+3,payloadBytes=sum(len(b) for b in members.values()))
privacy_check(canonical(scope),'SCOPE.json');privacy_check(canonical(manifest),'MANIFEST.json')
members['MANIFEST.json']=canonical(manifest);members['SCOPE.json']=canonical(scope);members['REPRODUCE.py']=builder_bytes
assert sum(len(b) for b in members.values())<=256_000_000
for v in sources:
    p=safe_path(v['path']);b=p.read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']
if args.check_only:
    print(json.dumps(dict(status='CHECK_ONLY_PASS',selectionSHA256=sha(selection_bytes),files=len(sources),members=len(members),payloadBytes=manifest['payloadBytes'],archiveWritten=False)));raise SystemExit(0)
output.mkdir(parents=True,exist_ok=False)
archive=output/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,b in sorted(members.items()):
        info,data=zipped(name,b);z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and z.namelist()==sorted(members)
    assert all(z.read(name)==b for name,b in members.items())
summary=dict(schemaVersion=1,status='BUILT_EXACT_EXPLICIT_PUBLIC_EVIDENCE',label=s['label'],selectionSHA256=sha(selection_bytes),archiveSHA256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,manifestSHA256=sha(members['MANIFEST.json']),scopeSHA256=sha(members['SCOPE.json']),members=len(members),files=len(sources),noQualityOrReadinessGrant=True,noUpload=True)
privacy_check(canonical(summary),'summary.json')
(output/'summary.json').write_bytes(canonical(summary));(output/'selection-original.json').write_bytes(selection_bytes)
print(json.dumps(summary))
