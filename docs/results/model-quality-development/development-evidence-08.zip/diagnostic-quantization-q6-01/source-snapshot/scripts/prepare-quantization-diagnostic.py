#!/usr/bin/env python3
"""Seal a same-model Q6 diagnostic using original gold-free inputs and compiled production harness."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CASE_IDS = ['prose.sky.en', 'prose.sky.fr-CA', 'control.soap_grease.en',
            'control.zipper.fr-CA', 'control.frost.en', 'control.sugar_dissolving.fr-CA']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--focused-run', type=Path, required=True)
    parser.add_argument('--controls-run', type=Path, required=True)
    parser.add_argument('--assets-directory', type=Path, required=True)
    parser.add_argument('--inputs-output', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and not args.inputs_output.exists()
    manifest = json.loads(args.source_manifest.read_text(encoding='utf-8'))
    source_files = {item['path']: item['sha256'] for item in manifest['files']}
    sources, rows, bindings, identity = {}, {}, [], None
    for phase, suite_name in [(args.focused_run, 'evaluation/harbour-model-quality-v1.json'),
                              (args.controls_run, 'evaluation/independent-factual-controls-v1.json')]:
        metadata_path = phase / 'metadata.json'
        metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
        assert metadata['complete'] is True
        assert all(source_files.get(name) == sha for name, sha in metadata['sourceSHA256'].items())
        current = {key: metadata[key] for key in ['sourceSHA256', 'runtimeFilesSHA256', 'models', 'executableSHA256', 'swiftVersion', 'platform', 'processor', 'logicalProcessors']}
        if identity is None:
            identity = current
        assert identity == current
        suite = json.loads((ROOT / suite_name).read_text(encoding='utf-8'))
        assert digest(ROOT / suite_name) == metadata['suiteSHA256']
        for case in suite['cases']:
            if case['id'] in CASE_IDS:
                assert case['id'] not in sources
                sources[case['id']] = case
        stream = phase / 'qwen35.jsonl'
        assert digest(stream) == metadata['resultSHA256']['qwen35']
        bindings.append({'phase': phase.name, 'rowsSHA256': digest(stream), 'metadataSHA256': digest(metadata_path), 'suiteSHA256': metadata['suiteSHA256']})
        for line in stream.read_text(encoding='utf-8').splitlines():
            row = json.loads(line)
            if row['caseID'] in CASE_IDS:
                assert row['caseID'] not in rows and row['budget'] == 512 and row['kind'] == 'prose'
                assert row['model'] == 'qwen35' and row['effort'] == 'standard' and row['repeatIndex'] == 0
                assert row['prompt'].endswith('<|im_start|>assistant\n<think>\n\n</think>\n\n')
                binding = next(item for item in metadata['promptSHA256']['qwen35'] if item['caseID'] == row['caseID'])
                assert hashlib.sha256(row['prompt'].encode('utf-8')).hexdigest() == binding['prompt']
                rows[row['caseID']] = row
    assert set(rows) == set(sources) == set(CASE_IDS)
    fixture_cases = []
    allowed = {'id', 'split', 'kind', 'language', 'input', 'history', 'hint', 'effortSubset', 'timingSubset'}
    for case_id in CASE_IDS:
        original = sources[case_id]
        fixture = {key: value for key, value in original.items() if key in allowed}
        fixture['records'] = rows[case_id]['records']
        assert fixture['split'] == 'dev' and fixture['kind'] == 'prose' and fixture['history'] == []
        assert 'expected' not in fixture and 'manualReview' not in fixture
        fixture_cases.append(fixture)
    inputs = {'id': 'qwen35-same-revision-q6-six-prose-diagnostic-v1', 'version': 1, 'cases': fixture_cases}
    args.inputs_output.open('x', encoding='utf-8').write(json.dumps(inputs, ensure_ascii=False, indent=2) + '\n')
    assets = args.assets_directory
    verification = json.loads((assets / 'asset-verification.json').read_text(encoding='utf-8'))
    asset = json.loads((assets / 'asset-preregistration.json').read_text(encoding='utf-8'))
    tokenizer = json.loads((assets / 'tokenizer-comparison.json').read_text(encoding='utf-8'))
    assert verification['complete'] is True and verification['asset'] == asset
    assert verification['actualBytes'] == asset['bytes'] == 1574961408
    assert verification['actualSHA256'] == asset['sha256'] == 'fc90339420b4298887aafb307a4291c55440b730133bbffe6ba9630503dcb548'
    assert digest(assets / 'primary-model-api.json') == asset['primaryAPIResponseSHA256']
    assert tokenizer['tokenizerMetadataIdentical'] and tokenizer['architectureMetadataIdentical'] and tokenizer['tensorNamesAndShapesIdentical']
    assert identity['executableSHA256'] == '188703cc2819c6af97811ecb1c3b88220175e7be37d90db397031292e66cbfc0'
    diagnostic_paths = ['scripts/prepare-quantization-diagnostic.py', 'scripts/evaluate-quantization-diagnostic.py']
    registration = {'schemaVersion': 1, 'id': inputs['id'], 'releaseEvidence': False,
                    'preregisteredUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    'sourceHEADAtCapture': manifest['gitHEAD'], 'sourceScope': 'Exact measured working source02, not retrospectively relabelled as a later commit',
                    'sourceIdentitySHA256': manifest['sourceIdentitySHA256'], 'sourceArchiveSHA256': manifest['archiveSHA256'],
                    'sourceManifestSHA256': digest(args.source_manifest), 'sourceFilesSHA256': source_files,
                    'originalSourceSHA256': identity['sourceSHA256'], 'runtimeFilesSHA256': identity['runtimeFilesSHA256'],
                    'executableSHA256': identity['executableSHA256'], 'sourceRunIdentity': identity, 'sourceStreams': bindings,
                    'asset': asset, 'assetVerificationSHA256': digest(assets / 'asset-verification.json'),
                    'tokenizerComparisonSHA256': digest(assets / 'tokenizer-comparison.json'), 'inputsSHA256': digest(args.inputs_output),
                    'diagnosticSourceSHA256': {name: digest(ROOT / name) for name in diagnostic_paths},
                    'design': 'Unmodified compiled production model-eval actor/builders/validators use the same original inputs, records, histories and settings. Only the separately verified same-revision Q6 asset replaces Q4 for this diagnostic.',
                    'settings': {'familySelector': 'qwen35', 'diagnosticModel': 'qwen35-q6', 'quantization': 'Q6_K', 'context': 4096,
                                 'batch': 512, 'physicalMicrobatch': 512, 'threads': 4, 'backend': 'Linux CPU', 'sampling': 'production greedy',
                                 'maxTokens': 512, 'grammar': None, 'stopAtJSON': False, 'thinking': 'canonical closed empty think prefix',
                                 'effort': 'standard', 'repetitions': 1, 'coldLoadBoundaries': 1},
                    'comparisonAcceptance': 'All6 actual prepared prompt hashes must match the measured source02 Q4 strings. Retain all raw rows and explicitly labelled derived rows; no best-answer selection or release-gate replacement.',
                    'limits': ['Single greedy pass per question; six questions are development diagnostics, not heldout quality replications.',
                               'Same quantizer/repository/revision and identical tokenizer/architecture/tensor-shape metadata do not prove equality of prequantization floating weights.',
                               'No production asset, sampler, baseline or release-gate changes; actual generation stop cause is unknown.'],
                    'cases': [{'id': case_id, 'language': rows[case_id]['language'], 'preparedPrompt': rows[case_id]['prompt'],
                               'preparedPromptSHA256': hashlib.sha256(rows[case_id]['prompt'].encode('utf-8')).hexdigest()} for case_id in CASE_IDS]}
    args.output.open('x', encoding='utf-8').write(json.dumps(registration, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'preregistrationSHA256': digest(args.output), 'inputsSHA256': digest(args.inputs_output),
                      'executableSHA256': registration['executableSHA256'], 'cases': 6, 'assetSHA256': asset['sha256']}))


if __name__ == '__main__':
    main()
