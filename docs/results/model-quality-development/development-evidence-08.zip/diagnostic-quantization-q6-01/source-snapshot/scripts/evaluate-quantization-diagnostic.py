#!/usr/bin/env python3
"""Run the sealed Q6 diagnostic through an unchanged, hash-verified production executable."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preregistration', type=Path, required=True)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--executable', type=Path, required=True)
    parser.add_argument('--asset', type=Path, required=True)
    parser.add_argument('--runtime-prefix', type=Path, required=True)
    parser.add_argument('--output-directory', type=Path, required=True)
    args = parser.parse_args()
    assert sys.platform == 'linux'
    registration = json.loads(args.preregistration.read_text(encoding='utf-8'))
    assert registration['releaseEvidence'] is False and len(registration['cases']) == 6
    for name, expected in {**registration['sourceFilesSHA256'], **registration['diagnosticSourceSHA256']}.items():
        assert digest(ROOT / name) == expected, f'Source mismatch: {name}'
    prefix = args.runtime_prefix.resolve()
    assert {p.relative_to(prefix).as_posix(): digest(p) for p in sorted(prefix.rglob('*')) if p.is_file()} == registration['runtimeFilesSHA256']
    assert digest(args.executable) == registration['executableSHA256']
    assert digest(args.inputs) == registration['inputsSHA256']
    assert args.asset.stat().st_size == registration['asset']['bytes'] and digest(args.asset) == registration['asset']['sha256']
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    environment = dict(os.environ, HARBOUR_LINUX_RUNTIME='1', HARBOUR_DEVICE_RUNTIME='0', SWIFT_DETERMINISTIC_HASHING='1',
                       PKG_CONFIG_PATH=str(prefix / 'lib/pkgconfig'), LD_LIBRARY_PATH=str(prefix / 'lib'))
    environment.pop('SDKROOT', None)
    metadata = {'schemaVersion': 1, 'complete': False, 'releaseEvidence': False,
                'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'preregistrationSHA256': digest(args.preregistration),
                'sourceIdentitySHA256': registration['sourceIdentitySHA256'], 'sourceFilesSHA256': registration['sourceFilesSHA256'],
                'diagnosticSourceSHA256': registration['diagnosticSourceSHA256'], 'runtimeFilesSHA256': registration['runtimeFilesSHA256'],
                'executableSHA256': digest(args.executable), 'asset': registration['asset'], 'inputsSHA256': digest(args.inputs),
                'settings': registration['settings'], 'platform': platform.platform(), 'processor': platform.processor(), 'logicalProcessors': os.cpu_count(),
                'swiftVersion': subprocess.check_output(['swift', '--version'], text=True).strip(),
                'comparisonAccepted': False, 'streams': {}, 'coldLoadMeaning': 'Actor/model/context initialization; disk pages already read by hash verification.',
                'rawGenerationStopCause': 'Unknown; unchanged production actor returns text only'}
    metadata_path = output / 'metadata.json'
    raw_path = output / 'qwen35-q6.raw.jsonl'
    labelled_path = output / 'qwen35-q6.labelled.jsonl'
    try:
        command = [str(args.executable), '--model', str(args.asset), '--model-id', 'qwen35', '--suite', str(args.inputs),
                   '--output', str(raw_path), '--efforts', 'standard', '--repeats', '1', '--split', 'dev']
        metadata['command'] = command
        metadata_path.write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
        with (output / 'qwen35-q6.stdout.json').open('w') as stdout, (output / 'qwen35-q6.stderr.log').open('w') as stderr:
            process = subprocess.run(command, env=environment, stdout=stdout, stderr=stderr)
        assert process.returncode == 0, f'Diagnostic process failed: exit{process.returncode}'
        rows = [json.loads(line) for line in raw_path.read_text(encoding='utf-8').splitlines() if line]
        assert [row['caseID'] for row in rows] == [case['id'] for case in registration['cases']]
        for row, case in zip(rows, registration['cases']):
            assert row['model'] == 'qwen35' and row['kind'] == 'prose' and row['budget'] == 512 and row['repeatIndex'] == 0
            assert row['threads'] == 4 and row['context'] == 4096 and row['batch'] == 512
            assert not row.get('responseGrammar') and row['prompt'] == case['preparedPrompt']
            assert hashlib.sha256(row['prompt'].encode('utf-8')).hexdigest() == case['preparedPromptSHA256']
        raw_sha = digest(raw_path)
        with labelled_path.open('x', encoding='utf-8') as stream:
            for index, row in enumerate(rows):
                labelled = dict(row, diagnosticModel='qwen35-q6', quantization='Q6_K', assetSHA256=registration['asset']['sha256'],
                                assetBytes=registration['asset']['bytes'], originalRawStreamSHA256=raw_sha, originalRawRowIndex=index,
                                releaseEvidence=False, rawGenerationStopCause=metadata['rawGenerationStopCause'])
                stream.write(json.dumps(labelled, ensure_ascii=False, sort_keys=True) + '\n')
        metadata['streams']['qwen35-q6'] = {'rows': 6, 'rawRowsSHA256': raw_sha, 'labelledRowsSHA256': digest(labelled_path),
                                          'stdoutSHA256': digest(output / 'qwen35-q6.stdout.json'), 'stderrSHA256': digest(output / 'qwen35-q6.stderr.log'),
                                          'generationErrors': sum(row.get('error') is not None for row in rows), 'preparedPromptHashesMatched': 6,
                                          'manualCompletionFactualLanguageReviewsRequired': 6}
        metadata['comparisonAccepted'] = True
        metadata['complete'] = True
        print('Completed six sealed Q6 diagnostic rows; actual prompts match original Q4 source02 strings', flush=True)
    finally:
        metadata['finishedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        metadata_path.write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    print(output, flush=True)


if __name__ == '__main__':
    main()
